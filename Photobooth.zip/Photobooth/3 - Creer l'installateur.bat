@echo off
chcp 65001 >nul
cd /d "%~dp0"
echo =====================================================
echo   Creation de l'installateur du Photobooth
echo   Compter 5 a 15 minutes. Internet necessaire.
echo =====================================================
echo.
py --version >nul 2>&1
if errorlevel 1 goto pas_python

echo [1/4] Installation des outils...
py -m pip install --upgrade pip
py -m pip install -r requirements.txt pyinstaller
if errorlevel 1 goto erreur

echo.
echo [2/4] Fabrication de Photobooth.exe...
py -m PyInstaller --noconfirm --clean --windowed --name Photobooth --icon "%~dp0photobooth.ico" --distpath "%~dp0_fabrication\dist" --workpath "%~dp0_fabrication\work" --specpath "%~dp0_fabrication" "%~dp0photobooth.py"
if errorlevel 1 goto erreur

echo.
echo [3/4] Recherche d'Inno Setup...
set "ISCC=%ProgramFiles(x86)%\Inno Setup 6\ISCC.exe"
if not exist "%ISCC%" set "ISCC=%ProgramFiles%\Inno Setup 6\ISCC.exe"
if not exist "%ISCC%" set "ISCC=%LocalAppData%\Programs\Inno Setup 6\ISCC.exe"
if not exist "%ISCC%" (
  echo Inno Setup n'est pas installe : installation automatique...
  winget install --id JRSoftware.InnoSetup -e --silent --accept-package-agreements --accept-source-agreements
)
if not exist "%ISCC%" set "ISCC=%ProgramFiles(x86)%\Inno Setup 6\ISCC.exe"
if not exist "%ISCC%" set "ISCC=%LocalAppData%\Programs\Inno Setup 6\ISCC.exe"
if not exist "%ISCC%" goto pas_inno

echo.
echo [4/4] Creation de l'installateur...
"%ISCC%" /Q "%~dp0installateur.iss"
if errorlevel 1 goto erreur
rmdir /s /q "%~dp0_fabrication"

echo.
echo =====================================================
echo   TERMINE !
echo   Le fichier "Installer Photobooth Audiova.exe" se trouve
echo   dans le dossier "Installateur".
echo   Copiez CE SEUL FICHIER sur une cle USB, puis double-cliquez
echo   dessus sur n'importe quel PC Windows pour installer.
echo =====================================================
explorer "%~dp0Installateur"
pause
exit /b 0

:pas_python
echo Python n'est pas installe sur ce PC.
echo Installez-le d'abord : voir le guide, etape 1.
pause
exit /b 1

:pas_inno
echo.
echo Inno Setup n'a pas pu etre installe automatiquement.
echo Telechargez-le sur https://jrsoftware.org/isdl.php , installez-le,
echo puis relancez ce fichier.
pause
exit /b 1

:erreur
echo.
echo ERREUR pendant la fabrication. Verifiez la connexion internet,
echo puis envoyez une photo de cette fenetre pour que je corrige.
pause
exit /b 1
