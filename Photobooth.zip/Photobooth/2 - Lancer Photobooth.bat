@echo off
cd /d "%~dp0"
start "" pyw "%~dp0photobooth.py"
