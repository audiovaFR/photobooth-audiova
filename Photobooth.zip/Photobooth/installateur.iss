﻿; Installateur Windows du Photobooth (compilé par Inno Setup)
#define NomAppli "Photobooth Audiova"
#ifndef Version
  #define Version "1.2.0"
#endif

[Setup]
AppId={{6B1E4C52-8E0F-4C1A-9C77-3A5D2F8B1E90}
AppName={#NomAppli}
AppVersion={#Version}
AppPublisher=Audiova France
AppPublisherURL=https://audiova.eu
DefaultDirName={autopf}\{#NomAppli}
DefaultGroupName={#NomAppli}
DisableProgramGroupPage=yes
OutputDir=Installateur
OutputBaseFilename=Installer Photobooth Audiova
SetupIconFile=photobooth.ico
UninstallDisplayIcon={app}\Photobooth.exe
Compression=lzma2
SolidCompression=yes
WizardStyle=modern
CloseApplications=no
SetupMutex=PhotoboothAudiovaInstallation
RestartApplications=no
ArchitecturesInstallIn64BitMode=x64compatible

[Languages]
Name: "fr"; MessagesFile: "compiler:Languages\French.isl"

[Tasks]
Name: "bureau"; Description: "Créer un raccourci sur le Bureau"; GroupDescription: "Raccourcis :"
Name: "demarrage"; Description: "Lancer le Photobooth automatiquement au démarrage de Windows"; GroupDescription: "Raccourcis :"; Flags: unchecked
Name: "pasredemarrage"; Description: "Empêcher Windows de redémarrer tout seul pour les mises à jour (recommandé pour les prestations)"; GroupDescription: "Prestations :"
Name: "gestes"; Description: "Bloquer les glissements depuis les bords de l'écran tactile (notifications, widgets)"; GroupDescription: "Prestations :"

[Files]
Source: "_fabrication\dist\Photobooth\*"; DestDir: "{app}"; Flags: ignoreversion recursesubdirs createallsubdirs
Source: "Fonds\*"; DestDir: "{app}\Fonds"; Flags: ignoreversion recursesubdirs createallsubdirs skipifsourcedoesntexist
Source: "Sons\*"; DestDir: "{app}\Sons"; Flags: ignoreversion recursesubdirs createallsubdirs skipifsourcedoesntexist
Source: "EDSDK\*"; DestDir: "{app}\EDSDK"; Flags: ignoreversion recursesubdirs createallsubdirs skipifsourcedoesntexist
Source: "Modeles\*"; DestDir: "{app}\Modeles"; Flags: ignoreversion recursesubdirs createallsubdirs skipifsourcedoesntexist
Source: "photobooth.ico"; DestDir: "{app}"; Flags: ignoreversion
Source: "LISEZ-MOI - Guide d'installation.txt"; DestDir: "{app}"; Flags: ignoreversion isreadme

[Registry]
Root: HKLM; Subkey: "SOFTWARE\Policies\Microsoft\Windows\WindowsUpdate\AU"; ValueType: dword; ValueName: "NoAutoRebootWithLoggedOnUsers"; ValueData: 1; Tasks: pasredemarrage; Flags: uninsdeletevalue
Root: HKLM; Subkey: "SOFTWARE\Policies\Microsoft\Windows\EdgeUI"; ValueType: dword; ValueName: "AllowEdgeSwipe"; ValueData: 0; Tasks: gestes; Flags: uninsdeletevalue

[Icons]
Name: "{group}\{#NomAppli}"; Filename: "{app}\Photobooth.exe"; IconFilename: "{app}\photobooth.ico"
Name: "{group}\Guide d'utilisation"; Filename: "{app}\LISEZ-MOI - Guide d'installation.txt"
Name: "{group}\Mes photos"; Filename: "{userdocs}\Photobooth Audiova\Photos"
Name: "{group}\Désinstaller {#NomAppli}"; Filename: "{uninstallexe}"
Name: "{autodesktop}\{#NomAppli}"; Filename: "{app}\Photobooth.exe"; IconFilename: "{app}\photobooth.ico"; Tasks: bureau
Name: "{userstartup}\{#NomAppli}"; Filename: "{app}\Photobooth.exe"; Tasks: demarrage

[Run]
Filename: "{app}\Photobooth.exe"; Description: "Lancer le Photobooth maintenant"; Flags: nowait postinstall

[Code]
// Mise à jour depuis le Photobooth : l'ancienne version se ferme (jusqu'à 5 s de rangement).
// On lui laisse le temps, puis on la ferme de force si besoin, pour ne jamais annuler l'installation.
function PrepareToInstall(var NeedsRestart: Boolean): String;
var
  Code: Integer;
begin
  if WizardSilent then
    Sleep(7000);
  Exec(ExpandConstant('{sys}\taskkill.exe'), '/F /IM Photobooth.exe', '', SW_HIDE, ewWaitUntilTerminated, Code);
  Sleep(1000);
  Result := '';
end;
