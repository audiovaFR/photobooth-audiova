# Envoie le nouvel installateur sur l'hébergement web, pour le bouton « Rechercher une mise à jour ».
# Utilisé automatiquement par GitHub si les secrets FTP sont renseignés.
import ftplib, io, os, re

hote = os.environ["FTP_HOTE"]
utilisateur = os.environ["FTP_UTILISATEUR"]
mdp = os.environ["FTP_MOT_DE_PASSE"]
dossier = os.environ.get("FTP_DOSSIER") or "/public_html/photobooth/maj"
version = re.search(r'VERSION = "(.+?)"', open("photobooth.py", encoding="utf-8").read()).group(1)
installateur = os.path.join("Installateur", "Installer Photobooth Audiova.exe")
nom_versionne = f"Installer_Photobooth_Audiova_{version}.exe"     # nom unique : jamais de vieux fichier en cache

# Interdit la mise en cache de ce dossier par l'hébergeur (sinon un ancien installateur peut être servi)
HTACCESS = """<IfModule mod_headers.c>
Header set Cache-Control "no-store, no-cache, must-revalidate, max-age=0"
Header set Pragma "no-cache"
</IfModule>
<IfModule LiteSpeed>
CacheDisable public /
</IfModule>
"""

with ftplib.FTP(hote, timeout=120) as ftp:
    ftp.login(utilisateur, mdp)
    if dossier.startswith("/"):
        ftp.cwd("/")
    for part in [p for p in dossier.split("/") if p]:
        try:
            ftp.cwd(part)
        except ftplib.error_perm:
            ftp.mkd(part)
            ftp.cwd(part)
    ftp.storbinary("STOR .htaccess", io.BytesIO(HTACCESS.encode("utf-8")))
    for nom in (nom_versionne, "Installer Photobooth Audiova.exe"):
        with open(installateur, "rb") as f:
            ftp.storbinary("STOR " + nom, f)
    # en dernier : la mise à jour n'est annoncée qu'une fois les installateurs complets
    ftp.storbinary("STOR version.txt", io.BytesIO(f"{version}\n{nom_versionne}\n".encode("utf-8")))
print("Version", version, "publiée dans", dossier, "(", nom_versionne, ")")
