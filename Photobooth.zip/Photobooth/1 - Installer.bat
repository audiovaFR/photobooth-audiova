@echo off
chcp 65001 >nul
echo Installation des composants du Photobooth...
echo.
py -m pip install --upgrade pip
py -m pip install -r "%~dp0requirements.txt"
if errorlevel 1 (
  echo.
  echo ERREUR : verifiez que Python est installe avec la case "Add python.exe to PATH" cochee.
) else (
  echo.
  echo Installation terminee ! Lancez "Lancer Photobooth.bat".
)
pause
