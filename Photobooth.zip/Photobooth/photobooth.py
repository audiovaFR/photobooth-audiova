# -*- coding: utf-8 -*-
"""
PHOTOBOOTH pour Windows (dans l'esprit de dslrBooth)

- Canon EOS (ex. 4000D) piloté par digiCamControl, ou une webcam
- Impression 10x15 (DNP DS-RX1HS ou toute imprimante Windows)
- Fonds / cadres personnalisés : PNG 10x15 avec zones transparentes
- Partage par QR code (Wi-Fi local ou hébergement FTP) et par e-mail
- Chaque option s'active ou se désactive dans les réglages
- Toutes les photos (originaux + montages) sont enregistrées sur l'ordinateur

Menu réglages : le petit cadenas en haut à droite de l'écran (pas besoin de clavier).
"""

import os, sys, io, re, json, time, glob, shutil, socket, threading, queue, logging, random, math
import smtplib, ftplib, uuid, functools, http.server, urllib.request, urllib.parse
from datetime import datetime
from email.message import EmailMessage
import tkinter as tk
from tkinter import ttk, filedialog, messagebox, simpledialog

from PIL import Image, ImageTk, ImageOps, ImageDraw, ImageFont, ImageFilter
import numpy as np

try:
    import cv2
except ImportError:
    cv2 = None
try:
    import qrcode
except ImportError:
    qrcode = None
try:
    import win32print, win32ui, win32con
    from PIL import ImageWin
    HAS_WIN32 = True
except ImportError:
    HAS_WIN32 = False

# --------------------------------------------------------------------------
# Dossiers
# --------------------------------------------------------------------------
VERSION = "2.3.0"
DEPOT_GITHUB = "audiovaFR/photobooth-audiova"   # dépôt PUBLIC où sont publiées les versions (Releases)
CREDIT = ("Logiciel conçu et fabriqué par Audiova France. En cas de souci ou pour une amélioration, "
          "contactez-nous : contact@audiova.eu")

APP_DIR = os.path.dirname(os.path.abspath(
    sys.executable if getattr(sys, "frozen", False) else __file__))


def _dossier_inscriptible(d):
    try:
        test = os.path.join(d, ".test_ecriture")
        with open(test, "w") as f:
            f.write("ok")
        os.remove(test)
        return True
    except OSError:
        return False


# Logiciel installé dans « Program Files » (non modifiable) : réglages, fonds et photos vont
# dans Documents\Photobooth Audiova. Version copiée dans un dossier simple : tout reste à côté.
if _dossier_inscriptible(APP_DIR):
    DATA_DIR = APP_DIR
else:
    DATA_DIR = os.path.join(os.path.expanduser("~"), "Documents", "Photobooth Audiova")
    os.makedirs(DATA_DIR, exist_ok=True)
    for _n in ("Fonds", "Sons"):             # fonds et sons d'exemple : ajoute ceux qui manquent
        _src, _dst = os.path.join(APP_DIR, _n), os.path.join(DATA_DIR, _n)
        if os.path.isdir(_src):
            os.makedirs(_dst, exist_ok=True)
            for _f in os.listdir(_src):
                _cible = os.path.join(_dst, _f)
                if not os.path.exists(_cible) and os.path.isfile(os.path.join(_src, _f)):
                    try:
                        shutil.copy2(os.path.join(_src, _f), _cible)
                    except OSError:
                        pass

FONDS_DIR = os.path.join(DATA_DIR, "Fonds")
PHOTOS_DIR = os.path.join(DATA_DIR, "Photos")
ORIG_DIR = os.path.join(PHOTOS_DIR, "Originaux")
MONT_DIR = os.path.join(PHOTOS_DIR, "Montages 10x15")
ATTENTE_DIR = os.path.join(DATA_DIR, "E-mails en attente")
CONFIG_PATH = os.path.join(DATA_DIR, "reglages.json")
for _d in (FONDS_DIR, ORIG_DIR, MONT_DIR, ATTENTE_DIR):
    os.makedirs(_d, exist_ok=True)

logging.basicConfig(filename=os.path.join(DATA_DIR, "photobooth.log"),
                    level=logging.INFO, encoding="utf-8",
                    format="%(asctime)s %(levelname)s %(message)s")
log = logging.getLogger("photobooth")

# --------------------------------------------------------------------------
# Apparence
# --------------------------------------------------------------------------
# Thème par défaut : Audiova France (modifiable dans Réglages > Apparence)
NUIT = "#0E1220"        # fond (couleur du site audiova.eu)
NUIT_CLAIR = "#1B2136"  # touches, boutons secondaires
CHAMPAGNE = "#7B3FF2"   # couleur 1 (violet)
ROSE = "#FF3D9A"        # couleur 2 (magenta)
CYAN = "#21D4FD"        # couleur 3 (cyan)
BLANC = "#FFFFFF"
GRIS = "#8A90A6"
TXT = "#FFFFFF"          # couleur des textes (blanc en mode sombre, foncé en mode clair)
ENCRE = "#141A2E"        # texte foncé fixe (champs de saisie, QR code)
TITRE = "Bahnschrift"   # livrée avec Windows 10 / 11
TEXTE = "Segoe UI"


def lever_coucher(jour, lat, lon):
    """Heures de lever et de coucher du soleil (heure locale du PC), calcul NOAA, sans internet.
    Retourne (lever, coucher) ou (None, None) en cas de nuit/jour polaire."""
    from datetime import timezone, timedelta
    n = jour.timetuple().tm_yday
    g = 2 * math.pi / 365 * (n - 1)
    eq = 229.18 * (0.000075 + 0.001868 * math.cos(g) - 0.032077 * math.sin(g)
                   - 0.014615 * math.cos(2 * g) - 0.040849 * math.sin(2 * g))
    decl = (0.006918 - 0.399912 * math.cos(g) + 0.070257 * math.sin(g) - 0.006758 * math.cos(2 * g)
            + 0.000907 * math.sin(2 * g) - 0.002697 * math.cos(3 * g) + 0.00148 * math.sin(3 * g))
    la = math.radians(lat)
    cos_ha = math.cos(math.radians(90.833)) / (math.cos(la) * math.cos(decl)) - math.tan(la) * math.tan(decl)
    if not -1 <= cos_ha <= 1:
        return None, None
    ha = math.degrees(math.acos(cos_ha))
    minuit = datetime(jour.year, jour.month, jour.day, tzinfo=timezone.utc)
    lever = minuit + timedelta(minutes=720 - 4 * (lon + ha) - eq)
    coucher = minuit + timedelta(minutes=720 - 4 * (lon - ha) - eq)
    return lever.astimezone(), coucher.astimezone()


def mode_effectif(cfg, maintenant=None):
    """« clair » ou « sombre » : le mode forcé, ou en automatique selon le soleil."""
    mode = cfg.get("mode", "sombre")
    if mode != "auto":
        return mode
    try:
        lat, lon = float(str(cfg.get("latitude")).replace(",", ".")), \
            float(str(cfg.get("longitude")).replace(",", "."))
    except ValueError:
        lat, lon = 46.95, 4.30
    maintenant = maintenant or datetime.now().astimezone()
    lever, coucher = lever_coucher(maintenant.date(), lat, lon)
    if lever is None:
        return "sombre"
    return "clair" if lever <= maintenant < coucher else "sombre"


def appliquer_theme(cfg):
    global NUIT, NUIT_CLAIR, CHAMPAGNE, ROSE, CYAN, TXT, GRIS
    CHAMPAGNE = cfg.get("couleur_1", CHAMPAGNE)
    ROSE = cfg.get("couleur_2", ROSE)
    CYAN = cfg.get("couleur_3", CYAN)
    if mode_effectif(cfg) == "clair":       # prestations de jour, en plein soleil
        NUIT = cfg.get("couleur_fond_clair", "#F6F3FA")
        TXT = "#1B1730"
        GRIS = "#6B6680"
        NUIT_CLAIR = melange(NUIT, "#000000", 0.07)
    else:                                   # soirées
        NUIT = cfg.get("couleur_fond", "#0E1220")
        TXT = "#FFFFFF"
        GRIS = "#8A90A6"
        NUIT_CLAIR = melange(NUIT, "#FFFFFF", 0.08)


def rgb(c):
    c = c.lstrip("#")
    return tuple(int(c[i:i + 2], 16) for i in (0, 2, 4))


def melange(c1, c2, t):
    a, b = rgb(c1), rgb(c2)
    return "#%02x%02x%02x" % tuple(int(a[i] + (b[i] - a[i]) * t) for i in range(3))

# --------------------------------------------------------------------------
# Réglages
# --------------------------------------------------------------------------
DEFAUT = {
    "pin": "1234",
    "marque": "",
    "titre_accueil": "Touchez pour commencer",
    "texte_accueil": "",
    "pied_accueil": "audiova.eu  ·  @audiova_france",
    "couleur_fond": "#0E1220",
    "couleur_1": "#7B3FF2",
    "couleur_2": "#FF3D9A",
    "couleur_3": "#21D4FD",
    "animations": True,
    "mode": "sombre",                    # "auto" (selon le soleil), "sombre" (soirée) ou "clair" (jour)
    "lieu": "Autun",
    "latitude": "46.95",
    "longitude": "4.30",
    "couleur_fond_clair": "#F6F3FA",
    "compte_a_rebours": 3,
    "delai_retour": 60,
    "miroir": True,
    "camera": "digicam",                 # "digicam" (Canon) ou "webcam"
    "digicam_url": "http://localhost:5513",
    "webcam_index": 0,
    "fond": "",
    "fond_photo": "",                    # fond 10x15 mémorisé (même en mode bandelettes seules)
    "fond_bande": "",                    # fond bandelette 5x15 associé (même décor, autre format)
    "choix_format": True,                # l'invité choisit 10x15 ou bandelettes si les deux fonds existent
    "impression_active": True,
    "imprimante": "",
    "copies_max": 2,
    "evenement": "",
    "limite_impressions": 0,             # 0 = illimité
    "impressions_faites": 0,
    "bloquer_clavier": False,           # inutile sans clavier branché
    "dossier_secours": "",
    "stats": {"seances": 0, "photos": 0, "impressions": 0, "emails": 0, "qr": 0},
    "galerie_dossier": "",
    "diaporama": True,
    "diaporama_delai": 30,
    "filtre": "aucun",
    "sons": True,
    "cadrage_exact": True,
    "proposer_refaire": True,
    "lancer_digicam": True,
    "url_mise_a_jour": "",                 # adresse privée des versions de test (jamais écrite dans le code)
    "canal_test": False,                   # True : reçoit les versions de test au lieu des versions publiques
    "afficher_fps": False,
    "proposer_nb": True,
    "mode_prestation": True,
    "hautes_performances": True,
    "aide_cadrage": True,
    "bloquer_bords": True,
    "animation_accueil": "bulles",       # "bulles", "etoiles", "guirlande", "paillettes" ou "aucune"
    "densite_anim": 1.0,                 # quantité d'éléments animés (0.6, 1.0 ou 1.6)
    "guide_masque": False,               # encart « Mise en route » masqué une fois tout réglé
    "guide_etapes": [],                  # étapes du guide déjà cochées
    "clavier_auto": True,                # le clavier apparaît quand on touche une case
    "comment_ca_marche": True,
    "duree_impression": 15,              # secondes pour le 1er tirage (DNP DS-RX1HS)
    "forme_bandelette": "",
    "imprimante_bande": "",              # imprimante Windows réglée sur la coupe 2 pouces (facultatif)              # format du pilote pour les bandelettes 5x15 (vide = automatique)
    "telecommande": True,
    "port_telecommande": 8090,
    "lien_avis": "",
    "qr_actif": False,
    "qr_mode": "local",                  # "local" (Wi-Fi) ou "ftp" (internet)
    "port_local": 8080,
    "qr_texte": "Scannez avec votre téléphone pour récupérer la photo",
    "qr_texte_wifi": "Connectez-vous d'abord au Wi-Fi du photobooth",
    "ftp_hote": "",
    "ftp_utilisateur": "",
    "ftp_mot_de_passe": "",
    "ftp_dossier": "/public_html/photobooth",
    "url_publique": "https://monsite.fr/photobooth",
    "email_actif": False,
    "smtp_hote": "smtp.gmail.com",
    "smtp_port": 587,
    "smtp_utilisateur": "",
    "smtp_mot_de_passe": "",
    "email_expediteur": "",
    "email_sujet": "Votre photo souvenir · Audiova France",
    "email_message": ("Bonjour,\n\nMerci d'être passé(e) au photo booth ! "
                      "Voici votre photo souvenir.\n\nBelle fin de soirée,\n"
                      "L'équipe Audiova France\naudiova.eu · @audiova_france"),
}


def charger_reglages():
    import copy
    cfg = copy.deepcopy(DEFAUT)
    try:
        with open(CONFIG_PATH, encoding="utf-8") as f:
            lu_fichier = json.load(f)
            cfg.update(lu_fichier)
        stats = dict(DEFAUT["stats"])
        stats.update(cfg.get("stats") or {})
        cfg["stats"] = stats
        if "canal_test" not in lu_fichier and cfg.get("url_mise_a_jour"):
            cfg["canal_test"] = True
    except FileNotFoundError:
        sauver_reglages(cfg)
    except Exception:
        log.exception("Lecture des réglages impossible")
    return cfg


def sauver_reglages(cfg):
    with open(CONFIG_PATH, "w", encoding="utf-8") as f:
        json.dump(cfg, f, indent=2, ensure_ascii=False)


def police_pil(taille):
    for nom in ("bahnschrift.ttf", "arialbd.ttf", "arial.ttf", "DejaVuSans-Bold.ttf"):
        try:
            return ImageFont.truetype(nom, taille)
        except OSError:
            continue
    return ImageFont.load_default()


def police_titre(taille):
    f = police_pil(taille)
    try:
        f.set_variation_by_name("Bold")       # Bahnschrift est une police variable
    except Exception:
        pass
    return f


def degrade(taille, c1, c2, vertical=False):
    w, h = taille
    a, b = np.array(rgb(c1), float), np.array(rgb(c2), float)
    t = np.linspace(0, 1, h if vertical else w)[:, None]
    ligne = (a + (b - a) * t).astype(np.uint8)
    arr = np.repeat(ligne[:, None, :], w, 1) if vertical else np.repeat(ligne[None, :, :], h, 0)
    return Image.fromarray(arr, "RGB")


def img_pilule(texte, largeur, hauteur, principal=True, taille=None, appuye=False):
    """Bouton arrondi : dégradé lumineux (principal) ou contour (secondaire)."""
    s, halo = 3, int(hauteur * 0.35)
    W, H = (largeur + 2 * halo) * s, (hauteur + 2 * halo) * s
    img = Image.new("RGBA", (W, H), (0, 0, 0, 0))
    boite = (halo * s, halo * s, W - halo * s, H - halo * s)
    masque = Image.new("L", (W, H), 0)
    ImageDraw.Draw(masque).rounded_rectangle(boite, radius=hauteur * s // 2, fill=255)
    if principal:
        lueur = Image.new("RGBA", (W, H), rgb(ROSE) + (0,))
        lueur.putalpha(masque.filter(ImageFilter.GaussianBlur(halo * s * 0.55)).point(
            lambda v: int(v * (0.35 if appuye else 0.6))))
        img = Image.alpha_composite(img, lueur)
        fond = degrade((W, H), CHAMPAGNE, ROSE)
        if appuye:
            fond = Image.blend(fond, Image.new("RGB", (W, H), "black"), 0.2)
        couche = Image.new("RGBA", (W, H), (0, 0, 0, 0))
        couche.paste(fond, (0, 0), masque)
        img = Image.alpha_composite(img, couche)
    else:
        d = ImageDraw.Draw(img)
        d.rounded_rectangle(boite, radius=hauteur * s // 2,
                            fill=rgb(NUIT_CLAIR if not appuye else melange(NUIT_CLAIR, TXT, 0.1)) + (255,),
                            outline=rgb(melange(NUIT, TXT, 0.28)) + (255,), width=2 * s)
    d = ImageDraw.Draw(img)
    f = police_titre(int((taille or hauteur * 0.42) * s))
    couleur_texte = (255, 255, 255, 255) if principal else rgb(TXT) + (255,)
    d.text((W / 2, H / 2), texte, font=f, fill=couleur_texte, anchor="mm")
    return img.resize((largeur + 2 * halo, hauteur + 2 * halo), Image.LANCZOS)


def img_titre(texte, taille, c1=None, c2=None, halo=True):
    """Texte en dégradé avec une lueur, façon néon."""
    c1, c2 = c1 or CYAN, c2 or ROSE
    f = police_titre(taille)
    x0, y0, x1, y1 = f.getbbox(texte)
    marge = int(taille * 0.45)
    W, H = x1 - x0 + 2 * marge, y1 - y0 + 2 * marge
    masque = Image.new("L", (W, H), 0)
    ImageDraw.Draw(masque).text((marge - x0, marge - y0), texte, font=f, fill=255)
    img = Image.new("RGBA", (W, H), (0, 0, 0, 0))
    if halo:
        lueur = Image.new("RGBA", (W, H), rgb(CHAMPAGNE) + (0,))
        lueur.putalpha(masque.filter(ImageFilter.GaussianBlur(taille * 0.16)).point(lambda v: int(v * 0.85)))
        img = Image.alpha_composite(img, lueur)
    couche = degrade((W, H), c1, c2).convert("RGBA")
    couche.putalpha(masque)
    return Image.alpha_composite(img, couche)


def img_cadre_photo(montage, max_w, max_h):
    """Aperçu du montage avec bord blanc et halo coloré."""
    m = int(min(max_w, max_h) * 0.05)
    vue = ImageOps.contain(montage, (max_w - 2 * m - 16, max_h - 2 * m - 16), Image.LANCZOS)
    W, H = vue.width + 16 + 2 * m, vue.height + 16 + 2 * m
    img = Image.new("RGBA", (W, H), (0, 0, 0, 0))
    masque = Image.new("L", (W, H), 0)
    ImageDraw.Draw(masque).rectangle((m, m, W - m, H - m), fill=255)
    lueur = degrade((W, H), CHAMPAGNE, CYAN, vertical=True).convert("RGBA")
    lueur.putalpha(masque.filter(ImageFilter.GaussianBlur(m * 0.6)).point(lambda v: int(v * 0.8)))
    img = Image.alpha_composite(img, lueur)
    ImageDraw.Draw(img).rectangle((m, m, W - m - 1, H - m - 1), fill=(255, 255, 255, 255))
    img.paste(vue, (m + 8, m + 8))
    return img


def img_cadenas(taille, couleur):
    """Petit cadenas discret (accès aux réglages)."""
    s = 4
    T = taille * s
    img = Image.new("RGBA", (T, T), (0, 0, 0, 0))
    d = ImageDraw.Draw(img)
    c = rgb(couleur) + (255,)
    ep = int(T * 0.09)
    d.arc((T * 0.27, T * 0.06, T * 0.73, T * 0.58), 180, 360, fill=c, width=ep)
    d.line((T * 0.27 + ep / 2, T * 0.32, T * 0.27 + ep / 2, T * 0.46), fill=c, width=ep)
    d.line((T * 0.73 - ep / 2, T * 0.32, T * 0.73 - ep / 2, T * 0.46), fill=c, width=ep)
    d.rounded_rectangle((T * 0.16, T * 0.44, T * 0.84, T * 0.94), radius=int(T * 0.1), fill=c)
    d.ellipse((T * 0.44, T * 0.58, T * 0.56, T * 0.70), fill=(0, 0, 0, 0))
    d.rectangle((T * 0.475, T * 0.66, T * 0.525, T * 0.82), fill=(0, 0, 0, 0))
    return img.resize((taille, taille), Image.LANCZOS)


_CACHE_IMAGES = {}


def img_fond_accueil(W, H, clair):
    """Fond fixe avec de grandes lueurs colorées floues (calculé une seule fois)."""
    cle = ("fond", W, H, clair, NUIT, CHAMPAGNE, ROSE, CYAN)
    if cle not in _CACHE_IMAGES:
        w, h = max(96, W // 4), max(54, H // 4)
        img = Image.new("RGB", (w, h), NUIT)
        for (cx, cy, r, coul, force) in ((0.12, 0.15, 0.32, CHAMPAGNE, 0.38), (0.9, 0.25, 0.28, ROSE, 0.30),
                                         (0.55, 1.05, 0.38, CYAN, 0.22)):
            calque = Image.new("RGB", (w, h), coul)
            masque = Image.new("L", (w, h), 0)
            ImageDraw.Draw(masque).ellipse(((cx - r) * w, (cy - r) * h * 1.6, (cx + r) * w, (cy + r) * h * 1.6),
                                           fill=int(255 * force * (0.7 if clair else 1)))
            masque = masque.filter(ImageFilter.GaussianBlur(w * 0.12))
            img = Image.composite(calque, img, masque)
        grand = img.resize((W, H), Image.BICUBIC).filter(ImageFilter.GaussianBlur(3))
        # léger grain pour éviter les bandes visibles dans les dégradés sombres
        bruit = Image.effect_noise((W, H), 6).convert("RGB")
        _CACHE_IMAGES[cle] = Image.blend(grand, bruit, 0.025)
    return _CACHE_IMAGES[cle]


def img_bulle(d, couleur, force):
    """Bulle de lumière floue (effet « bokeh »)."""
    cle = ("bulle", d, couleur, round(force, 2))
    if cle not in _CACHE_IMAGES:
        marge = int(d * 0.25)
        T = d + 2 * marge
        masque = Image.new("L", (T, T), 0)
        ImageDraw.Draw(masque).ellipse((marge, marge, marge + d, marge + d), fill=int(255 * force))
        masque = masque.filter(ImageFilter.GaussianBlur(d * 0.09))
        img = Image.new("RGBA", (T, T), rgb(couleur) + (0,))
        img.putalpha(masque)
        _CACHE_IMAGES[cle] = img
    return _CACHE_IMAGES[cle]


def img_etoile(d, couleur, brillante):
    cle = ("etoile", d, couleur, brillante)
    if cle not in _CACHE_IMAGES:
        T = d * 4
        masque = Image.new("L", (T, T), 0)
        dd = ImageDraw.Draw(masque)
        dd.ellipse((T / 2 - d / 2, T / 2 - d / 2, T / 2 + d / 2, T / 2 + d / 2), fill=255 if brillante else 170)
        masque = masque.filter(ImageFilter.GaussianBlur(d * (0.7 if brillante else 0.35)))
        if brillante:
            dd = ImageDraw.Draw(masque)
            dd.ellipse((T / 2 - d / 4, T / 2 - d / 4, T / 2 + d / 4, T / 2 + d / 4), fill=255)
        img = Image.new("RGBA", (T, T), rgb(couleur) + (0,))
        img.putalpha(masque)
        _CACHE_IMAGES[cle] = img
    return _CACHE_IMAGES[cle]


def img_ampoule(d, niveau):
    """Ampoule de guirlande : niveau 0 (presque éteinte), 1 (douce) ou 2 (pleine lumière)."""
    cle = ("ampoule", d, niveau)
    if cle not in _CACHE_IMAGES:
        force = (0.28, 0.6, 1.0)[niveau]
        T = d * 5
        c = T / 2
        halo = Image.new("L", (T, T), 0)
        ImageDraw.Draw(halo).ellipse((c - d * 0.9, c - d * 0.9, c + d * 0.9, c + d * 0.9), fill=int(200 * force))
        halo = halo.filter(ImageFilter.GaussianBlur(d * 0.9))
        img = Image.new("RGBA", (T, T), (255, 196, 110, 0))
        img.putalpha(halo)
        coeur = Image.new("L", (T, T), 0)
        ImageDraw.Draw(coeur).ellipse((c - d * 0.42, c - d * 0.5, c + d * 0.42, c + d * 0.5),
                                      fill=int(255 * (0.45 + 0.55 * force)))
        bulbe = Image.new("RGBA", (T, T), (255, 238, 200, 0))
        bulbe.putalpha(coeur.filter(ImageFilter.GaussianBlur(d * 0.08)))
        _CACHE_IMAGES[cle] = Image.alpha_composite(img, bulbe)
    return _CACHE_IMAGES[cle]


def img_paillette(r, niveau, couleur="#FFD678"):
    """Paillette dorée à 4 branches : niveau 0 (discrète), 1 (moyenne), 2 (éclat)."""
    cle = ("paillette", r, niveau, couleur)
    if cle not in _CACHE_IMAGES:
        force, taille = ((0.35, 0.7), (0.7, 0.9), (1.0, 1.25))[niveau]
        R = r * taille
        T = int(R * 6) + 2
        c = T / 2
        m = Image.new("L", (T, T), 0)
        dd = ImageDraw.Draw(m)
        dd.polygon([(c, c - R * 2.4), (c + R * 0.35, c), (c, c + R * 2.4), (c - R * 0.35, c)], fill=255)
        dd.polygon([(c - R * 2.4, c), (c, c - R * 0.35), (c + R * 2.4, c), (c, c + R * 0.35)], fill=255)
        m = m.filter(ImageFilter.GaussianBlur(R * 0.22)).point(lambda v: int(v * force))
        img = Image.new("RGBA", (T, T), rgb(couleur) + (0,))
        img.putalpha(m)
        _CACHE_IMAGES[cle] = img
    return _CACHE_IMAGES[cle]


def guirlandes(W, H, k):
    """Positions des fils et des ampoules (3 guirlandes en haut de l'écran)."""
    fils = []
    for (x0, x1, yb, fl) in ((-0.03, 0.56, 0.035, 0.16), (0.44, 1.03, 0.035, 0.17), (-0.03, 1.03, 0.012, 0.30)):
        pts = [((x0 + (x1 - x0) * t) * W, (yb + fl * 4 * t * (1 - t)) * H) for t in [i / 60 for i in range(61)]]
        fils.append(pts)
    return fils


def apercu_animation(style, w, h, clair=False):
    """Petite image fixe de chaque animation, pour la page de choix."""
    k = h / 1080
    rnd = random.Random(7)
    img = img_fond_accueil(w, h, clair).convert("RGBA")

    def poser(sprite, x, y):
        img.alpha_composite(sprite, (int(x - sprite.width / 2), int(y - sprite.height / 2)))
    if style == "bulles":
        for _ in range(22):
            d = max(6, int(rnd.uniform(40, 170) * k))
            poser(img_bulle(d, rnd.choice((CHAMPAGNE, ROSE, CYAN, BLANC)), rnd.uniform(0.2, 0.45)),
                  rnd.uniform(0, w), rnd.uniform(0, h))
    elif style == "etoiles":
        for i in range(60):
            d = max(2, int(rnd.uniform(4, 10) * k))
            poser(img_etoile(d, rnd.choice((BLANC, CYAN, ROSE)), i % 8 == 0), rnd.uniform(0, w), rnd.uniform(0, h))
    elif style == "guirlande":
        dd = ImageDraw.Draw(img)
        for pts in guirlandes(w, h, k):
            dd.line(pts, fill=(42, 36, 64, 255), width=max(1, int(3 * k)))
            for x, y in pts[::5]:
                poser(img_ampoule(max(4, int(22 * k)), rnd.choice((0, 1, 2, 2))), x, y + 14 * k)
    elif style == "paillettes":
        for _ in range(70):
            poser(img_paillette(max(2, rnd.uniform(2, 7) * k), rnd.choice((0, 0, 1, 2))),
                  rnd.uniform(0, w), rnd.uniform(0, h))
    return img.convert("RGB")


def img_etape(numero, d, actif):
    """Rond numéroté de l'écran « Comment ça marche » (lumineux quand c'est son tour)."""
    s = 3
    halo = int(d * 0.35)
    T = (d + 2 * halo) * s
    img = Image.new("RGBA", (T, T), (0, 0, 0, 0))
    masque = Image.new("L", (T, T), 0)
    ImageDraw.Draw(masque).ellipse((halo * s, halo * s, T - halo * s, T - halo * s), fill=255)
    if actif:
        lueur = Image.new("RGBA", (T, T), rgb(ROSE) + (0,))
        lueur.putalpha(masque.filter(ImageFilter.GaussianBlur(halo * s * 0.6)).point(lambda v: int(v * 0.8)))
        img = Image.alpha_composite(img, lueur)
        fond = degrade((T, T), CHAMPAGNE, ROSE).convert("RGBA")
    else:
        fond = Image.new("RGBA", (T, T), rgb(NUIT_CLAIR) + (255,))
    couche = Image.new("RGBA", (T, T), (0, 0, 0, 0))
    couche.paste(fond, (0, 0), masque)
    img = Image.alpha_composite(img, couche)
    dd = ImageDraw.Draw(img)
    if not actif:
        dd.ellipse((halo * s, halo * s, T - halo * s, T - halo * s), outline=rgb(melange(NUIT, TXT, 0.3)) + (255,),
                   width=2 * s)
    couleur = (255, 255, 255, 255) if actif else rgb(TXT) + (255,)
    dd.text((T / 2, T / 2), str(numero), font=police_titre(int(d * 0.5 * s)), fill=couleur, anchor="mm")
    return img.resize((d + 2 * halo, d + 2 * halo), Image.LANCZOS)


def img_carte_qr(qr, marge):
    """QR code sur une carte blanche arrondie entourée d'un halo coloré."""
    cw = qr.width + 2 * marge
    halo = marge * 2
    W = cw + 2 * halo
    img = Image.new("RGBA", (W, W), (0, 0, 0, 0))
    masque = Image.new("L", (W, W), 0)
    ImageDraw.Draw(masque).rounded_rectangle((halo, halo, W - halo, W - halo), radius=marge, fill=255)
    lueur = degrade((W, W), CHAMPAGNE, ROSE).convert("RGBA")
    lueur.putalpha(masque.filter(ImageFilter.GaussianBlur(halo * 0.5)))
    img = Image.alpha_composite(img, lueur)
    carte = Image.new("RGBA", (W, W), (255, 255, 255, 255))
    carte.paste(qr, (halo + marge, halo + marge))
    img.paste(carte, (0, 0), masque)
    return img


def faisceau(ox, oy, angle, longueur, demi_largeur):
    """Polygone d'un faisceau de lyre partant de (ox, oy)."""
    import math
    ex, ey = ox + longueur * math.sin(angle), oy + longueur * math.cos(angle)
    px, py = math.cos(angle), -math.sin(angle)
    l0 = demi_largeur * 0.05
    return [ox - px * l0, oy - py * l0, ox + px * l0, oy + py * l0,
            ex + px * demi_largeur, ey + py * demi_largeur,
            ex - px * demi_largeur, ey - py * demi_largeur]


# --------------------------------------------------------------------------
# Fonds et montage 10x15 (300 dpi)
# --------------------------------------------------------------------------
FORMAT_PAYSAGE = (1800, 1200)
FORMAT_PORTRAIT = (1200, 1800)
FORMAT_BANDE = (600, 1800)          # bandelette 5x15 (2 bandelettes par feuille 10x15, coupe au milieu)


def est_bandelette(taille):
    return taille[1] >= taille[0] * 2.5


class Gabarit:
    """Un fond 10x15 et l'emplacement des photos.

    Les emplacements viennent du fichier « <fond>.disposition.json » créé avec
    l'éditeur de placement ; à défaut, des zones transparentes du PNG.
    """

    def __init__(self, chemin=None):
        self.chemin = chemin
        self.image = None
        self.devant = True             # True : le fond passe par-dessus les photos
        self.taille = FORMAT_PAYSAGE
        self.zones = [(0, 0, *FORMAT_PAYSAGE)]
        if chemin and os.path.isfile(chemin):
            img = ImageOps.exif_transpose(Image.open(chemin)).convert("RGBA")
            if img.height >= img.width * 2.5:                 # fond très allongé : bandelette 5x15
                self.taille = FORMAT_BANDE
            else:
                self.taille = FORMAT_PAYSAGE if img.width >= img.height else FORMAT_PORTRAIT
            self.image = self._rendre_opaque(ImageOps.fit(img, self.taille, Image.LANCZOS))
            if not self._lire_disposition():
                self.zones, self.devant = self.detecter_zones()
            if not self.a_transparence:          # fond plein : il ne peut que passer derrière les photos
                self.devant = False

    @staticmethod
    def _rendre_opaque(img):
        """Certains logiciels exportent le fond à moitié transparent : le noir devient gris.
        On rend opaque tout ce qui n'est pas un vrai trou (transparence quasi totale)."""
        a = np.array(img.getchannel("A"))
        demi = ((a >= 20) & (a <= 235)).mean()
        if demi > 0.05:
            log.info("Fond semi-transparent (%.0f %%) : rendu opaque", demi * 100)
            a = np.where(a < 20, 0, 255).astype(np.uint8)
            img.putalpha(Image.fromarray(a))
        return img

    @staticmethod
    def chemin_disposition(chemin_fond):
        return chemin_fond + ".disposition.json"

    @property
    def a_transparence(self):
        return self.image is not None and \
            bool((np.array(self.image.getchannel("A")) < 20).any())

    def _lire_disposition(self):
        try:
            with open(self.chemin_disposition(self.chemin), encoding="utf-8") as f:
                d = json.load(f)
            zones = [tuple(int(v) for v in z) for z in d["zones"] if z[2] > 10 and z[3] > 10]
            if not zones:
                return False
            self.zones = zones
            self.devant = bool(d.get("fond_devant", True))
            return True
        except FileNotFoundError:
            return False
        except Exception:
            log.exception("Disposition illisible")
            return False

    def sauver_disposition(self):
        with open(self.chemin_disposition(self.chemin), "w", encoding="utf-8") as f:
            json.dump({"zones": [list(z) for z in self.zones],
                       "fond_devant": self.devant}, f, indent=2)

    def effacer_disposition(self):
        try:
            os.remove(self.chemin_disposition(self.chemin))
        except FileNotFoundError:
            pass

    def detecter_zones(self):
        """Zones transparentes du PNG = emplacements photo (fond par-dessus)."""
        W, H = self.taille
        if self.image is None:
            return [(0, 0, W, H)], True
        masque = (np.array(self.image.getchannel("A")) < 20).astype(np.uint8)
        zones = []
        mini = W * H * 0.01
        if masque.any():
            if cv2 is not None:
                n, _, stats, _ = cv2.connectedComponentsWithStats(masque, connectivity=8)
                for i in range(1, n):
                    x, y, w, h, aire = [int(v) for v in stats[i]]
                    if aire >= mini:
                        zones.append((x, y, w, h))
            else:
                ys, xs = np.nonzero(masque)
                zones.append((int(xs.min()), int(ys.min()),
                              int(xs.max() - xs.min() + 1), int(ys.max() - ys.min() + 1)))
        if zones:
            zones.sort(key=lambda z: (z[1] // 80, z[0]))   # sens de lecture
            return zones, True
        m = int(min(W, H) * 0.06)        # pas de transparence : fond derrière
        return [(m, m, W - 2 * m, H - 2 * m)], False

    @property
    def nb_photos(self):
        return len(self.zones)

    def composer(self, photos):
        W, H = self.taille
        toile = Image.new("RGB", self.taille, "white")
        if self.image is not None and not self.devant:
            toile.paste(self.image.convert("RGB"))
        for (x, y, w, h), photo in zip(self.zones, photos):
            morceau = ImageOps.fit(photo.convert("RGB"), (w, h), Image.LANCZOS,
                                   centering=(0.5, 0.45))
            toile.paste(morceau, (x, y))     # Pillow rogne ce qui dépasse
        if self.image is not None and self.devant:
            toile.paste(self.image, (0, 0), self.image)
        return toile

    def apercu_exemple(self):
        """Montage avec des photos numérotées, pour visualiser les zones."""
        photos = []
        f = police_pil(260)
        for i in range(self.nb_photos):
            p = Image.new("RGB", (900, 600), (150 + 25 * (i % 4), 160, 185))
            d = ImageDraw.Draw(p)
            d.text((450, 300), str(i + 1), fill="white", font=f, anchor="mm")
            photos.append(p)
        return self.composer(photos)


def charger_photo(chemin):
    img = Image.open(chemin)
    img.draft("RGB", (3200, 3200))
    img = ImageOps.exif_transpose(img).convert("RGB")
    img.thumbnail((3200, 3200), Image.LANCZOS)
    return img


# --------------------------------------------------------------------------
# Appareils photo
# --------------------------------------------------------------------------
class CameraWebcam:
    reflex = False

    def __init__(self, index=0):
        if cv2 is None:
            raise RuntimeError("Le module opencv-python n'est pas installé.")
        api = cv2.CAP_DSHOW if os.name == "nt" else cv2.CAP_ANY
        self.cap = cv2.VideoCapture(int(index), api)
        if not self.cap.isOpened():
            raise RuntimeError(f"Webcam n°{index} introuvable.")
        self.cap.set(cv2.CAP_PROP_FRAME_WIDTH, 1920)
        self.cap.set(cv2.CAP_PROP_FRAME_HEIGHT, 1080)
        self._frame = None
        self.n_image = 0
        self._lock = threading.Lock()
        self._actif = True
        self._dernier = time.time()
        threading.Thread(target=self._boucle, daemon=True).start()

    def _boucle(self):
        while self._actif:
            ok, f = self.cap.read()
            if ok:
                with self._lock:
                    self._frame = f
                    self.n_image += 1
                maintenant = time.time()
                self._horodatages = [t for t in getattr(self, "_horodatages", [])
                                     if maintenant - t < 1] + [maintenant]
                self.fps_source = len(self._horodatages)
                self._dernier = time.time()
            else:
                time.sleep(0.05)

    def en_ligne(self):
        return time.time() - self._dernier < 8

    def demarrer_apercu(self):
        pass

    def arreter_apercu(self):
        pass

    def apercu(self):
        with self._lock:
            f = self._frame
        if f is None:
            return None
        return Image.fromarray(cv2.cvtColor(f, cv2.COLOR_BGR2RGB))

    def capturer(self, dossier, nom, au_declenchement=None):
        os.makedirs(dossier, exist_ok=True)
        if au_declenchement:
            au_declenchement()
        img = None
        for _ in range(60):
            img = self.apercu()
            if img is not None:
                break
            time.sleep(0.05)
        if img is None:
            raise RuntimeError("La webcam ne renvoie pas d'image.")
        chemin = os.path.join(dossier, nom + ".jpg")
        img.save(chemin, quality=95)
        return chemin

    def fermer(self):
        self._actif = False
        time.sleep(0.15)
        self.cap.release()


class CameraDigicam:
    """Canon EOS piloté par digiCamControl (serveur web activé, port 5513)."""
    reflex = True

    def __init__(self, url):
        self.url = url.rstrip("/")
        self._frame = None
        self.n_image = 0
        self._apercu_on = False
        self._actif = True
        try:
            self._requete("/", 3)
        except Exception:
            raise RuntimeError("digiCamControl ne répond pas. Lancez-le et activez "
                               "son serveur web (port 5513).")
        threading.Thread(target=self._boucle, daemon=True).start()

    def _requete(self, chemin, timeout=5):
        with urllib.request.urlopen(self.url + chemin, timeout=timeout) as r:
            return r.read()

    def _commande(self, cmd):
        try:
            self._requete("/?CMD=" + cmd, 5)
        except Exception as e:
            log.warning("Commande %s : %s", cmd, e)

    def en_ligne(self):
        try:
            self._requete("/", 3)
            return True
        except Exception:
            return False

    def demarrer_apercu(self):
        self._frame = None
        self._commande("LiveViewWnd_Show")
        self._apercu_on = True

    def arreter_apercu(self):
        self._apercu_on = False
        self._commande("LiveViewWnd_Hide")

    def _boucle(self):
        precedent = b""
        while self._actif:
            if self._apercu_on:
                try:
                    data = self._requete("/liveview.jpg", 2)
                    if data and data != precedent:       # nouvelle image seulement
                        precedent = data
                        maintenant = time.time()
                        self._horodatages = [t for t in getattr(self, "_horodatages", [])
                                             if maintenant - t < 1] + [maintenant]
                        self.fps_source = len(self._horodatages)
                        img = Image.open(io.BytesIO(data))
                        img.draft("RGB", (1920, 1080))
                        img = img.convert("RGB")
                        self._frame = img
                        self.n_image += 1
                    else:
                        time.sleep(0.01)
                except Exception:
                    time.sleep(0.3)
            else:
                time.sleep(0.1)

    def apercu(self):
        return self._frame if self._apercu_on else None

    @staticmethod
    def _jpegs(dossier):
        return {os.path.normcase(p) for p in glob.glob(os.path.join(dossier, "*"))
                if p.lower().endswith((".jpg", ".jpeg"))}

    def capturer(self, dossier, nom, au_declenchement=None):
        os.makedirs(dossier, exist_ok=True)
        try:
            self._requete("/?slc=set&param1=session.folder&param2="
                          + urllib.parse.quote(dossier), 5)
        except Exception as e:
            log.warning("Dossier de session digiCamControl : %s", e)
        avant = self._jpegs(dossier)
        t0 = time.time()
        self._requete("/?slc=capture&param1=&param2=", 30)
        if au_declenchement:          # l'obturateur vient de se déclencher
            au_declenchement()
        fichier = None
        while time.time() - t0 < 25:
            nouveaux = self._jpegs(dossier) - avant
            if nouveaux:
                fichier = max(nouveaux, key=os.path.getmtime)
                break
            try:
                r = self._requete("/?slc=get&param1=lastcaptured&param2=", 3)
                r = r.decode("utf-8", "ignore").strip()
                if r and not os.path.isabs(r):
                    r = os.path.join(dossier, r)
                if r.lower().endswith((".jpg", ".jpeg")) and os.path.isfile(r) \
                        and os.path.getmtime(r) >= t0 - 1:
                    fichier = r
                    break
            except Exception:
                pass
            time.sleep(0.3)
        if not fichier:
            raise RuntimeError("L'appareil n'a pas renvoyé de photo. Vérifiez qu'il est "
                               "réglé en JPEG et allumé.")
        taille = -1
        for _ in range(40):                      # attendre la fin de l'écriture
            t = os.path.getsize(fichier)
            if t == taille and t > 0:
                break
            taille = t
            time.sleep(0.15)
        dest = os.path.join(dossier, nom + os.path.splitext(fichier)[1].lower())
        meme_dossier = os.path.normcase(os.path.dirname(fichier)) == os.path.normcase(dossier)
        # digiCamControl garde parfois le fichier ouvert quelques instants (WinError 32) :
        # on réessaie de le renommer, sinon on en fait une copie.
        if meme_dossier:
            for _ in range(20):
                try:
                    os.replace(fichier, dest)
                    return dest
                except PermissionError:
                    time.sleep(0.25)
        for _ in range(40):
            try:
                shutil.copy2(fichier, dest)
                break
            except PermissionError:
                time.sleep(0.25)
        else:
            raise RuntimeError("La photo est restée bloquée par digiCamControl.")
        if meme_dossier:
            threading.Thread(target=self._effacer_plus_tard, args=(fichier,), daemon=True).start()
        return dest

    @staticmethod
    def _effacer_plus_tard(fichier):
        """Supprime le fichier d'origine en double dès que digiCamControl le libère."""
        for _ in range(60):
            try:
                os.remove(fichier)
                return
            except FileNotFoundError:
                return
            except OSError:
                time.sleep(1)

    def fermer(self):
        self._actif = False
        if self._apercu_on:
            self.arreter_apercu()


# --------------------------------------------------------------------------
# Canon en direct, avec le kit officiel Canon (EDSDK) : aperçu fluide, sans digiCamControl
# Fichiers nécessaires dans le dossier « EDSDK » du logiciel : EDSDK.dll et EdsImage.dll (64 bits)
# --------------------------------------------------------------------------
EDSDK_DIR = os.path.join(APP_DIR, "EDSDK")


def bits_dll(chemin):
    """32 ou 64 : version d'un fichier .dll (lu dans son en-tête)."""
    try:
        with open(chemin, "rb") as f:
            d = f.read(4096)
        pe = int.from_bytes(d[0x3C:0x40], "little")
        machine = int.from_bytes(d[pe + 4:pe + 6], "little")
        return {0x8664: 64, 0x14C: 32}.get(machine, 0)
    except Exception:
        return 0


def trouver_edsdk():
    """Cherche le kit Canon : dossier EDSDK du logiciel, puis celui installé avec digiCamControl.
    Retourne (chemin du dossier, message)."""
    bits = 64 if sys.maxsize > 2 ** 32 else 32
    dossiers = [EDSDK_DIR] + [os.path.dirname(c) for c in CHEMINS_DIGICAM]
    trouves = []
    for racine in dossiers:
        if not os.path.isdir(racine):
            continue
        for dossier, sous, fichiers in os.walk(racine):
            if dossier[len(racine):].count(os.sep) > 2:
                sous[:] = []
                continue
            if "EDSDK.dll" in fichiers or "edsdk.dll" in [f.lower() for f in fichiers]:
                nom = next(f for f in fichiers if f.lower() == "edsdk.dll")
                b = bits_dll(os.path.join(dossier, nom))
                if b == bits:
                    return dossier, ""
                trouves.append(f"{dossier} ({b} bits)")
    if trouves:
        return None, (f"Kit Canon trouvé mais en mauvaise version pour ce logiciel ({bits} bits) : "
                      + ", ".join(trouves))
    return None, "Kit Canon introuvable (ni dans le dossier EDSDK, ni avec digiCamControl)."


def edsdk_disponible():
    return trouver_edsdk()[0] is not None


class CameraCanon:
    reflex = True
    # Constantes du kit Canon (EDSDK 13.x)
    PROP_SAVE_TO, SAVE_TO_HOST = 0x0B, 2
    PROP_EVF_OUTPUT, PROP_EVF_MODE, EVF_PC = 0x500, 0x501, 2
    CMD_EXTEND_SHUTDOWN, CMD_PRESS_SHUTTER = 1, 4
    SHUTTER_OFF, SHUTTER_COMPLETELY = 0, 3
    OBJ_EVENT_ALL, OBJ_TRANSFER = 0x200, 0x208
    STATE_EVENT_ALL, STATE_SHUTDOWN = 0x300, 0x301
    ERR_NOT_READY, ERR_BUSY = 0xA102, 0x81

    def __init__(self):
        if os.name != "nt":
            raise RuntimeError("Le kit Canon ne fonctionne que sous Windows.")
        self.dossier_sdk, message = trouver_edsdk()
        if not self.dossier_sdk:
            raise RuntimeError(message)
        self._frame = None
        self.n_image = 0
        self.fps_source = 0
        self._horodatages = []
        self._apercu_voulu = False
        self._apercu_on = False
        self._actif = True
        self._en_ligne = False
        self._ordres = queue.Queue()
        self._telechargement = None          # (dossier, nom, Event, résultat)
        self._pret = threading.Event()
        self._erreur_demarrage = None
        threading.Thread(target=self._boucle, daemon=True).start()
        if not self._pret.wait(15):
            raise RuntimeError("Le kit Canon ne répond pas.")
        if self._erreur_demarrage:
            raise RuntimeError(self._erreur_demarrage)

    # ---- tout le dialogue avec l'appareil se fait dans ce fil ----
    def _boucle(self):
        import ctypes
        from ctypes import c_uint32, c_int32, c_uint64, c_void_p, byref, POINTER
        self.ct = ctypes
        try:
            ctypes.windll.ole32.CoInitializeEx(None, 2)
            os.add_dll_directory(self.dossier_sdk)
            sdk = ctypes.WinDLL(os.path.join(self.dossier_sdk, "EDSDK.dll"))
            log.info("Kit Canon chargé depuis %s", self.dossier_sdk)
            self.sdk = sdk
            for nom in ("EdsInitializeSDK", "EdsTerminateSDK", "EdsGetCameraList", "EdsGetChildCount",
                        "EdsGetChildAtIndex", "EdsOpenSession", "EdsCloseSession", "EdsRelease",
                        "EdsSetPropertyData", "EdsGetPropertyData", "EdsSendCommand", "EdsGetEvent",
                        "EdsCreateMemoryStream", "EdsCreateEvfImageRef", "EdsDownloadEvfImage",
                        "EdsGetPointer", "EdsGetLength", "EdsDownload", "EdsDownloadComplete",
                        "EdsGetDirectoryItemInfo", "EdsSetCapacity", "EdsSetObjectEventHandler",
                        "EdsSetCameraStateEventHandler"):
                getattr(sdk, nom).restype = c_uint32
            sdk.EdsGetLength.argtypes = [c_void_p, c_void_p]

            class Capacite(ctypes.Structure):
                _fields_ = [("clusters", c_int32), ("octets", c_int32), ("reset", c_int32)]

            self._verif(sdk.EdsInitializeSDK(), "démarrage du kit Canon")
            self._sdk_lance = True
            # Les versions récentes du kit comptent les tailles sur 64 bits, les anciennes sur 32.
            # En 32 bits, ctypes détecte sans danger un mauvais choix : on essaie 64, sinon 32.
            taille = c_uint64
            if sys.maxsize <= 2 ** 32:
                sdk.EdsCreateMemoryStream.argtypes = [c_uint64, POINTER(c_void_p)]
                essai = c_void_p()
                try:
                    if sdk.EdsCreateMemoryStream(0, byref(essai)) == 0 and essai:
                        sdk.EdsRelease(essai)
                except ValueError:
                    taille = c_uint32
            log.info("Kit Canon : tailles sur %s bits", 64 if taille is c_uint64 else 32)
            sdk.EdsCreateMemoryStream.argtypes = [taille, POINTER(c_void_p)]
            sdk.EdsDownload.argtypes = [c_void_p, taille, c_void_p]

            class InfoFichier(ctypes.Structure):
                _fields_ = [("size", taille), ("isFolder", c_int32), ("groupID", c_uint32),
                            ("option", c_uint32), ("szFileName", ctypes.c_char * 256),
                            ("format", c_uint32), ("dateTime", c_uint32)]
            self.InfoFichier = InfoFichier
            liste, nb = c_void_p(), c_uint32()
            self._verif(sdk.EdsGetCameraList(byref(liste)), "liste des appareils")
            sdk.EdsGetChildCount(liste, byref(nb))
            if nb.value == 0:
                sdk.EdsRelease(liste)
                raise RuntimeError("Aucun appareil Canon détecté. Est-il allumé et branché en USB ?")
            self.cam = c_void_p()
            sdk.EdsGetChildAtIndex(liste, 0, byref(self.cam))
            sdk.EdsRelease(liste)

            RAPPEL = ctypes.WINFUNCTYPE(c_uint32, c_uint32, c_void_p, c_void_p)
            RAPPEL_ETAT = ctypes.WINFUNCTYPE(c_uint32, c_uint32, c_uint32, c_void_p)
            self._rappel_objet = RAPPEL(self._evenement_objet)
            self._rappel_etat = RAPPEL_ETAT(self._evenement_etat)
            sdk.EdsSetObjectEventHandler(self.cam, self.OBJ_EVENT_ALL, self._rappel_objet, None)
            sdk.EdsSetCameraStateEventHandler(self.cam, self.STATE_EVENT_ALL, self._rappel_etat, None)
            self._verif(sdk.EdsOpenSession(self.cam), "ouverture de la session avec l'appareil")
            self._set_prop(self.PROP_SAVE_TO, self.SAVE_TO_HOST)        # photos envoyées au PC
            sdk.EdsSetCapacity(self.cam, Capacite(0x7FFFFFFF, 0x1000, 1))
            self._en_ligne = True
        except Exception as e:
            self._erreur_demarrage = str(e)
            log.exception("Kit Canon")
            try:
                if getattr(self, "_sdk_lance", False):
                    self.sdk.EdsTerminateSDK()
            except Exception:
                pass
            self._pret.set()
            return
        self._pret.set()
        log.info("Appareil Canon connecté en direct (EDSDK)")

        dernier_reveil = time.time()
        while self._actif:
            try:
                while True:                               # ordres venant du logiciel
                    ordre = self._ordres.get_nowait()
                    ordre()
            except queue.Empty:
                pass
            sdk.EdsGetEvent()                             # fait arriver les photos prises
            if self._apercu_voulu != self._apercu_on:
                self._basculer_apercu(self._apercu_voulu)
            if self._apercu_on:
                self._lire_apercu()
            else:
                time.sleep(0.03)
            if time.time() - dernier_reveil > 30:         # empêche la mise en veille
                sdk.EdsSendCommand(self.cam, self.CMD_EXTEND_SHUTDOWN, 0)
                dernier_reveil = time.time()
        try:
            if self._apercu_on:
                self._basculer_apercu(False)
            sdk.EdsCloseSession(self.cam)
            sdk.EdsRelease(self.cam)
            sdk.EdsTerminateSDK()
        except Exception:
            pass

    def _verif(self, err, quoi):
        if err:
            raise RuntimeError(f"Kit Canon : erreur 0x{err:X} ({quoi}).")

    def _set_prop(self, prop, valeur):
        v = self.ct.c_uint32(valeur)
        return self.sdk.EdsSetPropertyData(self.cam, prop, 0, 4, self.ct.byref(v))

    def _get_prop(self, prop):
        v = self.ct.c_uint32()
        self.sdk.EdsGetPropertyData(self.cam, prop, 0, 4, self.ct.byref(v))
        return v.value

    def _basculer_apercu(self, actif):
        if actif:
            self._set_prop(self.PROP_EVF_MODE, 1)
            sortie = self._get_prop(self.PROP_EVF_OUTPUT) | self.EVF_PC
        else:
            sortie = self._get_prop(self.PROP_EVF_OUTPUT) & ~self.EVF_PC
        err = self._set_prop(self.PROP_EVF_OUTPUT, sortie)
        if err in (0,):
            self._apercu_on = actif
        elif err != self.ERR_BUSY:
            log.warning("Aperçu Canon : erreur 0x%X", err)
            self._apercu_on = actif
        else:
            time.sleep(0.1)

    def _lire_apercu(self):
        ct, sdk = self.ct, self.sdk
        flux, evf = ct.c_void_p(), ct.c_void_p()
        try:
            if sdk.EdsCreateMemoryStream(0, ct.byref(flux)):
                return
            if sdk.EdsCreateEvfImageRef(flux, ct.byref(evf)):
                return
            err = sdk.EdsDownloadEvfImage(self.cam, evf)
            if err:
                time.sleep(0.02 if err == self.ERR_NOT_READY else 0.1)
                return
            ptr, longueur = ct.c_void_p(), ct.c_uint64()
            sdk.EdsGetPointer(flux, ct.byref(ptr))
            sdk.EdsGetLength(flux, ct.byref(longueur))
            data = ct.string_at(ptr, longueur.value)
            img = Image.open(io.BytesIO(data))
            img.draft("RGB", (1920, 1080))
            self._frame = img.convert("RGB")
            self.n_image += 1
            maintenant = time.time()
            self._horodatages = [t for t in self._horodatages if maintenant - t < 1] + [maintenant]
            self.fps_source = len(self._horodatages)
        except Exception as e:
            log.warning("Aperçu Canon : %s", e)
        finally:
            if evf:
                sdk.EdsRelease(evf)
            if flux:
                sdk.EdsRelease(flux)

    def _evenement_objet(self, evenement, ref, contexte):
        try:
            if evenement == self.OBJ_TRANSFER and ref:
                self._recevoir_photo(ref)
            elif ref:
                self.sdk.EdsRelease(ref)
        except Exception:
            log.exception("Réception de la photo")
        return 0

    def _evenement_etat(self, evenement, parametre, contexte):
        if evenement == self.STATE_SHUTDOWN:
            log.warning("Appareil Canon déconnecté")
            self._en_ligne = False
            self._actif = False
        return 0

    def _recevoir_photo(self, ref):
        ct, sdk = self.ct, self.sdk
        info = self.InfoFichier()
        sdk.EdsGetDirectoryItemInfo(ref, ct.byref(info))
        flux = ct.c_void_p()
        sdk.EdsCreateMemoryStream(info.size, ct.byref(flux))
        err = sdk.EdsDownload(ref, info.size, flux)
        sdk.EdsDownloadComplete(ref)
        attente = self._telechargement
        try:
            if err:
                raise RuntimeError(f"Téléchargement de la photo : erreur 0x{err:X}")
            ptr, longueur = ct.c_void_p(), ct.c_uint64()
            sdk.EdsGetPointer(flux, ct.byref(ptr))
            sdk.EdsGetLength(flux, ct.byref(longueur))
            data = ct.string_at(ptr, longueur.value)
            if attente is None:
                log.warning("Photo reçue sans demande : ignorée")
                return
            dossier, nom, evt, resultat = attente
            ext = os.path.splitext(info.szFileName.decode("ascii", "ignore"))[1].lower() or ".jpg"
            chemin = os.path.join(dossier, nom + ext)
            with open(chemin, "wb") as f:
                f.write(data)
            resultat["chemin"] = chemin
        except Exception as e:
            if attente:
                attente[3]["erreur"] = str(e)
        finally:
            sdk.EdsRelease(flux)
            sdk.EdsRelease(ref)
            if attente:
                attente[2].set()

    # ---- interface commune avec les autres appareils ----
    def en_ligne(self):
        return self._en_ligne and self._actif

    def demarrer_apercu(self):
        self._frame = None
        self._apercu_voulu = True

    def arreter_apercu(self):
        self._apercu_voulu = False

    def apercu(self):
        return self._frame if self._apercu_on else None

    def capturer(self, dossier, nom, au_declenchement=None):
        if not self.en_ligne():
            raise RuntimeError("L'appareil Canon n'est plus connecté.")
        os.makedirs(dossier, exist_ok=True)
        evt, resultat = threading.Event(), {}
        self._telechargement = (dossier, nom, evt, resultat)
        declenche = threading.Event()

        def declencher():
            err = self.sdk.EdsSendCommand(self.cam, self.CMD_PRESS_SHUTTER, self.SHUTTER_COMPLETELY)
            self.sdk.EdsSendCommand(self.cam, self.CMD_PRESS_SHUTTER, self.SHUTTER_OFF)
            resultat["err_declenchement"] = err
            declenche.set()
        self._ordres.put(declencher)
        if not declenche.wait(15):
            raise RuntimeError("L'appareil n'a pas déclenché.")
        if resultat.get("err_declenchement"):
            self._telechargement = None
            raise RuntimeError(f"Déclenchement refusé (erreur 0x{resultat['err_declenchement']:X}) : "
                               "mise au point impossible ? Essayez l'objectif en MF.")
        if au_declenchement:
            au_declenchement()
        if not evt.wait(30):
            self._telechargement = None
            raise RuntimeError("La photo n'est pas arrivée sur l'ordinateur.")
        self._telechargement = None
        if "erreur" in resultat:
            raise RuntimeError(resultat["erreur"])
        return resultat["chemin"]

    def fermer(self):
        self._actif = False
        time.sleep(0.3)


def creer_camera(cfg):
    if cfg["camera"] == "webcam":
        return CameraWebcam(cfg["webcam_index"])
    if cfg["camera"] == "canon":
        return CameraCanon()
    return CameraDigicam(cfg["digicam_url"])


# --------------------------------------------------------------------------
# Impression
# --------------------------------------------------------------------------
def liste_imprimantes():
    if not HAS_WIN32:
        return []
    drapeaux = win32print.PRINTER_ENUM_LOCAL | win32print.PRINTER_ENUM_CONNECTIONS
    return [p[2] for p in win32print.EnumPrinters(drapeaux)]


def feuille_bandelettes(bande):
    """Deux bandelettes identiques côte à côte sur une feuille 10x15 portrait (coupée en deux)."""
    bande = ImageOps.fit(bande.convert("RGB"), FORMAT_BANDE, Image.LANCZOS)
    feuille = Image.new("RGB", FORMAT_PORTRAIT, "white")
    feuille.paste(bande, (0, 0))
    feuille.paste(bande, (FORMAT_BANDE[0], 0))
    return feuille


def forme_bandelette(nom_imprimante, forme_choisie=""):
    """Nom du format « 2 x 5x15 avec coupe » du pilote (ex. DNP : « (PC)2x6 x2 »)."""
    if forme_choisie:
        return forme_choisie
    try:
        h = win32print.OpenPrinter(nom_imprimante)
        try:
            noms = [f["Name"] for f in win32print.EnumForms(h)]
        finally:
            win32print.ClosePrinter(h)
    except Exception:
        return ""
    def compact(n):
        return n.lower().replace(" ", "").replace("\"", "").replace("-", "")
    indices = ("2x6", "5x15", "50x150", "51x152", "2inch", "2in", "cut", "coupe", "strip", "bande")
    for n in noms:                       # d'abord un format qui parle de bandelettes ET de 2 par feuille
        c = compact(n)
        if any(i in c for i in indices) and ("x2" in c or "cut" in c or "coupe" in c or "2inch" in c):
            return n
    return next((n for n in noms if any(i in compact(n) for i in indices)), "")


def imprimer_photo(chemin_ou_image, imprimante="", copies=1, forme=""):
    """Imprime une photo. forme : nom d'un format papier du pilote (bandelettes), sinon celui par défaut."""
    if not HAS_WIN32:
        raise RuntimeError("Le module pywin32 n'est pas installé.")
    img = chemin_ou_image if isinstance(chemin_ou_image, Image.Image) \
        else Image.open(chemin_ou_image)
    img = img.convert("RGB")
    nom = imprimante or win32print.GetDefaultPrinter()
    hdc = None
    if forme:
        try:
            import win32gui
            h = win32print.OpenPrinter(nom)
            try:
                dm = win32print.GetPrinter(h, 2)["pDevMode"]
            finally:
                win32print.ClosePrinter(h)
            dm.FormName = forme
            dm.Fields |= 0x00010000                                   # DM_FORMNAME
            hdc = win32ui.CreateDCFromHandle(win32gui.CreateDC("WINSPOOL", nom, dm))
            log.info("Impression au format « %s »", forme)
        except Exception as e:
            log.warning("Format « %s » impossible (%s) : format par défaut", forme, e)
            hdc = None
    if hdc is None:
        hdc = win32ui.CreateDC()
        hdc.CreatePrinterDC(nom)
    try:
        pw = hdc.GetDeviceCaps(win32con.HORZRES)
        ph = hdc.GetDeviceCaps(win32con.VERTRES)
        if (pw > ph) != (img.width > img.height):
            img = img.rotate(90, expand=True)
        img = ImageOps.fit(img, (pw, ph), Image.LANCZOS)   # sans bord blanc
        dib = ImageWin.Dib(img)
        for _ in range(max(1, int(copies))):
            hdc.StartDoc("Photobooth")
            hdc.StartPage()
            dib.draw(hdc.GetHandleOutput(), (0, 0, pw, ph))
            hdc.EndPage()
            hdc.EndDoc()
    finally:
        hdc.DeleteDC()
    log.info("Impression %s x%s sur %s", getattr(chemin_ou_image, "filename", chemin_ou_image), copies, nom)


# --------------------------------------------------------------------------
# Partage : QR code (Wi-Fi local ou FTP) et e-mail
# --------------------------------------------------------------------------
def ip_locale():
    s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    try:
        s.connect(("10.255.255.255", 1))
        return s.getsockname()[0]
    except Exception:
        return "127.0.0.1"
    finally:
        s.close()


class _Handler(http.server.SimpleHTTPRequestHandler):
    def list_directory(self, path):          # pas de liste des photos
        self.send_error(403, "Accès refusé")
        return None

    def log_message(self, *args):
        pass


class ServeurLocal:
    def __init__(self, port):
        self.port = int(port)
        handler = functools.partial(_Handler, directory=MONT_DIR)
        self.httpd = http.server.ThreadingHTTPServer(("", self.port), handler)
        threading.Thread(target=self.httpd.serve_forever, daemon=True).start()

    def url_pour(self, chemin):
        rel = os.path.relpath(chemin, MONT_DIR).replace(os.sep, "/")
        return f"http://{ip_locale()}:{self.port}/" + urllib.parse.quote(rel)

    def arreter(self):
        self.httpd.shutdown()
        self.httpd.server_close()


def envoyer_ftp(cfg, chemin):
    nom = uuid.uuid4().hex[:12] + os.path.splitext(chemin)[1]
    with ftplib.FTP(cfg["ftp_hote"], timeout=20) as ftp:
        ftp.login(cfg["ftp_utilisateur"], cfg["ftp_mot_de_passe"])
        dossier = cfg["ftp_dossier"].strip()
        if dossier.startswith("/"):
            ftp.cwd("/")
        for part in [p for p in dossier.split("/") if p]:
            try:
                ftp.cwd(part)
            except ftplib.error_perm:
                ftp.mkd(part)
                ftp.cwd(part)
        with open(chemin, "rb") as f:
            ftp.storbinary("STOR " + nom, f)
    return cfg["url_publique"].rstrip("/") + "/" + nom


def envoyer_email(cfg, dest, chemin):
    msg = EmailMessage()
    msg["Subject"] = cfg["email_sujet"]
    msg["From"] = cfg["email_expediteur"] or cfg["smtp_utilisateur"]
    msg["To"] = dest
    texte = cfg["email_message"]
    if cfg.get("lien_avis", "").strip():
        texte += ("\n\n⭐ Vous avez aimé le photobooth ? Laissez-nous un avis, ça nous aide beaucoup :\n"
                  + cfg["lien_avis"].strip())
    msg.set_content(texte)
    with open(chemin, "rb") as f:
        msg.add_attachment(f.read(), maintype="image", subtype="jpeg",
                           filename=os.path.basename(chemin))
    hote = cfg["smtp_hote"].strip()
    utilisateur = cfg["smtp_utilisateur"].strip()
    mdp = cfg["smtp_mot_de_passe"].replace(" ", "") if "gmail" in hote.lower() else cfg["smtp_mot_de_passe"]
    if not hote or not utilisateur or not mdp:
        raise RuntimeError("Renseignez le serveur, l'identifiant et le mot de passe.")
    port = int(cfg["smtp_port"])
    # On essaie le port choisi, puis l'autre (587 <-> 465) : beaucoup d'erreurs viennent de là.
    essais = [port] + [p for p in (587, 465) if p != port]
    derniere = None
    for p in essais:
        try:
            if p == 465:
                srv = smtplib.SMTP_SSL(hote, p, timeout=30)
            else:
                srv = smtplib.SMTP(hote, p, timeout=30)
                srv.starttls()
            with srv:
                srv.login(utilisateur, mdp)
                srv.send_message(msg)
            log.info("E-mail envoyé à %s (port %s)", dest, p)
            return
        except smtplib.SMTPAuthenticationError:
            raise RuntimeError("Identifiant ou mot de passe refusé par le serveur. Avec Gmail, il faut "
                               "un « mot de passe d'application » de 16 lettres, pas le mot de passe "
                               "habituel.")
        except (smtplib.SMTPServerDisconnected, ConnectionError, socket.timeout, OSError,
                smtplib.SMTPException) as e:
            derniere = e
            log.warning("SMTP %s:%s : %s", hote, p, e)
    raise RuntimeError(f"Impossible de joindre le serveur d'envoi {hote} (ports 587 et 465 essayés). "
                       "Vérifiez le nom du serveur, la connexion internet, et qu'aucun antivirus ne "
                       f"bloque l'envoi d'e-mails. Détail : {derniere}")


class FileEmails:
    """Les e-mails sont mis en file d'attente : sans internet, ils partent plus tard."""

    def __init__(self, app):
        self.app = app
        self.evt = threading.Event()
        threading.Thread(target=self._boucle, daemon=True).start()

    def ajouter(self, dest, chemin):
        job = {"dest": dest, "photo": chemin, "date": datetime.now().isoformat()}
        with open(os.path.join(ATTENTE_DIR, f"{time.time_ns()}.json"), "w", encoding="utf-8") as f:
            json.dump(job, f, ensure_ascii=False)
        self.evt.set()

    def en_attente(self):
        return len(glob.glob(os.path.join(ATTENTE_DIR, "*.json")))

    def relancer(self):
        self.evt.set()

    def _boucle(self):
        while True:
            self.evt.wait(60)
            self.evt.clear()
            for p in sorted(glob.glob(os.path.join(ATTENTE_DIR, "*.json"))):
                try:
                    with open(p, encoding="utf-8") as f:
                        job = json.load(f)
                    envoyer_email(self.app.cfg, job["dest"], job["photo"])
                    os.remove(p)
                except Exception as e:
                    log.warning("E-mail non envoyé (nouvel essai plus tard) : %s", e)
                    break


# --------------------------------------------------------------------------
# Verrouillage du clavier (touche Windows, Alt+Tab, Alt+F4, Ctrl+Échap)
# --------------------------------------------------------------------------
def installer_verrou(est_actif):
    """est_actif() est appelée à chaque touche : True = on bloque."""
    if os.name != "nt":
        return None
    import ctypes
    from ctypes import wintypes
    user32 = ctypes.WinDLL("user32", use_last_error=True)
    kernel32 = ctypes.WinDLL("kernel32", use_last_error=True)
    LRESULT = ctypes.c_ssize_t

    class KBD(ctypes.Structure):
        _fields_ = [("vkCode", wintypes.DWORD), ("scanCode", wintypes.DWORD),
                    ("flags", wintypes.DWORD), ("time", wintypes.DWORD),
                    ("dwExtraInfo", ctypes.c_size_t)]

    HOOKPROC = ctypes.WINFUNCTYPE(LRESULT, ctypes.c_int, wintypes.WPARAM, wintypes.LPARAM)
    user32.SetWindowsHookExW.argtypes = [ctypes.c_int, HOOKPROC, wintypes.HINSTANCE, wintypes.DWORD]
    user32.SetWindowsHookExW.restype = wintypes.HHOOK
    user32.CallNextHookEx.argtypes = [wintypes.HHOOK, ctypes.c_int, wintypes.WPARAM, wintypes.LPARAM]
    user32.CallNextHookEx.restype = LRESULT
    kernel32.GetModuleHandleW.restype = wintypes.HMODULE

    def proc(n, wp, lp):
        try:
            if n == 0 and est_actif():
                kb = ctypes.cast(lp, ctypes.POINTER(KBD)).contents
                vk, alt = kb.vkCode, kb.flags & 0x20
                ctrl = user32.GetAsyncKeyState(0x11) & 0x8000
                if vk in (0x5B, 0x5C):                    # touches Windows
                    return 1
                if alt and vk in (0x09, 0x1B, 0x73):      # Alt+Tab, Alt+Échap, Alt+F4
                    return 1
                if ctrl and vk == 0x1B:                   # Ctrl+Échap
                    return 1
        except Exception:
            pass
        return user32.CallNextHookEx(None, n, wp, lp)

    rappel = HOOKPROC(proc)
    etat = {"hook": None, "thread": None, "rappel": rappel}

    def boucle():
        etat["thread"] = kernel32.GetCurrentThreadId()
        h = user32.SetWindowsHookExW(13, rappel, kernel32.GetModuleHandleW(None), 0)
        if not h:
            log.warning("Verrouillage clavier indisponible")
            return
        etat["hook"] = h
        msg = wintypes.MSG()
        while user32.GetMessageW(ctypes.byref(msg), None, 0, 0) > 0:
            user32.TranslateMessage(ctypes.byref(msg))
            user32.DispatchMessageW(ctypes.byref(msg))
        user32.UnhookWindowsHookEx(h)
        etat["hook"] = None
    threading.Thread(target=boucle, daemon=True).start()

    def retirer():
        """Rend le clavier à Windows (appelé à la fermeture et en cas d'erreur)."""
        try:
            if etat["hook"]:
                user32.UnhookWindowsHookEx(etat["hook"])
                etat["hook"] = None
            if etat["thread"]:
                user32.PostThreadMessageW(etat["thread"], 0x0012, 0, 0)   # WM_QUIT
        except Exception:
            pass
    etat["retirer"] = retirer
    return etat


# --------------------------------------------------------------------------
# Sons (bips du compte à rebours, déclencheur) : remplaçables par vos .wav
# --------------------------------------------------------------------------
SONS_DIR = os.path.join(DATA_DIR, "Sons")


def creer_sons():
    import wave, struct
    os.makedirs(SONS_DIR, exist_ok=True)
    taux = 44100

    def ecrire(nom, echantillons):
        chemin = os.path.join(SONS_DIR, nom)
        if os.path.isfile(chemin):
            return
        with wave.open(chemin, "w") as w:
            w.setnchannels(1)
            w.setsampwidth(2)
            w.setframerate(taux)
            w.writeframes(b"".join(struct.pack("<h", int(max(-1, min(1, v)) * 30000)) for v in echantillons))

    def bip(freq, duree):
        n = int(taux * duree)
        return [math.sin(2 * math.pi * freq * i / taux) * min(1, i / 300, (n - i) / 900) * 0.6
                for i in range(n)]
    ecrire("bip.wav", bip(880, 0.12))
    random.seed(1)
    n = int(taux * 0.16)
    declic = [random.uniform(-1, 1) * math.exp(-i / (taux * 0.012)) for i in range(n // 2)] + \
             [random.uniform(-1, 1) * 0.6 * math.exp(-i / (taux * 0.02)) for i in range(n // 2)]
    ecrire("declic.wav", declic)


def jouer_son(nom):
    if os.name != "nt":
        return
    try:
        import winsound
        winsound.PlaySound(os.path.join(SONS_DIR, nom), winsound.SND_FILENAME | winsound.SND_ASYNC)
    except Exception:
        pass


FILTRES = ("aucun", "noir et blanc", "vintage")


def appliquer_filtre(img, filtre):
    if filtre == "noir et blanc":
        return ImageOps.autocontrast(ImageOps.grayscale(img), cutoff=1).convert("RGB")
    if filtre == "vintage":
        gris = ImageOps.autocontrast(ImageOps.grayscale(img), cutoff=1)
        return ImageOps.colorize(gris, "#2B1B10", "#F4E6CC", mid="#9C7A57")
    return img


def copier_secours(cfg, chemin):
    """Copie de sécurité d'une photo dans le dossier de secours (clé USB, 2e disque…)."""
    dest_racine = (cfg.get("dossier_secours") or "").strip()
    if not dest_racine:
        return

    def travail():
        try:
            if not os.path.isdir(dest_racine):
                raise FileNotFoundError(f"Dossier de secours absent : {dest_racine}")
            dest = os.path.join(dest_racine, "Photobooth", os.path.relpath(chemin, PHOTOS_DIR))
            os.makedirs(os.path.dirname(dest), exist_ok=True)
            shutil.copy2(chemin, dest)
        except Exception as e:
            log.warning("Copie de secours : %s", e)
    threading.Thread(target=travail, daemon=True).start()


def dossiers_evenement(cfg, racine=MONT_DIR):
    """Dossiers de photos de l'événement en cours (il peut passer minuit)."""
    nom = nom_dossier(cfg.get("evenement", ""))
    if not os.path.isdir(racine):
        return []
    if nom:
        return sorted(os.path.join(racine, d) for d in os.listdir(racine)
                      if d.endswith(" - " + nom) and os.path.isdir(os.path.join(racine, d)))
    jour = os.path.join(racine, datetime.now().strftime("%Y-%m-%d"))
    return [jour] if os.path.isdir(jour) else []


def photos_evenement(cfg):
    fichiers = []
    for d in dossiers_evenement(cfg):
        fichiers += [os.path.join(d, f) for f in os.listdir(d) if f.lower().endswith(".jpg")]
    return sorted(fichiers, key=os.path.getmtime)


PAGE_GALERIE = """<!doctype html><html lang="fr"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1"><title>{titre}</title>
<style>
body{{margin:0;background:{fond};color:#fff;font-family:system-ui,Segoe UI,Roboto,sans-serif}}
header{{padding:32px 16px 8px;text-align:center}}
h1{{margin:0;font-size:clamp(26px,5vw,44px);background:linear-gradient(90deg,{c3},{c2});
-webkit-background-clip:text;background-clip:text;color:transparent}}
p{{color:#aab;margin:8px 0 0}}
main{{display:grid;grid-template-columns:repeat(auto-fill,minmax(260px,1fr));gap:14px;padding:20px}}
a{{display:block;border-radius:10px;overflow:hidden;box-shadow:0 0 18px {c1}55}}
img{{width:100%;display:block}}
footer{{text-align:center;color:#889;padding:24px;font-size:14px}}
a.avis{{display:inline-block;box-shadow:none;margin:6px auto 0;padding:12px 22px;border-radius:30px;color:#fff;
text-decoration:none;font-weight:700;background:linear-gradient(90deg,{c1},{c2})}}
</style></head><body><header><h1>{titre}</h1><p>{nb} photos · touchez une photo pour la télécharger</p>
{avis}</header><main>{images}</main><footer>{pied}</footer></body></html>"""


def publier_galerie(cfg, progression=None):
    """Envoie toutes les photos de l'événement + une page web. Retourne (url, dossier)."""
    photos = photos_evenement(cfg)
    if not photos:
        raise RuntimeError("Aucune photo pour cet événement.")
    dossier = cfg.get("galerie_dossier") or (
        (nom_dossier(cfg.get("evenement", "")) or datetime.now().strftime("%Y-%m-%d"))
        .lower().replace(" ", "-") + "-" + uuid.uuid4().hex[:8])
    dossier = re.sub(r"[^a-z0-9\-]", "", dossier.encode("ascii", "ignore").decode())
    base = cfg["url_publique"].rstrip("/") + "/galeries/" + dossier
    with ftplib.FTP(cfg["ftp_hote"], timeout=30) as ftp:
        ftp.login(cfg["ftp_utilisateur"], cfg["ftp_mot_de_passe"])
        chemin_ftp = cfg["ftp_dossier"].strip()
        if chemin_ftp.startswith("/"):
            ftp.cwd("/")
        for part in [p for p in chemin_ftp.split("/") if p] + ["galeries", dossier]:
            try:
                ftp.cwd(part)
            except ftplib.error_perm:
                ftp.mkd(part)
                ftp.cwd(part)
        try:
            deja = set(ftp.nlst())
        except ftplib.error_perm:
            deja = set()
        for i, p in enumerate(photos):
            nom = os.path.basename(p)
            if nom not in deja:
                with open(p, "rb") as f:
                    ftp.storbinary("STOR " + nom, f)
            if progression:
                progression(i + 1, len(photos))
        images = "".join(f'<a href="{os.path.basename(p)}" download><img loading="lazy" '
                         f'src="{os.path.basename(p)}" alt=""></a>' for p in reversed(photos))
        lien = cfg.get("lien_avis", "").strip()
        avis = (f'<p><a class="avis" href="{lien}" target="_blank" rel="noopener">⭐ Laissez-nous un avis Google</a></p>'
                if lien else "")
        page = PAGE_GALERIE.format(titre=cfg.get("evenement") or "Vos photos", nb=len(photos), avis=avis,
                                   images=images, pied=cfg.get("pied_accueil", ""),
                                   fond=cfg["couleur_fond"], c1=cfg["couleur_1"],
                                   c2=cfg["couleur_2"], c3=cfg["couleur_3"])
        ftp.storbinary("STOR index.html", io.BytesIO(page.encode("utf-8")))
    return base + "/", dossier


# --------------------------------------------------------------------------
# Mode « Prestation » : Windows reste éveillé, silencieux et à pleine puissance
# --------------------------------------------------------------------------
class ModePrestation:
    HAUTES_PERF = "8c5e7fda-e8bf-4a96-9a85-a6e23a8c635c"

    def __init__(self):
        self.ancien_plan = None
        self.ancien_toasts = None
        self.actif = False

    @staticmethod
    def _cmd(args):
        import subprocess
        return subprocess.run(args, capture_output=True, text=True, timeout=10,
                              creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))

    def activer(self, cfg):
        if os.name != "nt":
            return
        import ctypes
        self.actif = True
        if cfg.get("mode_prestation", True):
            # PC et écran ne se mettent plus en veille tant que le Photobooth tourne
            ctypes.windll.kernel32.SetThreadExecutionState(0x80000000 | 0x00000001 | 0x00000002)
            # notifications Windows coupées (restaurées à la fermeture)
            try:
                import winreg
                cle = winreg.CreateKey(winreg.HKEY_CURRENT_USER,
                                       r"Software\Microsoft\Windows\CurrentVersion\Notifications\Settings")
                try:
                    self.ancien_toasts = winreg.QueryValueEx(cle, "NOC_GLOBAL_SETTING_TOASTS_ENABLED")[0] or None
                except OSError:
                    self.ancien_toasts = None       # (0 = laissé par un arrêt brutal : on rétablira)
                winreg.SetValueEx(cle, "NOC_GLOBAL_SETTING_TOASTS_ENABLED", 0, winreg.REG_DWORD, 0)
                winreg.CloseKey(cle)
            except Exception as e:
                log.warning("Notifications : %s", e)
        if cfg.get("hautes_performances", True):
            try:
                r = self._cmd(["powercfg", "/getactivescheme"])
                m = re.search(r"([0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12})", r.stdout)
                if m and m.group(1) != self.HAUTES_PERF:
                    self.ancien_plan = m.group(1)
                    if self._cmd(["powercfg", "/setactive", self.HAUTES_PERF]).returncode != 0:
                        self.ancien_plan = None              # plan absent sur ce PC : on n'insiste pas
                ctypes.windll.kernel32.SetPriorityClass(ctypes.windll.kernel32.GetCurrentProcess(), 0x80)
            except Exception as e:
                log.warning("Hautes performances : %s", e)
        log.info("Mode prestation actif")

    def desactiver(self):
        if os.name != "nt" or not self.actif:
            return
        import ctypes
        self.actif = False
        try:
            ctypes.windll.kernel32.SetThreadExecutionState(0x80000000)
        except Exception:
            pass
        try:
            import winreg
            cle = winreg.CreateKey(winreg.HKEY_CURRENT_USER,
                                   r"Software\Microsoft\Windows\CurrentVersion\Notifications\Settings")
            if self.ancien_toasts is None:
                try:
                    winreg.DeleteValue(cle, "NOC_GLOBAL_SETTING_TOASTS_ENABLED")
                except OSError:
                    pass
            else:
                winreg.SetValueEx(cle, "NOC_GLOBAL_SETTING_TOASTS_ENABLED", 0, winreg.REG_DWORD,
                                  self.ancien_toasts)
            winreg.CloseKey(cle)
        except Exception:
            pass
        if self.ancien_plan:
            try:
                self._cmd(["powercfg", "/setactive", self.ancien_plan])
            except Exception:
                pass
            self.ancien_plan = None


def bloquer_gestes_bord(hwnd):
    """Empêche les glissements depuis les bords de l'écran tactile (notifications, widgets,
    barre des tâches) tant que la fenêtre du Photobooth est en plein écran."""
    if os.name != "nt" or not hwnd:
        return False
    import ctypes
    from ctypes import c_void_p, c_ushort, c_ubyte, c_uint32, byref, POINTER, WINFUNCTYPE, c_long

    class GUID(ctypes.Structure):
        _fields_ = [("a", c_uint32), ("b", c_ushort), ("c", c_ushort), ("d", c_ubyte * 8)]

    class PROPERTYKEY(ctypes.Structure):
        _fields_ = [("fmtid", GUID), ("pid", c_uint32)]

    class PROPVARIANT(ctypes.Structure):
        _fields_ = [("vt", c_ushort), ("r1", c_ushort), ("r2", c_ushort), ("r3", c_ushort),
                    ("donnees", c_ubyte * 16)]

    def guid(texte):
        g = GUID()
        ctypes.windll.ole32.CLSIDFromString(ctypes.c_wchar_p(texte), byref(g))
        return g
    try:
        ctypes.windll.ole32.CoInitialize(None)
        iid = guid("{886D8EEB-8CF2-4446-8D02-CDBA1DBDCF99}")                 # IPropertyStore
        cle = PROPERTYKEY(guid("{32CE38B2-2C9A-41B1-9BC5-B3784394AA44}"), 2)  # DisableTouchWhenFullscreen
        valeur = PROPVARIANT()
        valeur.vt = 11                                                      # VT_BOOL
        valeur.donnees[0] = valeur.donnees[1] = 0xFF                        # VARIANT_TRUE
        magasin = c_void_p()
        if ctypes.windll.shell32.SHGetPropertyStoreForWindow(c_void_p(hwnd), byref(iid), byref(magasin)) != 0:
            return False
        vtbl = ctypes.cast(magasin, POINTER(POINTER(c_void_p)))[0]
        set_value = WINFUNCTYPE(c_long, c_void_p, POINTER(PROPERTYKEY), POINTER(PROPVARIANT))(vtbl[6])
        commit = WINFUNCTYPE(c_long, c_void_p)(vtbl[7])
        release = WINFUNCTYPE(ctypes.c_ulong, c_void_p)(vtbl[2])
        ok = set_value(magasin, byref(cle), byref(valeur)) == 0
        commit(magasin)
        release(magasin)
        return ok
    except Exception as e:
        log.warning("Blocage des bords : %s", e)
        return False


_DETECTEUR_VISAGES = None


def detecteur_visages():
    global _DETECTEUR_VISAGES
    if _DETECTEUR_VISAGES is None and cv2 is not None:
        for chemin in (os.path.join(APP_DIR, "Modeles", "haarcascade_frontalface_default.xml"),
                       os.path.join(getattr(getattr(cv2, "data", None), "haarcascades", ""),
                                    "haarcascade_frontalface_default.xml")):
            if os.path.isfile(chemin):
                d = cv2.CascadeClassifier(chemin)
                if not d.empty():
                    _DETECTEUR_VISAGES = d
                    break
        if _DETECTEUR_VISAGES is None:
            _DETECTEUR_VISAGES = False
    return _DETECTEUR_VISAGES or None


def conseil_cadrage(img):
    """Regarde les visages dans l'image cadrée et renvoie un conseil, ou "" si tout va bien."""
    det = detecteur_visages()
    if det is None:
        return ""
    petit = ImageOps.contain(img, (360, 360))
    gris = np.array(petit.convert("L"))
    visages = det.detectMultiScale(gris, scaleFactor=1.15, minNeighbors=5, minSize=(18, 18))
    if len(visages) == 0:
        return ""
    W, H = petit.size
    for (x, y, w, h) in visages:
        if x < W * 0.04 or x + w > W * 0.96:
            return "Rapprochez-vous du centre !"
        if y < H * 0.03:
            return "Reculez un peu, on ne voit pas tout !"
    if max(h for (_, _, _, h) in visages) > H * 0.5:
        return "Reculez un peu !"
    if max(h for (_, _, _, h) in visages) < H * 0.07:
        return "Approchez-vous !"
    return ""


def ouvrir_clavier_ecran():
    """Ouvre le clavier tactile de Windows (réglages sans clavier branché).
    Le logiciel est en 32 bits : on vise explicitement les dossiers 64 bits de Windows,
    sinon Windows le redirige vers un dossier où le clavier n'existe pas."""
    if os.name != "nt":
        return
    import ctypes, subprocess
    communs = os.environ.get("CommonProgramW6432") or os.environ.get("CommonProgramFiles",
                                                                     r"C:\Program Files\Common Files")
    tabtip = os.path.join(communs, "microsoft shared", "ink", "TabTip.exe")
    windir = os.environ.get("WINDIR", r"C:\Windows")
    sys64 = os.path.join(windir, "Sysnative" if os.path.isdir(os.path.join(windir, "Sysnative")) else "System32")
    osk = os.path.join(sys64, "osk.exe")
    # 1) clavier tactile moderne
    if os.path.isfile(tabtip):
        try:
            os.startfile(tabtip)
            time.sleep(0.6)
            # s'il tournait déjà caché, on le fait apparaître (interface ITipInvocation de Windows)
            ole32 = ctypes.windll.ole32
            ole32.CoInitialize(None)

            class GUID(ctypes.Structure):
                _fields_ = [("a", ctypes.c_uint32), ("b", ctypes.c_uint16), ("c", ctypes.c_uint16),
                            ("d", ctypes.c_ubyte * 8)]

            def guid(t):
                ole32.CLSIDFromString.argtypes = [ctypes.c_wchar_p, ctypes.POINTER(GUID)]
                g = GUID()
                ole32.CLSIDFromString(t, ctypes.byref(g))
                return g
            clsid = guid("{4CE576FA-83DC-4F88-951C-9D0782B4E376}")
            iid = guid("{37C994E7-432B-4834-A2F7-DCE1F13B834B}")
            ptr = ctypes.c_void_p()
            if ole32.CoCreateInstance(ctypes.byref(clsid), None, 0x4 | 0x1, ctypes.byref(iid),
                                      ctypes.byref(ptr)) == 0 and ptr:
                vtbl = ctypes.cast(ptr, ctypes.POINTER(ctypes.POINTER(ctypes.c_void_p)))[0]
                basculer = ctypes.WINFUNCTYPE(ctypes.c_long, ctypes.c_void_p, ctypes.c_void_p)(vtbl[3])
                basculer(ptr, ctypes.windll.user32.GetDesktopWindow())
                liberer = ctypes.WINFUNCTYPE(ctypes.c_ulong, ctypes.c_void_p)(vtbl[2])
                liberer(ptr)
            return
        except Exception as e:
            log.warning("Clavier tactile : %s", e)
    # 2) clavier visuel classique, toujours disponible
    try:
        subprocess.Popen([osk])
    except Exception as e:
        log.warning("Clavier visuel : %s", e)

def recadrer(img, rapport, centrage=(0.5, 0.45)):
    """Recadre comme le montage (même centrage) : l'aperçu montre exactement la photo finale."""
    iw, ih = img.size
    if iw / ih > rapport:
        nw = int(ih * rapport)
        x = int((iw - nw) * centrage[0])
        return img.crop((x, 0, x + nw, ih))
    nh = int(iw / rapport)
    y = int((ih - nh) * centrage[1])
    return img.crop((0, y, iw, y + nh))


CHEMINS_DIGICAM = (
    r"C:\Program Files (x86)\digiCamControl\CameraControl.exe",
    r"C:\Program Files\digiCamControl\CameraControl.exe",
)


def lancer_digicam():
    """Ouvre digiCamControl s'il est installé. Retourne True si on l'a lancé."""
    if os.name != "nt":
        return False
    for chemin in CHEMINS_DIGICAM:
        if os.path.isfile(chemin):
            try:
                os.startfile(chemin)
                log.info("digiCamControl lancé automatiquement")
                return True
            except OSError as e:
                log.warning("Lancement de digiCamControl : %s", e)
    return False


def version_tuple(v):
    return tuple(int(x) for x in re.findall(r"\d+", v)[:3])


def chercher_mise_a_jour(cfg):
    """Retourne (version disponible, url de l'installateur) ou (version, None) si on est à jour.
    Canal public : la dernière publication (« Release ») du dépôt GitHub public.
    Canal de test (Audiova) : l'adresse privée enregistrée dans les réglages."""
    if cfg.get("canal_test") and cfg.get("url_mise_a_jour"):
        return _chercher_maj_privee(cfg)
    req = urllib.request.Request(f"https://api.github.com/repos/{DEPOT_GITHUB}/releases/latest",
                                 headers={"Accept": "application/vnd.github+json",
                                          "User-Agent": "Photobooth-Audiova"})
    try:
        with urllib.request.urlopen(req, timeout=15) as r:
            pub = json.loads(r.read().decode("utf-8"))
    except urllib.error.HTTPError as e:
        if e.code == 404:
            raise RuntimeError("aucune version publiée pour l'instant")
        raise
    dispo = pub.get("tag_name", "").lstrip("vV")
    exe = next((a["browser_download_url"] for a in pub.get("assets", [])
                if a.get("name", "").lower().endswith(".exe")), None)
    if not dispo or not exe:
        raise RuntimeError("publication incomplète (installateur manquant)")
    return dispo, (exe if version_tuple(dispo) > version_tuple(VERSION) else None)


def _chercher_maj_privee(cfg):
    """Canal de test : version.txt sur l'hébergement privé."""
    base = cfg.get("url_mise_a_jour", "").rstrip("/")
    if not base:
        raise RuntimeError("aucune publication trouvée")
    anti_cache = f"?t={int(time.time())}"            # évite qu'un cache de l'hébergeur serve un vieux fichier
    req = urllib.request.Request(base + "/version.txt" + anti_cache, headers={"Cache-Control": "no-cache"})
    with urllib.request.urlopen(req, timeout=10) as r:
        lignes = r.read().decode("utf-8", "ignore").strip().splitlines()
    dispo = lignes[0].strip() if lignes else ""
    fichier = lignes[1].strip() if len(lignes) > 1 and lignes[1].strip() else "Installer Photobooth Audiova.exe"
    if version_tuple(dispo) > version_tuple(VERSION):
        return dispo, base + "/" + urllib.parse.quote(fichier) + anti_cache
    return dispo, None


def nom_dossier(texte):
    return re.sub(r'[<>:"/\\|?*]', "", texte).strip()[:60]


# --------------------------------------------------------------------------
# Télécommande : page web pour le téléphone de l'organisateur (Wi-Fi du photobooth)
# --------------------------------------------------------------------------
def etat_imprimante(cfg):
    """(niveau, texte) : « ok », « alerte » ou « ko »."""
    if not cfg.get("impression_active"):
        return "ok", "Impression désactivée"
    if not HAS_WIN32:
        return "ko", "Module d'impression absent"
    try:
        nom = cfg["imprimante"] or win32print.GetDefaultPrinter()
        h = win32print.OpenPrinter(nom)
        try:
            info = win32print.GetPrinter(h, 2)
        finally:
            win32print.ClosePrinter(h)
        if info["Attributes"] & 0x400:
            return "ko", f"{nom} : hors ligne"
        if info["Status"]:
            return "alerte", f"{nom} : à vérifier (code {info['Status']})"
        n = info.get("cJobs", 0)
        return "ok", f"{nom} : prête" + (f", {n} en attente" if n else "")
    except Exception as e:
        return "ko", f"Imprimante introuvable ({str(e)[:40]})"


PAGE_TELECOMMANDE = """<!doctype html><html lang="fr"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1"><title>Télécommande Photobooth</title>
<style>
*{box-sizing:border-box}body{margin:0;background:#0E1220;color:#fff;font-family:system-ui,Segoe UI,Roboto,sans-serif}
header{padding:18px 16px;background:linear-gradient(90deg,#7B3FF2,#FF3D9A);font-weight:700;font-size:20px}
main{padding:14px;display:grid;gap:12px;max-width:640px;margin:auto}
.carte{background:#1B2136;border-radius:14px;padding:14px}
.carte h2{margin:0 0 8px;font-size:15px;color:#aab;font-weight:600;text-transform:uppercase;letter-spacing:.05em}
.ligne{display:flex;justify-content:space-between;gap:8px;padding:6px 0;border-bottom:1px solid #2a3150}
.ligne:last-child{border:0}.ok{color:#2ECC71}.alerte{color:#FFB020}.ko{color:#FF4D4D}
.gros{font-size:34px;font-weight:800}
button,select,input{font:inherit;border-radius:10px;border:0;padding:12px 14px}
button{background:#7B3FF2;color:#fff;font-weight:700;width:100%;margin-top:8px}
button.sec{background:#2a3150}select,input{width:100%;background:#0E1220;color:#fff;border:1px solid #3a4268}
img{width:100%;border-radius:10px;display:block;margin-top:6px}
.duo{display:grid;grid-template-columns:1fr 1fr;gap:8px}
#msg{text-align:center;color:#21D4FD;min-height:20px}
</style></head><body><header>📸 Télécommande Photobooth</header><main>
<div id="msg"></div>
<div class="carte"><h2>En direct</h2>
<div class="ligne"><span>Photobooth</span><b id="etat">…</b></div>
<div class="ligne"><span>Appareil photo</span><b id="camera">…</b></div>
<div class="ligne"><span>Imprimante</span><b id="imprimante">…</b></div>
<div class="ligne"><span>Internet</span><b id="internet">…</b></div>
<div class="ligne"><span>E-mails en attente</span><b id="emails">…</b></div></div>
<div class="carte"><h2>Tirages</h2><div class="gros" id="tirages">…</div><div id="tirages_detail"></div>
<div class="duo"><input id="limite" type="number" min="0" placeholder="Nombre prévu">
<button class="sec" onclick="act('limite',document.getElementById('limite').value)">Changer la limite</button></div></div>
<div class="carte"><h2>Séances</h2><div id="stats">…</div></div>
<div class="carte"><h2>Fond</h2><select id="fonds"></select>
<button onclick="act('fond',document.getElementById('fonds').value)">Utiliser ce fond</button></div>
<div class="carte"><h2>Affichage</h2><select id="mode">
<option value="auto">Automatique (soleil)</option><option value="sombre">Sombre</option>
<option value="clair">Clair</option></select>
<button onclick="act('mode',document.getElementById('mode').value)">Appliquer</button></div>
<div class="carte"><h2>Commandes</h2><div class="duo">
<button id="pause" onclick="act('pause','')">Mettre en pause</button>
<button class="sec" onclick="act('accueil','')">Retour à l'accueil</button></div>
<button class="sec" onclick="if(confirm('Fermer complètement le Photobooth ?'))act('quitter','')">Quitter le Photobooth</button></div>
<div class="carte"><h2>Dernière photo</h2><img id="derniere" alt=""></div>
<button class="sec" onclick="location.href='/deconnexion'">Se déconnecter</button>
</main><script>
let premier=true;
async function maj(){try{const r=await fetch('/etat.json');if(r.status==401){location.href='/';return}
const d=await r.json();
const t=(id,v,c)=>{const e=document.getElementById(id);e.textContent=v;if(c)e.className=c};
t('etat',d.etat);t('camera',d.camera[1],d.camera[0]);t('imprimante',d.imprimante[1],d.imprimante[0]);
t('internet',d.internet?'Connecté':'Pas d\\'internet',d.internet?'ok':'alerte');t('emails',d.emails);
t('tirages',d.limite?d.faites+' / '+d.limite:d.faites+' (sans limite)');
t('tirages_detail',d.limite?'Il reste '+Math.max(0,d.limite-d.faites)+' tirage(s) pour ce client.':'');
t('stats',d.seances+' séances · '+d.photos+' photos · '+d.qr+' QR codes · '+d.mails+' e-mails');
document.getElementById('pause').textContent=d.pause?'Reprendre':'Mettre en pause';
if(premier){const s=document.getElementById('fonds');s.innerHTML='';
for(const f of d.fonds){const o=document.createElement('option');o.value=f;o.textContent=f||'(Aucun fond)';
if(f==d.fond)o.selected=true;s.appendChild(o)}document.getElementById('mode').value=d.mode;
document.getElementById('limite').value=d.limite;premier=false}
if(d.derniere)document.getElementById('derniere').src='/derniere.jpg?'+d.derniere;
}catch(e){}}
async function act(a,v){const r=await fetch('/action',{method:'POST',body:new URLSearchParams({action:a,valeur:v})});
const m=document.getElementById('msg');m.textContent=(await r.text());setTimeout(()=>m.textContent='',3000);premier=true;maj()}
maj();setInterval(maj,3000);
</script></body></html>"""

PAGE_CONNEXION = """<!doctype html><html lang="fr"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1"><title>Télécommande Photobooth</title>
<style>body{margin:0;min-height:100vh;display:grid;place-items:center;background:#0E1220;color:#fff;
font-family:system-ui,Segoe UI,Roboto,sans-serif}form{background:#1B2136;padding:26px;border-radius:16px;width:min(340px,90vw)}
h1{font-size:20px;margin:0 0 14px}input,button{font:inherit;width:100%;padding:14px;border-radius:10px;border:0;margin-top:10px}
input{background:#0E1220;color:#fff;border:1px solid #3a4268;font-size:22px;text-align:center;letter-spacing:.3em}
button{background:linear-gradient(90deg,#7B3FF2,#FF3D9A);color:#fff;font-weight:700}p{color:#FF4D4D;margin:8px 0 0}</style>
</head><body><form method="post" action="/connexion"><h1>📸 Télécommande Photobooth</h1>
<input name="code" type="password" inputmode="numeric" placeholder="Code des réglages" autofocus>
<button>Entrer</button>{erreur}</form></body></html>"""


class ServeurTelecommande:
    def __init__(self, app, port):
        self.app = app
        self.port = int(port)
        self.jetons = set()
        serveur = self

        class Handler(http.server.BaseHTTPRequestHandler):
            def log_message(self, *a):
                pass

            def _envoyer(self, code, corps, type_="text/html; charset=utf-8", entetes=None):
                data = corps if isinstance(corps, bytes) else corps.encode("utf-8")
                self.send_response(code)
                self.send_header("Content-Type", type_)
                self.send_header("Content-Length", str(len(data)))
                self.send_header("Cache-Control", "no-store")
                for k, v in (entetes or {}).items():
                    self.send_header(k, v)
                self.end_headers()
                self.wfile.write(data)

            def _connecte(self):
                for morceau in (self.headers.get("Cookie") or "").split(";"):
                    k, _, v = morceau.strip().partition("=")
                    if k == "pb" and v in serveur.jetons:
                        return True
                return False

            def _formulaire(self):
                n = int(self.headers.get("Content-Length") or 0)
                return dict(urllib.parse.parse_qsl(self.rfile.read(min(n, 10000)).decode("utf-8", "ignore")))

            def do_GET(self):
                chemin = self.path.split("?")[0]
                if chemin == "/deconnexion":
                    return self._envoyer(302, "", entetes={"Location": "/", "Set-Cookie": "pb=; Max-Age=0"})
                if not self._connecte():
                    if chemin == "/etat.json":
                        return self._envoyer(401, "{}", "application/json")
                    return self._envoyer(200, PAGE_CONNEXION.replace("{erreur}", ""))
                if chemin == "/etat.json":
                    return self._envoyer(200, json.dumps(serveur.etat()), "application/json")
                if chemin == "/derniere.jpg":
                    data = serveur.miniature()
                    return self._envoyer(200 if data else 404, data or b"", "image/jpeg")
                return self._envoyer(200, PAGE_TELECOMMANDE)

            def do_POST(self):
                chemin = self.path.split("?")[0]
                f = self._formulaire()
                if chemin == "/connexion":
                    if f.get("code", "") == str(serveur.app.cfg["pin"]):
                        jeton = uuid.uuid4().hex
                        serveur.jetons.add(jeton)
                        return self._envoyer(302, "", entetes={
                            "Location": "/", "Set-Cookie": f"pb={jeton}; HttpOnly; SameSite=Strict; Max-Age=86400"})
                    time.sleep(1.5)                                  # freine les essais au hasard
                    return self._envoyer(200, PAGE_CONNEXION.replace("{erreur}", "<p>Code incorrect</p>"))
                if not self._connecte():
                    return self._envoyer(401, "Non connecté", "text/plain; charset=utf-8")
                if chemin == "/action":
                    return self._envoyer(200, serveur.action(f.get("action", ""), f.get("valeur", "")),
                                         "text/plain; charset=utf-8")
                return self._envoyer(404, "")

        self.httpd = http.server.ThreadingHTTPServer(("", self.port), Handler)
        threading.Thread(target=self.httpd.serve_forever, daemon=True).start()
        log.info("Télécommande active sur le port %s", self.port)

    def url(self):
        return f"http://{ip_locale()}:{self.port}"

    def etat(self):
        app, cfg = self.app, self.app.cfg
        st = cfg.get("stats", {})
        cam = app.camera
        if cam is None:
            camera = ("ko", "Non connecté")
        else:
            camera = ("ok", "Prêt") if cam.en_ligne() else ("ko", "Ne répond plus")
        libelles = {"accueil": "À l'accueil", "diaporama": "Diaporama", "prise": "Séance en cours",
                    "traitement": "Préparation de la photo", "resultat": "Résultat affiché",
                    "pause": "En pause", "reglages": "Réglages ouverts", "qr": "QR code affiché",
                    "mail": "Saisie d'e-mail", "choix": "Choix en cours", "code": "Saisie du code"}
        chemin = getattr(app, "montage_chemin", None)
        fonds = [""] + sorted(n for n in os.listdir(FONDS_DIR) if n.lower().endswith((".png", ".jpg", ".jpeg", ".webp")))
        return {"etat": libelles.get(app.etat, app.etat), "pause": app.etat == "pause",
                "camera": camera, "imprimante": etat_imprimante(cfg), "internet": bool(app.internet),
                "emails": app.emails.en_attente(), "faites": int(cfg.get("impressions_faites") or 0),
                "limite": int(cfg.get("limite_impressions") or 0), "seances": st.get("seances", 0),
                "photos": st.get("photos", 0), "qr": st.get("qr", 0), "mails": st.get("emails", 0),
                "fond": cfg.get("fond", ""), "fonds": fonds, "mode": cfg.get("mode", "sombre"),
                "derniere": int(os.path.getmtime(chemin)) if chemin and os.path.isfile(chemin) else 0}

    def miniature(self):
        chemin = getattr(self.app, "montage_chemin", None)
        if not chemin or not os.path.isfile(chemin):
            return None
        img = Image.open(chemin).convert("RGB")
        img.thumbnail((800, 800))
        tampon = io.BytesIO()
        img.save(tampon, "JPEG", quality=80)
        return tampon.getvalue()

    def action(self, action, valeur):
        app = self.app
        if action == "fond":
            if valeur and not os.path.isfile(os.path.join(FONDS_DIR, valeur)):
                return "Fond introuvable"
            app.dans_ui(app.changer_reglage, "fond", valeur)
            return "Fond changé : " + (valeur or "aucun")
        if action == "mode" and valeur in ("auto", "sombre", "clair"):
            app.dans_ui(app.changer_reglage, "mode", valeur)
            return "Affichage : " + {"auto": "automatique", "sombre": "sombre", "clair": "clair"}[valeur]
        if action == "limite":
            try:
                n = max(0, int(valeur))
            except ValueError:
                return "Nombre invalide"
            app.dans_ui(app.changer_reglage, "limite_impressions", n)
            return f"Limite de tirages : {n or 'aucune'}"
        if action == "pause":
            app.dans_ui(app.basculer_pause)
            return "C'est fait"
        if action == "accueil":
            app.dans_ui(app.afficher_accueil)
            return "Retour à l'accueil"
        if action == "quitter":
            threading.Timer(0.5, lambda: app.dans_ui(app.quitter)).start()
            return "Le Photobooth se ferme"
        return "Action inconnue"

    def arreter(self):
        self.httpd.shutdown()
        self.httpd.server_close()


# --------------------------------------------------------------------------
# Application
# --------------------------------------------------------------------------
class Photobooth:
    def __init__(self):
        self.cfg = charger_reglages()
        appliquer_theme(self.cfg)
        self.root = tk.Tk()
        self.root.title("Photobooth")
        self.root.configure(bg=NUIT, cursor="arrow")
        self.root.attributes("-fullscreen", True)
        self.root.attributes("-topmost", True)
        self.root.protocol("WM_DELETE_WINDOW", lambda: None)
        try:
            self.root.iconbitmap(os.path.join(APP_DIR, "photobooth.ico"))
        except Exception:
            pass
        self.W = self.root.winfo_screenwidth()
        self.H = self.root.winfo_screenheight()
        self.k = self.H / 1080

        self.camera = None
        self.erreur_camera = "Connexion en cours…"
        self.serveur = None
        self.gabarit = Gabarit(self._chemin_fond())
        self.emails = FileEmails(self)
        self.taches = queue.Queue()
        self.etat = "accueil"
        self._minuteur = None
        self._fige = False
        self.reglages_ouverts = False
        self._images_boutons = {}
        self._anim_accueil = None
        self._confettis = []
        self.internet = None
        self._evt_net = threading.Event()

        self._minuteur_diapo = None
        self._connexion_en_cours = False
        self._cache_gabarits = {}
        self.g_session = self.gabarit
        creer_sons()

        self._construire()
        threading.Thread(target=self._surveiller_internet, daemon=True).start()
        threading.Thread(target=self._surveiller_camera, daemon=True).start()
        self._verrou = None
        self.root.report_callback_exception = self._erreur_interface
        self.root.after(50, self._pomper)
        self.root.after(300, self._initialiser_materiel)
        self.mode_actuel = mode_effectif(self.cfg)
        self.root.after(60000, self._suivre_soleil)
        if os.name == "nt":
            try:
                import ctypes
                ctypes.windll.winmm.timeBeginPeriod(1)
            except Exception:
                pass
        self.prestation = ModePrestation()
        self.root.after(1500, lambda: self.prestation.activer(self.cfg))
        self.root.after(800, self._bloquer_bords)
        self.afficher_accueil()
        if self.cfg.get("bloquer_clavier"):
            # seulement une fois le logiciel bien démarré
            self.root.after(5000, self._activer_verrou)

    def _activer_verrou(self):
        if self._verrou is None:
            self._verrou = installer_verrou(
                lambda: bool(self.cfg.get("bloquer_clavier")) and not self.reglages_ouverts)

    def retirer_verrou(self):
        if self._verrou:
            self._verrou["retirer"]()
            self._verrou = None

    def _erreur_interface(self, exc, val, tb):
        """Une erreur dans un écran ne doit jamais bloquer le photobooth : on la note et on continue."""
        import traceback
        log.error("Erreur d'interface :\n%s", "".join(traceback.format_exception(exc, val, tb)))

    # ---- outils -----------------------------------------------------------
    def p(self, taille):
        return max(8, int(taille * self.k))

    def dans_ui(self, fonction, *args):
        self.taches.put(lambda: fonction(*args))

    def _pomper(self):
        try:
            while True:
                self.taches.get_nowait()()
        except queue.Empty:
            pass
        self.root.after(40, self._pomper)

    def _chemin_fond(self):
        return os.path.join(FONDS_DIR, self.cfg["fond"]) if self.cfg["fond"] else None

    def bouton(self, parent, texte, commande, principal=True, largeur=None):
        """Bouton arrondi en dégradé, dessiné en image (plus joli que les boutons Windows)."""
        h = self.p(84)
        if largeur is None:
            largeur = int(police_titre(int(h * 0.42)).getlength(texte) + self.p(110))
        cle = (texte, largeur, h, principal)
        if cle not in self._images_boutons:
            self._images_boutons[cle] = (
                ImageTk.PhotoImage(img_pilule(texte, largeur, h, principal)),
                ImageTk.PhotoImage(img_pilule(texte, largeur, h, principal, appuye=True)))
        normal, appuye = self._images_boutons[cle]
        b = tk.Label(parent, image=normal, bg=parent.cget("bg"), bd=0, cursor="hand2")

        def presse(_e):
            b.config(image=appuye)

        def relache(e):
            b.config(image=normal)
            if 0 <= e.x <= b.winfo_width() and 0 <= e.y <= b.winfo_height() and commande:
                commande()
        b.bind("<ButtonPress-1>", presse)
        b.bind("<ButtonRelease-1>", relache)
        return b

    def titre_image(self, texte, taille, halo=True):
        cle = ("titre", texte, taille, halo)
        if cle not in self._images_boutons:
            self._images_boutons[cle] = ImageTk.PhotoImage(img_titre(texte, taille, halo=halo))
        return self._images_boutons[cle]

    def montrer(self, page):
        # Sur un Canvas, tkraise() désigne autre chose (ses dessins) : on appelle la version « fenêtre »
        tk.Misc.tkraise(page)

    # ---- construction des écrans ------------------------------------------
    def _construire(self):
        def page(cls=tk.Frame, **kw):
            f = cls(self.root, bg=NUIT, highlightthickness=0, bd=0, **kw)
            f.place(x=0, y=0, relwidth=1, relheight=1)
            return f

        # Accueil
        self.c_accueil = page(tk.Canvas)
        self.c_accueil.bind("<Button-1>", self._appui_accueil)

        # Prise de vue (aperçu en direct + compte à rebours)
        self.c_live = page(tk.Canvas)
        self.id_live = self.c_live.create_image(self.W // 2, self.H // 2)
        r = self.p(190)
        cx, cy = self.W // 2, self.H // 2
        self.id_anneau_fond = self.c_live.create_oval(cx - r, cy - r, cx + r, cy + r, outline=melange(NUIT, BLANC, 0.25),
                                                      width=self.p(14), state="hidden")
        self.id_anneau = self.c_live.create_arc(cx - r, cy - r, cx + r, cy + r, start=90, extent=359.9,
                                                style="arc", outline=ROSE, width=self.p(14), state="hidden")
        self.id_ombre = self.c_live.create_text(self.W // 2 + 6, self.H // 2 + 6, text="",
                                                font=(TITRE, self.p(260), "bold"), fill="#000000")
        self.id_texte = self.c_live.create_text(self.W // 2, self.H // 2, text="",
                                                font=(TITRE, self.p(260), "bold"), fill=BLANC)
        self.id_info = self.c_live.create_text(self.W // 2, self.p(64), text="",
                                               font=(TITRE, self.p(42), "bold"), fill=BLANC)
        # Boutons « Refaire » / « Garder » après chaque photo (dessinés sur l'image)
        lg, hb = self.p(330), self.p(84)
        self._tk_refaire = ImageTk.PhotoImage(img_pilule("Refaire", lg, hb, False))
        self._tk_garder = ImageTk.PhotoImage(img_pilule("Garder", lg, hb, True))
        yb = self.H - self.p(130)
        self.c_live.create_image(self.W // 2 - self.p(200), yb, image=self._tk_refaire,
                                 tags="refaire", state="hidden")
        self.c_live.create_image(self.W // 2 + self.p(200), yb, image=self._tk_garder,
                                 tags="garder", state="hidden")
        self.c_live.create_text(self.W // 2, yb + self.p(78), text="", fill=BLANC, state="hidden",
                                font=(TEXTE, self.p(20), "bold"), tags="refaire_txt")
        self.c_live.create_rectangle(0, 0, 0, 0, fill="#0E1220", outline="", tags="conseil_fond", state="hidden")
        self.c_live.create_text(self.W // 2, self.H - self.p(150), text="", fill="#FFD23F",
                                font=(TITRE, self.p(44), "bold"), tags="conseil")
        self.c_live.create_text(self.p(16), self.H - self.p(16), anchor="sw", text="", fill="#7CFC00",
                                font=(TEXTE, self.p(16), "bold"), tags="fps", state="hidden")
        self.c_live.tag_bind("refaire", "<ButtonRelease-1>", self._refaire)
        self.c_live.tag_bind("garder", "<ButtonRelease-1>", self._garder)
        self.id_flash = self.c_live.create_rectangle(0, 0, self.W, self.H, fill="white",
                                                     outline="", state="hidden")

        # Message plein écran
        self.page_msg = page()
        self.lbl_msg = tk.Label(self.page_msg, bg=NUIT, fg=TXT, font=(TITRE, self.p(46), "bold"),
                                justify="center", wraplength=int(self.W * 0.8))
        self.lbl_msg.place(relx=0.5, rely=0.5, anchor="center")

        # Résultat
        self.page_res = page(tk.Canvas)
        self.page_res.bind("<Button-1>", self._appui_coin)
        self.id_res = self.page_res.create_image(int(self.W * 0.37), self.H // 2)
        self.col = tk.Frame(self.page_res, bg=NUIT)
        self.page_res.create_window(int(self.W * 0.845), self.H // 2, window=self.col)
        lg_nb, h_nb = self.p(300), self.p(70)
        self._tk_nb = {True: ImageTk.PhotoImage(img_pilule("Couleur", lg_nb, h_nb, False)),
                       False: ImageTk.PhotoImage(img_pilule("Noir et blanc", lg_nb, h_nb, False))}
        self.id_nb = self.page_res.create_image(int(self.W * 0.37), self.H - self.p(78), tags="nb", state="hidden")
        self.page_res.tag_bind("nb", "<ButtonRelease-1>", self._basculer_nb)
        self.id_toast = self.page_res.create_text(self.W // 2, int(self.H * 0.955), text="",
                                                  font=(TEXTE, self.p(26), "bold"), fill=CYAN)

        # Nombre de tirages
        self.page_copies = page()

        # QR code
        self.page_qr = page()
        self.lbl_qr_titre = tk.Label(self.page_qr, bg=NUIT, fg=TXT, font=(TITRE, self.p(42), "bold"),
                                     wraplength=int(self.W * 0.8), justify="center")
        self.lbl_qr_titre.pack(pady=(self.p(50), self.p(20)))
        self.lbl_qr = tk.Label(self.page_qr, bg=NUIT, bd=0)
        self.lbl_qr.pack()
        self.lbl_qr_info = tk.Label(self.page_qr, bg=NUIT, fg=CYAN, font=(TEXTE, self.p(24)),
                                    wraplength=int(self.W * 0.8), justify="center")
        self.lbl_qr_info.pack(pady=self.p(16))
        self.bouton(self.page_qr, "Retour", self.retour_resultat, False).pack(pady=self.p(10))

        # E-mail (clavier tactile)
        self.page_mail = page()
        self._construire_clavier()

        # Code administrateur
        self.page_format = page()
        self.page_code = page()
        self._construire_pave()

        # Diaporama quand personne n'utilise le photobooth
        self.page_diapo = page(tk.Canvas)
        self.page_diapo.bind("<Button-1>", self._appui_diapo)
        self.id_diapo = self.page_diapo.create_image(self.W // 2, int(self.H * 0.45))
        self._tk_diapo_appel = ImageTk.PhotoImage(img_titre("Touchez pour faire votre photo", self.p(70)))
        self.page_diapo.create_image(self.W // 2, int(self.H * 0.92), image=self._tk_diapo_appel)

        # Cadenas d'accès aux réglages
        self._tk_cadenas = ImageTk.PhotoImage(img_cadenas(self.p(40), melange(NUIT, TXT, 0.35)))
        self._poser_cadenas(self.page_res)
        self._poser_cadenas(self.page_diapo)

        # Témoin de connexion internet (pages QR code et e-mail)
        self.temoins_net = []
        for p in (self.page_qr, self.page_mail):
            lbl = tk.Label(p, text="", bg=NUIT, font=(TEXTE, self.p(22), "bold"))
            if p is self.page_mail:          # tout en bas, centré
                lbl.place(relx=0.5, rely=0.985, anchor="s")
            else:                            # coin en bas à droite
                lbl.place(relx=0.985, rely=0.975, anchor="se")
            self.temoins_net.append((p, lbl))
        self._maj_internet(self.internet)

    # ---- surveillance de l'appareil photo ----------------------------------
    def _surveiller_camera(self):
        """Toutes les 10 s, à l'accueil : si l'appareil ne répond plus, on le reconnecte."""
        derniere_tentative = 0
        while True:
            time.sleep(10)
            if self.etat not in ("accueil", "diaporama") or self.reglages_ouverts \
                    or self._connexion_en_cours:
                continue
            cam = self.camera
            if cam is not None:
                try:
                    ok = cam.en_ligne()
                except Exception:
                    ok = False
                if not ok:
                    log.warning("Appareil photo perdu : reconnexion")
                    self.dans_ui(self.reconnecter_camera)
            elif time.time() - derniere_tentative > 20:
                derniere_tentative = time.time()
                self.dans_ui(self.reconnecter_camera)

    # ---- connexion internet --------------------------------------------------
    @staticmethod
    def _tester_internet():
        for hote in (("1.1.1.1", 53), ("8.8.8.8", 53), ("9.9.9.9", 53)):
            try:
                socket.create_connection(hote, timeout=2).close()
                return True
            except OSError:
                continue
        return False

    def _surveiller_internet(self):
        while True:
            self.dans_ui(self._maj_internet, self._tester_internet())
            self._evt_net.wait(10)
            self._evt_net.clear()

    def _maj_internet(self, ok):
        self.internet = ok
        for page, lbl in self.temoins_net:
            if ok is None:
                lbl.config(text="● Vérification d'internet…", fg=GRIS)
            elif ok:
                lbl.config(text="● Internet OK", fg="#2ECC71")
            elif page is self.page_mail:
                lbl.config(text="● Pas d'internet · la photo partira dès le retour du réseau", fg="#FF4D4D")
            else:
                lbl.config(text="● Pas d'internet", fg="#FF4D4D")

    def _construire_clavier(self):
        p = self.page_mail
        tk.Label(p, image=self.titre_image("Votre adresse e-mail", self.p(56)), bg=NUIT).pack(
            pady=(self.p(16), 0))
        self.saisie = tk.StringVar()
        tk.Label(p, textvariable=self.saisie, bg=BLANC, fg=ENCRE, font=(TEXTE, self.p(34)),
                 width=34, anchor="w", padx=self.p(16), pady=self.p(10)).pack()
        self.lbl_mail_err = tk.Label(p, text="", bg=NUIT, fg=ROSE, font=(TEXTE, self.p(22)))
        self.lbl_mail_err.pack(pady=self.p(8))
        clavier = tk.Frame(p, bg=NUIT)
        clavier.pack()
        rangees = ["1234567890", "azertyuiop", "qsdfghjklm", "wxcvbn.-_@"]
        for r in rangees:
            ligne = tk.Frame(clavier, bg=NUIT)
            ligne.pack(pady=self.p(4))
            for c in r:
                self._touche(ligne, c, lambda c=c: self._taper(c)).pack(side="left", padx=self.p(4))
        ligne = tk.Frame(clavier, bg=NUIT)
        ligne.pack(pady=self.p(4))
        for t in ("@gmail.com", "@hotmail.fr", "@orange.fr", "@icloud.com", ".fr", ".com"):
            self._touche(ligne, t, lambda t=t: self._taper(t), large=True).pack(side="left", padx=self.p(4))
        self._touche(ligne, "⌫", self._effacer, large=True).pack(side="left", padx=self.p(4))
        self.accord = tk.BooleanVar(value=False)
        self.lbl_accord = tk.Label(p, bg=NUIT, fg=TXT, font=(TEXTE, self.p(22)), cursor="hand2",
                                   wraplength=int(self.W * 0.8), justify="left")
        self.lbl_accord.pack(pady=(self.p(18), 0))
        self.lbl_accord.bind("<Button-1>", lambda e: self._basculer_accord())
        self._maj_accord()
        actions = tk.Frame(p, bg=NUIT)
        actions.pack(pady=self.p(16))
        self.bouton(actions, "Annuler", self.retour_resultat, False).pack(side="left", padx=self.p(14))
        self.bouton(actions, "Envoyer la photo", self._valider_mail).pack(side="left", padx=self.p(14))

    def _touche(self, parent, texte, cmd, large=False):
        return tk.Button(parent, text=texte, command=cmd, font=(TEXTE, self.p(26)),
                         width=None if large else 3, bg=NUIT_CLAIR, fg=TXT,
                         activebackground=ROSE, activeforeground=BLANC,
                         relief="flat", bd=0, highlightthickness=0,
                         padx=self.p(14), pady=self.p(10))

    def _basculer_accord(self):
        self._armer_retour()
        self.accord.set(not self.accord.get())
        self._maj_accord()

    def _maj_accord(self):
        case = "☑" if self.accord.get() else "☐"
        self.lbl_accord.config(text=f"{case}  J'accepte de recevoir ma photo par e-mail. Mon adresse "
                                    "sert uniquement à cet envoi et n'est pas conservée.",
                               fg=TXT if self.accord.get() else melange(TXT, NUIT, 0.25))

    def _taper(self, t):
        self._armer_retour()
        self.saisie.set(self.saisie.get() + t)

    def _effacer(self):
        self._armer_retour()
        self.saisie.set(self.saisie.get()[:-1])

    def _construire_pave(self):
        p = self.page_code
        tk.Label(p, image=self.titre_image("Code réglages", self.p(56)), bg=NUIT).pack(
            pady=(self.p(40), 0))
        self.code = tk.StringVar()
        self.lbl_code = tk.Label(p, text="", bg=NUIT, fg=ROSE, font=(TITRE, self.p(50), "bold"))
        self.lbl_code.pack(pady=self.p(10))
        grille = tk.Frame(p, bg=NUIT)
        grille.pack()
        touches = ["1", "2", "3", "4", "5", "6", "7", "8", "9", "⌫", "0", "OK"]
        for i, t in enumerate(touches):
            b = tk.Button(grille, text=t, font=(TITRE, self.p(36)), width=4,
                          bg=ROSE if t == "OK" else NUIT_CLAIR,
                          fg=BLANC if t == "OK" else TXT, relief="flat", bd=0,
                          activebackground=ROSE, pady=self.p(14),
                          command=lambda t=t: self._pave(t))
            b.grid(row=i // 3, column=i % 3, padx=self.p(6), pady=self.p(6))
        self.bouton(p, "Annuler", self.afficher_accueil, False).pack(pady=self.p(30))

    def _pave(self, t):
        if t == "⌫":
            self.code.set(self.code.get()[:-1])
        elif t == "OK":
            if self.code.get() == str(self.cfg["pin"]):
                self.code.set("")
                self.ouvrir_reglages()
                return
            self.code.set("")
            self.lbl_code.config(text="Code incorrect")
            return
        else:
            self.code.set(self.code.get() + t)
        self.lbl_code.config(text="•" * len(self.code.get()))

    # ---- matériel -----------------------------------------------------------
    def _initialiser_materiel(self):
        self._demarrer_serveur()
        self._demarrer_telecommande()
        self.reconnecter_camera()

    def _demarrer_telecommande(self):
        if getattr(self, "telecommande", None):
            try:
                self.telecommande.arreter()
            except Exception:
                pass
            self.telecommande = None
        if self.cfg.get("telecommande", True):
            try:
                self.telecommande = ServeurTelecommande(self, self.cfg.get("port_telecommande", 8090))
            except Exception as e:
                log.error("Télécommande : %s", e)

    def changer_reglage(self, cle, valeur):
        """Réglage changé depuis la télécommande."""
        self.cfg[cle] = valeur
        sauver_reglages(self.cfg)
        if cle == "fond":
            self._cache_gabarits = {}
            self.gabarit = self._gabarit(self._chemin_fond())
        if cle == "mode":
            if self.etat in ("accueil", "diaporama", "pause"):
                pause = self.etat == "pause"
                self._reconstruire_interface()
                self.basculer_pause() if pause else self.afficher_accueil()
            else:
                self._reconstruire_apres = True

    def basculer_pause(self):
        if self.etat == "pause":
            self.afficher_accueil()
        elif not self.reglages_ouverts:
            self._annuler_retour()
            self._annuler_diapo()
            self.etat = "pause"
            self.message("Petite pause…\nLe photobooth revient très vite ✨")

    def reconnecter_camera(self, rappel=None):
        ancienne, self.camera = self.camera, None
        self._connexion_en_cours = True
        self.erreur_camera = "Connexion en cours…"
        if self.etat == "accueil":
            self._dessiner_statut()

        def travail():
            if ancienne:
                try:
                    ancienne.fermer()
                except Exception:
                    pass
            try:
                cam, err = creer_camera(self.cfg), None
            except Exception as e:
                cam, err = None, str(e)
                log.warning("Appareil photo : %s", e)
                # digiCamControl fermé ? on l'ouvre et on attend qu'il réponde
                if self.cfg["camera"] == "digicam" and self.cfg.get("lancer_digicam", True) \
                        and time.time() - getattr(self, "_digicam_lance", 0) > 120 and lancer_digicam():
                    self._digicam_lance = time.time()
                    self.dans_ui(lambda: self.root.after(4000, self._reprendre_le_dessus))
                    for _ in range(30):
                        time.sleep(1)
                        try:
                            cam, err = creer_camera(self.cfg), None
                            break
                        except Exception as e2:
                            err = str(e2)
                    self.dans_ui(self._reprendre_le_dessus)
            self.dans_ui(self._camera_prete, cam, err, rappel)
        threading.Thread(target=travail, daemon=True).start()

    def _camera_prete(self, cam, err, rappel=None):
        self._connexion_en_cours = False
        self.camera, self.erreur_camera = cam, err
        if self.etat == "accueil":
            self._dessiner_statut()
        if rappel:
            rappel(err)

    def _demarrer_serveur(self):
        if self.serveur:
            try:
                self.serveur.arreter()
            except Exception:
                pass
            self.serveur = None
        if self.cfg["qr_actif"] and self.cfg["qr_mode"] == "local":
            try:
                self.serveur = ServeurLocal(self.cfg["port_local"])
            except Exception as e:
                log.error("Serveur local : %s", e)

    # ---- accueil ------------------------------------------------------------
    def afficher_accueil(self):
        self._annuler_retour()
        self._annuler_diapo()
        if getattr(self, "_reconstruire_apres", False):     # mode changé pendant une séance
            self._reconstruire_apres = False
            self._reconstruire_interface()
        self.etat = "accueil"
        self.code.set("")
        self.lbl_code.config(text="")
        self._dessiner_accueil()
        self.montrer(self.c_accueil)
        if self.cfg.get("diaporama"):
            self._minuteur_diapo = self.root.after(
                max(5, int(self.cfg.get("diaporama_delai") or 30)) * 1000, self._lancer_diaporama)

    # ---- diaporama -------------------------------------------------------------
    def _annuler_diapo(self):
        if self._minuteur_diapo:
            self.root.after_cancel(self._minuteur_diapo)
            self._minuteur_diapo = None

    def _lancer_diaporama(self):
        self._minuteur_diapo = None
        if self.etat != "accueil" or self.reglages_ouverts:
            return
        photos = photos_evenement(self.cfg)[-40:]
        if not photos:
            self._minuteur_diapo = self.root.after(60000, self._lancer_diaporama)
            return
        self.etat = "diaporama"
        self._diapo_liste = list(reversed(photos))
        self._diapo_i = 0
        self._diapo_suivante()

    def _diapo_suivante(self):
        if self.etat != "diaporama":
            return
        chemin = self._diapo_liste[self._diapo_i % len(self._diapo_liste)]
        self._diapo_i += 1
        W, H = self.W, self.H

        def travail():
            try:
                img = img_cadre_photo(Image.open(chemin).convert("RGB"), int(W * 0.9), int(H * 0.82))
                self.dans_ui(self._diapo_afficher, img)
            except Exception as e:
                log.warning("Diaporama : %s", e)
                self.dans_ui(self._diapo_afficher, None)
        threading.Thread(target=travail, daemon=True).start()

    def _diapo_afficher(self, img):
        if self.etat != "diaporama":
            return
        if img is not None:
            self._tk_diapo = ImageTk.PhotoImage(img)
            self.page_diapo.itemconfig(self.id_diapo, image=self._tk_diapo)
            self.montrer(self.page_diapo)
        self._minuteur_diapo = self.root.after(4500, self._diapo_suivante)

    def _appui_diapo(self, e):
        if self._appui_coin(e):
            return
        self._annuler_diapo()
        self.etat = "accueil"
        self.demarrer_session()

    def _dessiner_accueil(self):
        c = self.c_accueil
        c.delete("all")
        self._anim_accueil = None
        W, H = self.W, self.H
        image = None
        for nom in ("accueil.png", "accueil.jpg", "accueil.jpeg"):
            chemin = os.path.join(DATA_DIR, nom)
            if os.path.isfile(chemin):
                try:
                    image = ImageOps.fit(Image.open(chemin).convert("RGB"), (W, H))
                except Exception:
                    pass
                break
        if image is not None:                      # écran d'accueil fourni par vous
            self._tk_accueil = ImageTk.PhotoImage(image)
            c.create_image(0, 0, image=self._tk_accueil, anchor="nw")
        else:
            self._scene_accueil(c)
        self._dessiner_statut()
        self._poser_cadenas(c)

    def _dessiner_statut(self):
        c, W, H = self.c_accueil, self.W, self.H
        c.delete("statut")
        if self.camera is None:
            texte = "Appareil photo : " + (self.erreur_camera or "non connecté")
            c.create_text(W / 2, H - self.p(80), text=texte, font=(TEXTE, self.p(18)),
                          fill=ROSE, width=int(W * 0.9), tags="statut")

    def _scene_accueil(self, c):
        """Faisceaux de lyres, particules lumineuses, logo et titre néon."""
        import math
        W, H = self.W, self.H
        random.seed(7)
        couleurs = (CHAMPAGNE, CYAN, ROSE, CYAN, CHAMPAGNE)
        clair = mode_effectif(self.cfg) == "clair"
        renfort = 1.5 if clair else 1.0
        self._style_anim = self.cfg.get("animation_accueil", "bulles")
        self._lyres, self._bulles, self._sprites, self._etoiles, self._lumieres = [], [], [], [], []
        densite = float(self.cfg.get("densite_anim", 1.0) or 1.0)
        if self._style_anim != "projecteurs":
            self._tk_fond_accueil = ImageTk.PhotoImage(img_fond_accueil(W, H, clair))
            c.create_image(0, 0, image=self._tk_fond_accueil, anchor="nw")
            self._tk_sprites = []
        if self._style_anim == "bulles":
            for _ in range(int(24 * densite)):
                d = int(random.uniform(40, 170) * self.k)
                coul = random.choice((CHAMPAGNE, ROSE, CYAN, CHAMPAGNE if clair else BLANC))
                tkimg = ImageTk.PhotoImage(img_bulle(d, coul, random.uniform(0.18, 0.45)))
                self._tk_sprites.append(tkimg)
                x, y = random.uniform(0, W), random.uniform(0, H)
                item = c.create_image(x, y, image=tkimg)
                self._sprites.append({"item": item, "x": x, "y": y, "vy": random.uniform(0.25, 0.9) * self.k,
                                      "amp": random.uniform(10, 40) * self.k, "ph": random.uniform(0, 6.28),
                                      "vit": random.uniform(0.15, 0.45), "d": d})
        elif self._style_anim == "guirlande":
            for pts in guirlandes(W, H, self.k):
                c.create_line(*[v for p in pts for v in p], fill="#2A2440", width=max(2, int(3 * self.k)),
                              smooth=True)
                pas = max(2, int(5 / densite))
                for x, y in pts[::pas]:
                    d = max(8, int(22 * self.k))
                    imgs = [ImageTk.PhotoImage(img_ampoule(d, n)) for n in range(3)]
                    self._tk_sprites += imgs
                    item = c.create_image(x, y + 14 * self.k, image=imgs[2])
                    self._lumieres.append({"item": item, "imgs": imgs, "niveau": 2, "type": "onde",
                                           "ph": random.uniform(0, 6.28), "vit": random.uniform(0.4, 1.1)})
        elif self._style_anim == "paillettes":
            for _ in range(int(80 * densite)):
                r = max(2, random.uniform(2, 7) * self.k)
                imgs = [ImageTk.PhotoImage(img_paillette(r, n)) for n in range(3)]
                self._tk_sprites += imgs
                item = c.create_image(random.uniform(0, W), random.uniform(0, H), image=imgs[0])
                self._lumieres.append({"item": item, "imgs": imgs, "niveau": 0, "type": "eclat", "debut": 0})
        elif self._style_anim == "etoiles":
            for _ in range(int(70 * densite)):
                d = max(4, int(random.uniform(4, 10) * self.k))
                coul = random.choice((BLANC if not clair else CHAMPAGNE, CYAN, ROSE))
                faible = ImageTk.PhotoImage(img_etoile(d, coul, False))
                forte = ImageTk.PhotoImage(img_etoile(d, coul, True))
                self._tk_sprites += [faible, forte]
                item = c.create_image(random.uniform(0, W), random.uniform(0, H * 0.95), image=faible)
                self._etoiles.append({"item": item, "faible": faible, "forte": forte, "fin": 0})
        for i, coul in enumerate(couleurs if self._style_anim == "projecteurs" else ()):
            ox = W * (0.1 + 0.2 * i)
            couches = []
            for largeur, force in ((0.20, 0.10), (0.11, 0.17), (0.045, 0.30)):
                couches.append((c.create_polygon(0, 0, 0, 0, 0, 0, fill=melange(NUIT, coul, force * renfort),
                                                 outline=""), largeur))
            self._lyres.append({"ox": ox, "couches": couches, "phase": i * 1.3,
                                "vitesse": 0.35 + 0.12 * (i % 3), "base": (0.5 - i / 4) * 0.5})
            c.create_oval(ox - self.p(16), -self.p(16), ox + self.p(16), self.p(16),
                          fill=melange(coul, BLANC, 0.5), outline="")
        for _ in range(34 if self._style_anim == "projecteurs" else 0):
            r = random.uniform(3, 16) * self.k
            x, y = random.uniform(0, W), random.uniform(0, H)
            coul = random.choice((CHAMPAGNE, ROSE, CYAN, CYAN if clair else BLANC))
            item = c.create_oval(x - r, y - r, x + r, y + r,
                                 fill=melange(NUIT, coul, random.uniform(0.25, 0.6)), outline="")
            self._bulles.append([item, random.uniform(0.3, 1.2) * self.k, random.uniform(0, 6.28)])
        logo = None                                # logo discret, en haut
        for nom in ("logo.png", "logo.jpg"):
            chemin = os.path.join(DATA_DIR, nom)
            if os.path.isfile(chemin):
                try:
                    logo = ImageOps.contain(Image.open(chemin).convert("RGBA"),
                                            (int(W * 0.16), int(H * 0.08)), Image.LANCZOS)
                except Exception:
                    pass
                break
        if logo is not None:
            self._tk_logo = ImageTk.PhotoImage(logo)
            c.create_image(W / 2, H * 0.1, image=self._tk_logo)
        elif self.cfg.get("marque"):
            c.create_text(W / 2, H * 0.1, text=self.cfg["marque"], font=(TITRE, self.p(22)), fill=GRIS)
        # Grand appel à toucher l'écran, en néon qui pulse
        titre = self.cfg.get("titre_accueil") or "Touchez pour commencer"
        taille = self.p(150)
        while taille > 20 and police_titre(taille).getlength(titre) > W * 0.86:
            taille -= 4
        self._tk_pil_a = ImageTk.PhotoImage(img_titre(titre, taille))
        self._tk_pil_b = ImageTk.PhotoImage(img_titre(titre, taille, halo=False))
        self.id_appel = c.create_image(W / 2, H * 0.47, image=self._tk_pil_a)
        if self.cfg.get("texte_accueil"):
            c.create_text(W / 2, H * 0.47 + taille * 0.95, text=self.cfg["texte_accueil"],
                          font=(TEXTE, self.p(30)), fill=TXT, width=int(W * 0.8), justify="center")
        self._etapes = []
        self._etape_affichee = None
        if self.cfg.get("comment_ca_marche", True):
            textes = ("Touchez l'écran", "Prenez la pose", "Récupérez votre photo")
            d = self.p(92)
            self._tk_etapes = []
            for i, t in enumerate(textes):
                x = W / 2 + (i - 1) * W * 0.24
                y = H * 0.73
                normal = ImageTk.PhotoImage(img_etape(i + 1, d, False))
                actif = ImageTk.PhotoImage(img_etape(i + 1, d, True))
                self._tk_etapes.append((normal, actif))
                rond = c.create_image(x, y, image=normal)
                texte = c.create_text(x, y + d * 0.85, text=t, font=(TITRE, self.p(26), "bold"), fill=TXT)
                self._etapes.append((rond, texte))
                if i < 2:
                    c.create_text(x + W * 0.12, y, text="›", font=(TITRE, self.p(60)), fill=GRIS)
        c.create_text(W / 2, H - self.p(36), text=self.cfg.get("pied_accueil", ""),
                      font=(TEXTE, self.p(20)), fill=GRIS)
        self._t0 = time.time()
        self._prochaine_image = self._t0
        self._anim_accueil = True
        self._gen_accueil = getattr(self, "_gen_accueil", 0) + 1
        self._animer_accueil(self._gen_accueil)

    def _animer_accueil(self, gen):
        if self.etat != "accueil" or not self._anim_accueil or gen != self._gen_accueil:
            return
        c, t = self.c_accueil, time.time() - self._t0
        L = self.H * 1.35
        if self.cfg.get("animations", True) or t < 0.1:
            for ly in self._lyres:
                a = ly["base"] + 0.42 * math.sin(t * ly["vitesse"] + ly["phase"])
                for item, largeur in ly["couches"]:
                    c.coords(item, *faisceau(ly["ox"], 0, a, L, L * largeur))
            for sp in self._sprites:                        # bulles de lumière qui montent doucement
                sp["y"] -= sp["vy"]
                if sp["y"] < -sp["d"]:
                    sp["y"] = self.H + sp["d"]
                c.coords(sp["item"], sp["x"] + sp["amp"] * math.sin(t * sp["vit"] + sp["ph"]), sp["y"])
            if self._etoiles:                                 # étoiles qui scintillent
                maintenant = time.time()
                for et in self._etoiles:
                    if et["fin"] and maintenant > et["fin"]:
                        et["fin"] = 0
                        c.itemconfig(et["item"], image=et["faible"])
                for et in random.sample(self._etoiles, 2):
                    if not et["fin"] and random.random() < 0.5:
                        et["fin"] = maintenant + random.uniform(0.3, 1.2)
                        c.itemconfig(et["item"], image=et["forte"])
            if self._lumieres:                                # guirlande / paillettes : rien ne bouge
                maintenant = time.time()
                if self._style_anim == "paillettes":
                    for lu in random.sample(self._lumieres, min(2, len(self._lumieres))):
                        if not lu["debut"] and random.random() < 0.6:
                            lu["debut"] = maintenant
                for lu in self._lumieres:
                    if lu["type"] == "onde":
                        v = math.sin(t * lu["vit"] + lu["ph"])
                        niveau = 2 if v > 0.3 else 1 if v > -0.5 else 0
                    else:
                        if not lu["debut"]:
                            continue
                        age = maintenant - lu["debut"]
                        niveau = 1 if age < 0.15 else 2 if age < 0.45 else 1 if age < 0.75 else 0
                        if age >= 0.75:
                            lu["debut"] = 0
                    if niveau != lu["niveau"]:
                        lu["niveau"] = niveau
                        c.itemconfig(lu["item"], image=lu["imgs"][niveau])
            for b in self._bulles:
                item, v, ph = b
                c.move(item, math.sin(t + ph) * 0.4, -v)
                pos = c.coords(item)
                if len(pos) != 4:
                    continue
                x0, y0, x1, y1 = pos
                if y1 < 0:
                    c.move(item, 0, self.H + (y1 - y0) + 10)
            c.itemconfig(self.id_appel, image=self._tk_pil_a if int(t * 1.4) % 2 == 0 else self._tk_pil_b)
        if getattr(self, "_etapes", None):                 # « Comment ça marche » : seulement au changement
            etape = int(t / 1.4) % 3
            if etape != getattr(self, "_etape_affichee", None):
                self._etape_affichee = etape
                for i, (rond, texte) in enumerate(self._etapes):
                    c.itemconfig(rond, image=self._tk_etapes[i][i == etape])
        # cadence fixe : une image toutes les 33 ms (30 images/s), sans dérive
        maintenant = time.time()
        self._prochaine_image = getattr(self, "_prochaine_image", maintenant) + 0.033
        if self._prochaine_image < maintenant - 0.1:          # gros retard : on repart à zéro
            self._prochaine_image = maintenant + 0.033
        self.root.after(max(1, int((self._prochaine_image - maintenant) * 1000)), self._animer_accueil, gen)

    def _poser_cadenas(self, canvas):
        """Cadenas discret en haut à droite : un appui ouvre le code des réglages."""
        canvas.delete("cadenas")
        canvas.create_image(self.W - self.p(46), self.p(46), image=self._tk_cadenas, tags="cadenas")

    def _appui_coin(self, e):
        """Appui sur le cadenas (zone en haut à droite) = demande du code."""
        if e.x > self.W - self.p(110) and e.y < self.p(110):
            self.demander_code()
            return True
        return False

    def _appui_accueil(self, e):
        self._dernier_contact = time.time()
        if self._appui_coin(e):
            return
        self._annuler_diapo()
        self.demarrer_session()

    def demander_code(self):
        if self.etat not in ("accueil", "resultat", "diaporama") or self.reglages_ouverts:
            return
        self._annuler_retour()
        self._annuler_diapo()
        self.etat = "code"
        self.code.set("")
        self.lbl_code.config(text="")
        self.montrer(self.page_code)

    # ---- séance photo ------------------------------------------------------
    def message(self, texte):
        self.lbl_msg.config(text=texte)
        self.montrer(self.page_msg)

    def demarrer_session(self):
        if self.etat != "accueil":
            return
        if self.camera is None:
            self.etat = "connexion"
            self.message("Connexion à l'appareil photo…")
            self.reconnecter_camera(self._apres_connexion)
            return
        self._lancer()

    def _gabarit(self, chemin):
        """Gabarits mis en cache (l'analyse d'un fond prend un peu de temps)."""
        if not chemin:
            return Gabarit(None)
        try:
            cle = (chemin, os.path.getmtime(chemin),
                   os.path.getmtime(Gabarit.chemin_disposition(chemin))
                   if os.path.isfile(Gabarit.chemin_disposition(chemin)) else 0)
        except OSError:
            return Gabarit(None)
        if cle not in self._cache_gabarits:
            self._cache_gabarits[cle] = Gabarit(chemin)
        return self._cache_gabarits[cle]

    def _apres_connexion(self, err):
        if err:
            log.error("Appareil photo indisponible : %s", err)
            self.message("L'appareil photo se prépare…\nPrévenez l'organisateur si ça dure.")
            self.root.after(5000, self.afficher_accueil)
        else:
            self.etat = "accueil"
            self._lancer()

    def _formats_proposes(self):
        """[(chemin 10x15, chemin bandelette)] si l'invité peut choisir, sinon None."""
        if not self.cfg.get("choix_format", True):
            return None
        a, b = self.cfg.get("fond", ""), self.cfg.get("fond_bande", "")
        ca, cb = os.path.join(FONDS_DIR, a), os.path.join(FONDS_DIR, b)
        if a and b and a != b and os.path.isfile(ca) and os.path.isfile(cb):
            return ca, cb
        return None

    def _choisir_format(self, chemins):
        self.etat = "choix"
        self._armer_retour()
        p = self.page_format
        for w in p.winfo_children():
            w.destroy()
        tk.Label(p, image=self.titre_image("Quel format ?", self.p(70)), bg=NUIT).pack(pady=(self.p(30), self.p(6)))
        ligne = tk.Frame(p, bg=NUIT)
        ligne.pack(expand=True)
        self._tk_formats = []
        for chemin in chemins:
            g = self._gabarit(chemin)
            bande = est_bandelette(g.taille)
            apercu = feuille_bandelettes(g.apercu_exemple()) if bande else g.apercu_exemple()
            img = ImageTk.PhotoImage(img_cadre_photo(apercu, int(self.W * 0.36), int(self.H * 0.52)))
            self._tk_formats.append(img)
            col = tk.Frame(ligne, bg=NUIT)
            col.pack(side="left", padx=self.p(30))
            vignette = tk.Label(col, image=img, bg=NUIT, cursor="hand2")
            vignette.pack()
            titre = "Bandelettes" if bande else "Photo 10x15"
            detail = (f"2 bandelettes identiques · {g.nb_photos} photo{'s' if g.nb_photos > 1 else ''}" if bande
                      else f"{g.nb_photos} photo{'s' if g.nb_photos > 1 else ''} · format carte postale")
            self.bouton(col, titre, lambda c=chemin: self._format_choisi(c)).pack(pady=(self.p(8), 0))
            tk.Label(col, text=detail, bg=NUIT, fg=TXT, font=(TEXTE, self.p(22))).pack()
            vignette.bind("<ButtonRelease-1>", lambda e, c=chemin: self._format_choisi(c))
        self.bouton(p, "Annuler", self.afficher_accueil, False).pack(pady=self.p(20))
        self.montrer(p)

    def _format_choisi(self, chemin):
        if self.etat != "choix":
            return
        self._annuler_retour()
        self._lancer(choisi=chemin)

    def _lancer(self, choisi=None):
        if choisi is None:
            formats = self._formats_proposes()
            if formats:
                return self._choisir_format(formats)
            self.g_session = self.gabarit
        else:
            self.g_session = self._gabarit(choisi)
        self._annuler_retour()
        self._stat("seances")
        self.etat = "prise"
        self.photos = []
        self.session = datetime.now().strftime("%Y%m%d_%H%M%S")
        self.jour = datetime.now().strftime("%Y-%m-%d")
        if nom_dossier(self.cfg.get("evenement", "")):
            self.jour += " - " + nom_dossier(self.cfg["evenement"])
        self._fige = False
        try:
            self.camera.demarrer_apercu()
        except Exception as e:
            log.warning("Aperçu : %s", e)
        self.c_live.itemconfig(self.id_live, image="")
        self._texte("")
        self._anneau(False)
        self._masquer_refaire()
        n = self.g_session.nb_photos
        self.c_live.itemconfig(self.id_info, text=f"{n} photos, préparez-vous !" if n > 1
                               else "Préparez-vous !")
        self.montrer(self.c_live)
        self.root.after(900, self._reprendre_le_dessus)
        self._boucle_apercu()
        self.root.after(1800, self._compte, int(self.cfg["compte_a_rebours"]))

    def _reprendre_le_dessus(self):
        if self.reglages_ouverts:
            return
        # La fenêtre d'aperçu de digiCamControl peut passer devant : on revient au premier plan
        self.root.lift()
        self.root.attributes("-topmost", True)
        self.root.focus_force()

    def _boucle_apercu(self):
        """Démarre la préparation des images (fil séparé) et leur affichage (écran)."""
        self._apercu_pret = None
        self._n_affiche = -1
        self._compteur_fps = []
        self._conseil = ""
        self._compte_en_cours = False
        if not self.cfg.get("afficher_fps"):
            self.c_live.itemconfig("fps", state="hidden")
        session = self.session
        threading.Thread(target=self._preparer_apercu, args=(session,), daemon=True).start()
        self._afficher_apercu(session)

    def _preparer_apercu(self, session):
        """Redimensionne et retourne les images hors de l'écran, pour une vue fluide."""
        dernier = -1
        while self.etat == "prise" and self.session == session:
            cam = self.camera
            n = getattr(cam, "n_image", None) if cam is not None else None
            if self._fige or cam is None or n == dernier:
                time.sleep(0.008)
                continue
            img = cam.apercu()
            if img is None:
                time.sleep(0.02)
                continue
            dernier = n
            try:
                img = self._cadrer(img)
                if self.cfg.get("aide_cadrage", True) and time.time() - getattr(self, "_t_visages", 0) > 0.4:
                    self._t_visages = time.time()
                    try:
                        self._conseil = conseil_cadrage(img)
                    except Exception:
                        self._conseil = ""
                img = ImageOps.contain(img, (self.W, self.H), Image.BILINEAR)
                if self.cfg["miroir"]:
                    img = ImageOps.mirror(img)
                self._apercu_pret = (n, img)
            except Exception:
                time.sleep(0.05)

    def _cadrer(self, img):
        """Montre uniquement la partie de l'image qui ira dans l'emplacement de la photo en cours."""
        if not self.cfg.get("cadrage_exact", True):
            return img
        zones = self.g_session.zones
        x, y, w, h = zones[min(len(self.photos), len(zones) - 1)]
        return recadrer(img, w / h)

    def _afficher_apercu(self, session):
        if self.etat != "prise" or self.session != session:
            return
        pret = self._apercu_pret
        if pret is not None and not self._fige and pret[0] != self._n_affiche:
            self._n_affiche = pret[0]
            img = pret[1]
            tkimg = getattr(self, "_tk_apercu", None)
            if tkimg is not None and (tkimg.width(), tkimg.height()) == img.size:
                tkimg.paste(img)                       # mise à jour sur place : rapide
            else:
                self._tk_apercu = ImageTk.PhotoImage(img)
            if self.c_live.itemcget(self.id_live, "image") != str(self._tk_apercu):
                self.c_live.itemconfig(self.id_live, image=self._tk_apercu)
            conseil = getattr(self, "_conseil", "") if self._compte_en_cours else ""
            if self.c_live.itemcget("conseil", "text") != conseil:
                self.c_live.itemconfig("conseil", text=conseil)
                self.c_live.itemconfig("conseil_fond", state="normal" if conseil else "hidden")
                if conseil:
                    x0, y0, x1, y1 = self.c_live.bbox("conseil")
                    self.c_live.coords("conseil_fond", x0 - self.p(24), y0 - self.p(10), x1 + self.p(24), y1 + self.p(10))
            if self.cfg.get("afficher_fps"):
                self._compteur_fps.append(time.time())
                self._compteur_fps = [t for t in self._compteur_fps if time.time() - t < 1]
                cam = self.camera
                src = getattr(cam, "fps_source", 0) if cam else 0
                self.c_live.itemconfig("fps", text=f"Écran : {len(self._compteur_fps)} img/s · "
                                                   f"Appareil : {src:.0f} img/s", state="normal")
            else:
                self.c_live.itemconfig("fps", state="hidden")      # option décochée : on l'efface
        self.root.after(10, self._afficher_apercu, session)

    def _texte(self, t, taille=260):
        police = (TITRE, self.p(taille), "bold")
        self.c_live.itemconfig(self.id_texte, text=t, font=police)
        self.c_live.itemconfig(self.id_ombre, text=t, font=police)

    def _anneau(self, visible):
        etat = "normal" if visible else "hidden"
        self.c_live.itemconfig(self.id_anneau, state=etat)
        self.c_live.itemconfig(self.id_anneau_fond, state=etat)

    def _tourner_anneau(self, debut, etape=0):
        if self.etat != "prise":
            return
        f = min(1, (time.time() - debut))
        self.c_live.itemconfig(self.id_anneau, extent=max(0.1, 359.9 * (1 - f)),
                               outline=CHAMPAGNE if f < 0.5 else ROSE)
        if f < 1:
            self.root.after(30, self._tourner_anneau, debut)

    def _compte(self, n):
        if self.etat != "prise":
            return
        self._compte_en_cours = n > 0
        if n > 0:
            if self.cfg.get("sons"):
                jouer_son("bip.wav")
            self._texte(str(n))
            self._anneau(True)
            self._tourner_anneau(time.time())
            self.root.after(1000, self._compte, n - 1)
        else:
            self._anneau(False)
            self._texte("Ne bougez plus !", 130)
            self.c_live.itemconfig(self.id_info, text="Mise au point…")
            self._capturer()

    def _flash(self):
        """Éclair blanc et déclic au moment exact où l'appareil prend la photo."""
        if self.etat != "prise":
            return
        if self.cfg.get("sons"):
            jouer_son("declic.wav")
        self._texte("")
        self.c_live.itemconfig(self.id_info, text="")
        self.c_live.itemconfig(self.id_flash, state="normal")
        self.root.after(160, lambda: self.c_live.itemconfig(self.id_flash, state="hidden"))

    def _capturer(self):
        rang = len(self.photos) + 1
        dossier = os.path.join(ORIG_DIR, self.jour)
        cam = self.camera

        def travail():
            try:
                nom = f"{self.session}_{rang}"
                n = 2
                while glob.glob(os.path.join(dossier, nom + ".*")):   # photo refaite : on garde les deux
                    nom = f"{self.session}_{rang}_essai{n}"
                    n += 1
                chemin = cam.capturer(dossier, nom,
                                      au_declenchement=lambda: self.dans_ui(self._flash))
                copier_secours(self.cfg, chemin)
                self.dans_ui(self._photo_ok, charger_photo(chemin))
            except Exception as e:
                log.exception("Capture")
                self.dans_ui(self._photo_ko, str(e))
        threading.Thread(target=travail, daemon=True).start()

    def _photo_ok(self, img):
        if self.etat != "prise":
            return
        self._compte_en_cours = False
        self.c_live.itemconfig("conseil", text="")
        self.c_live.itemconfig("conseil_fond", state="hidden")
        self._texte("")
        self._stat("photos")
        vue = ImageOps.contain(self._cadrer(img), (self.W, self.H), Image.BILINEAR)
        self.photos.append(img)
        self._fige = True
        self._tk_live = ImageTk.PhotoImage(vue)
        self.c_live.itemconfig(self.id_live, image=self._tk_live)
        self._n_affiche = -1                           # l'aperçu reprendra l'image en direct ensuite
        if len(self.photos) >= self.g_session.nb_photos:
            self._preparer_montage()               # pendant que l'invité regarde sa photo
        if self.cfg.get("proposer_refaire", True):
            self._proposer_refaire(5)
        else:
            self._continuer()

    def _preparer_montage(self):
        photos, gab, filtre = list(self.photos), self.g_session, self.cfg.get("filtre", "aucun")
        cle = (tuple(id(p) for p in photos), filtre, id(gab))
        self._montage_pret = (cle, None)
        W, H = self.W, self.H

        def travail():
            try:
                montage = gab.composer([appliquer_filtre(p, filtre) for p in photos])
                vue = img_cadre_photo(montage, int(W * 0.68), int(H * 0.96))
                if self._montage_pret and self._montage_pret[0] == cle:
                    self._montage_pret = (cle, (montage, vue))
            except Exception:
                log.exception("Montage préparé")
        threading.Thread(target=travail, daemon=True).start()

    def _continuer(self):
        """Photo gardée : photo suivante ou montage."""
        if self.etat != "prise":
            return
        self._masquer_refaire()
        total = self.g_session.nb_photos
        if len(self.photos) < total:
            self.c_live.itemconfig(self.id_info, text=f"Photo {len(self.photos) + 1} sur {total}")
            self.root.after(1200, self._suivante)
        else:
            self.c_live.itemconfig(self.id_info, text="")
            self.root.after(500, self._assembler)

    def _proposer_refaire(self, secondes):
        c = self.c_live
        if self.etat != "prise":
            return
        if secondes == 5:
            self._jeton_refaire = getattr(self, "_jeton_refaire", 0) + 1
            for tag in ("refaire", "garder", "refaire_txt"):
                c.itemconfig(tag, state="normal")
                c.tag_raise(tag)
        if secondes <= 0:
            return self._continuer()
        c.itemconfig("refaire_txt", text=f"Suite automatique dans {secondes} s")
        jeton = self._jeton_refaire
        self.root.after(1000, lambda: self._proposer_refaire(secondes - 1)
                        if self._jeton_refaire == jeton and c.itemcget("garder", "state") == "normal"
                        else None)

    def _masquer_refaire(self):
        self._jeton_refaire = getattr(self, "_jeton_refaire", 0) + 1
        for tag in ("refaire", "garder", "refaire_txt"):
            self.c_live.itemconfig(tag, state="hidden")

    def _refaire(self, _e=None):
        if self.etat != "prise" or self.c_live.itemcget("refaire", "state") != "normal":
            return
        self._masquer_refaire()
        self._montage_pret = None
        if self.photos:
            self.photos.pop()            # l'original reste quand même enregistré
        self.c_live.itemconfig(self.id_info, text="On recommence !")
        self.root.after(800, self._suivante)

    def _garder(self, _e=None):
        if self.etat == "prise" and self.c_live.itemcget("garder", "state") == "normal":
            self._continuer()

    def _suivante(self):
        self._fige = False
        self._compte(int(self.cfg["compte_a_rebours"]))

    def _photo_ko(self, err):
        try:
            self.camera.arreter_apercu()
        except Exception:
            pass
        self.etat = "erreur"
        log.error("Photo non prise : %s", err)          # le détail reste dans le journal
        self.message("Oups ! La photo n'a pas pu être prise.\nOn réessaie dans un instant…")
        self.root.after(4000, self.afficher_accueil)

    def _assembler(self):
        self.etat = "traitement"
        try:
            self.camera.arreter_apercu()
        except Exception:
            pass
        photos, jour, session, gab = list(self.photos), self.jour, self.session, self.g_session
        filtre, cfg = self.cfg.get("filtre", "aucun"), self.cfg
        cle = (tuple(id(p) for p in photos), filtre, id(gab))
        pret = getattr(self, "_montage_pret", None)
        deja = pret[1] if pret and pret[0] == cle and pret[1] else None
        if deja is None:
            self.message("Préparation de votre photo…")

        def travail():
            try:
                if deja is not None:
                    montage, vue = deja
                else:
                    attente = time.time()           # montage presque fini ? on l'attend un peu
                    while time.time() - attente < 3:
                        p = getattr(self, "_montage_pret", None)
                        if p and p[0] == cle and p[1]:
                            break
                        if not (p and p[0] == cle):
                            break
                        time.sleep(0.05)
                    p = getattr(self, "_montage_pret", None)
                    if p and p[0] == cle and p[1]:
                        montage, vue = p[1]
                    else:
                        montage = gab.composer([appliquer_filtre(p, filtre) for p in photos])
                        vue = None
                self._vue_prete = vue
                dossier = os.path.join(MONT_DIR, jour)
                os.makedirs(dossier, exist_ok=True)
                chemin = os.path.join(dossier, f"PB_{session}_{uuid.uuid4().hex[:6]}.jpg")
                montage.save(chemin, quality=95, dpi=(300, 300))
                log.info("Montage enregistré : %s", chemin)
                copier_secours(cfg, chemin)
                self.dans_ui(self.afficher_resultat, chemin, montage)
            except Exception as e:
                log.exception("Montage")
                self.dans_ui(self._photo_ko, str(e))
        threading.Thread(target=travail, daemon=True).start()

    # ---- résultat ----------------------------------------------------------
    def afficher_resultat(self, chemin, montage):
        self.etat = "resultat"
        self.montage_chemin = chemin
        self.imprime = False
        self.url_qr = None
        self._montage_pret = None
        self.est_bande = est_bandelette(montage.size)
        vue = getattr(self, "_vue_prete", None) or img_cadre_photo(montage, int(self.W * 0.68), int(self.H * 0.96))
        self._vue_prete = None
        self._tk_res = ImageTk.PhotoImage(vue)
        self.page_res.itemconfig(self.id_res, image=self._tk_res)
        self.page_res.itemconfig(self.id_toast, text="")
        self._filtre_base = self.cfg.get("filtre", "aucun")
        self.nb_actif = self._filtre_base == "noir et blanc"
        self._nb_en_cours = False
        if self.cfg.get("proposer_nb", True) and getattr(self, "photos", None):
            self.page_res.itemconfig(self.id_nb, image=self._tk_nb[self.nb_actif], state="normal")
            self.page_res.tag_raise("nb")
        else:
            self.page_res.itemconfig(self.id_nb, state="hidden")
        self._boutons_resultat()
        self.montrer(self.page_res)
        self._armer_retour()

    def _basculer_nb(self, _e=None):
        """Un appui : la photo passe en noir et blanc, ou revient en couleur."""
        if self.etat != "resultat" or self._nb_en_cours:
            return
        self._nb_en_cours = True
        self._armer_retour()
        nb = not self.nb_actif
        filtre = "noir et blanc" if nb else ("aucun" if self._filtre_base == "noir et blanc" else self._filtre_base)
        photos, gab, chemin, cfg = list(self.photos), self.g_session, self.montage_chemin, self.cfg
        self.page_res.itemconfig(self.id_toast, text="Un instant…")

        def travail():
            try:
                montage = gab.composer([appliquer_filtre(p, filtre) for p in photos])
                montage.save(chemin, quality=95, dpi=(300, 300))
                copier_secours(cfg, chemin)
                vue = img_cadre_photo(montage, int(self.W * 0.68), int(self.H * 0.96))
                self.dans_ui(self._nb_fait, nb, vue)
            except Exception:
                log.exception("Noir et blanc")
                self.dans_ui(self._nb_fait, self.nb_actif, None)
        threading.Thread(target=travail, daemon=True).start()

    def _nb_fait(self, nb, vue):
        self._nb_en_cours = False
        if self.etat != "resultat":
            return
        self.page_res.itemconfig(self.id_toast, text="")
        if vue is not None:
            self.nb_actif = nb
            self.url_qr = None                      # le QR code renverra la nouvelle version
            self._tk_res = ImageTk.PhotoImage(vue)
            self.page_res.itemconfig(self.id_res, image=self._tk_res)
            self.page_res.itemconfig(self.id_nb, image=self._tk_nb[nb])
        if self.cfg.get("animations", True):
            self._lancer_confettis()

    def _lancer_confettis(self):
        c = self.page_res
        for item, *_ in self._confettis:
            c.delete(item)
        self._confettis = []
        couleurs = (CHAMPAGNE, ROSE, CYAN, BLANC, "#FFD23F")
        for _ in range(150):
            x = random.uniform(0, self.W * 0.72)
            y = random.uniform(-self.H, -10)
            w, h = random.uniform(8, 16) * self.k, random.uniform(14, 26) * self.k
            item = c.create_rectangle(x, y, x + w, y + h, fill=random.choice(couleurs), outline="")
            c.tag_lower(item, self.id_res) if random.random() < 0.3 else None
            self._confettis.append([item, x, y, w, h, random.uniform(-1.5, 1.5) * self.k,
                                    random.uniform(5, 11) * self.k, random.uniform(0, 6.28)])
        self._t_confettis = time.time()
        self._animer_confettis()

    def _animer_confettis(self):
        c = self.page_res
        if self.etat not in ("resultat",) or time.time() - self._t_confettis > 4.5:
            for item, *_ in self._confettis:
                c.delete(item)
            self._confettis = []
            return
        for cf in self._confettis:
            item, x, y, w, h, vx, vy, ph = cf
            cf[1], cf[2], cf[7] = x + vx + math.sin(ph) * 1.2, y + vy, ph + 0.18
            lw = w * abs(math.cos(ph))                  # effet de rotation
            c.coords(item, cf[1], cf[2], cf[1] + max(1, lw), cf[2] + h)
        self.root.after(30, self._animer_confettis)

    def _boutons_resultat(self):
        for w in self.col.winfo_children():
            w.destroy()
        lg = self.p(400)
        tk.Label(self.col, image=self.titre_image("Et voilà !", self.p(78)), bg=NUIT).pack(pady=(0, self.p(6)))
        if self.cfg["impression_active"] and not self.imprime:
            # Une fois l'impression lancée, le bouton disparaît
            if self.restantes() == 0:
                pass                                    # limite atteinte : pas de bouton, sans message
            else:
                self.bouton(self.col, "Imprimer", self.choisir_copies, largeur=lg).pack()
                if getattr(self, "est_bande", False):
                    tk.Label(self.col, text="2 bandelettes identiques", bg=NUIT, fg=CYAN,
                             font=(TEXTE, self.p(20), "bold")).pack(pady=(0, self.p(6)))
        if self.cfg["qr_actif"]:
            self.bouton(self.col, "QR code", self.afficher_qr, largeur=lg).pack()
        if self.cfg["email_actif"]:
            self.bouton(self.col, "Par e-mail", self.afficher_mail, largeur=lg).pack()
        tk.Frame(self.col, bg=NUIT, height=self.p(30)).pack()
        self.bouton(self.col, "Recommencer", self.recommencer, False, largeur=lg).pack()
        self.bouton(self.col, "Terminer", self.afficher_accueil, False, largeur=lg).pack()

    def toast(self, texte, duree=5000):
        c = self.page_res
        c.itemconfig(self.id_toast, text=texte)
        self.root.after(duree, lambda: c.itemconfig(self.id_toast, text="")
                        if c.itemcget(self.id_toast, "text") == texte else None)

    def retour_resultat(self):
        self.etat = "resultat"
        self._boutons_resultat()
        self.root.after(50, self._barre_impression)
        self.montrer(self.page_res)
        self._armer_retour()

    def recommencer(self):
        self.afficher_accueil()
        self.demarrer_session()

    def _armer_retour(self):
        self._annuler_retour()
        self._minuteur = self.root.after(int(self.cfg["delai_retour"]) * 1000, self.afficher_accueil)

    def _annuler_retour(self):
        if self._minuteur:
            self.root.after_cancel(self._minuteur)
            self._minuteur = None

    # ---- impression ----------------------------------------------------------
    def restantes(self):
        """Tirages encore autorisés pour l'événement (None = illimité)."""
        limite = int(self.cfg.get("limite_impressions") or 0)
        if limite <= 0:
            return None
        return max(0, limite - int(self.cfg.get("impressions_faites") or 0))

    def choisir_copies(self):
        if self.imprime:
            return
        if getattr(self, "est_bande", False):
            return self._confirmer_bandelettes()
        maxi = max(1, int(self.cfg["copies_max"]))
        reste = self.restantes()
        if reste is not None:
            maxi = min(maxi, reste)
        if maxi <= 0:
            self._boutons_resultat()
            return
        if maxi == 1:
            return self.imprimer(1)
        self._armer_retour()
        p = self.page_copies
        for w in p.winfo_children():
            w.destroy()
        tk.Label(p, image=self.titre_image("Combien de tirages ?", self.p(64)), bg=NUIT).pack(
            pady=(self.H * 0.2, self.p(30)))
        ligne = tk.Frame(p, bg=NUIT)
        ligne.pack()
        for n in range(1, maxi + 1):
            self.bouton(ligne, str(n), lambda n=n: self.imprimer(n)).pack(side="left", padx=self.p(14))
        self.bouton(p, "Annuler", self.retour_resultat, False).pack(pady=self.p(50))
        self.montrer(p)

    def _confirmer_bandelettes(self):
        """Bandelettes : pas de choix du nombre, on prévient que 2 bandelettes identiques sortent."""
        reste = self.restantes()
        if reste is not None and reste <= 0:
            self._boutons_resultat()
            return
        self._armer_retour()
        p = self.page_copies
        for w in p.winfo_children():
            w.destroy()
        tk.Label(p, image=self.titre_image("Vos bandelettes", self.p(64)), bg=NUIT).pack(
            pady=(self.H * 0.06, self.p(10)))
        try:
            bande = Image.open(self.montage_chemin).convert("RGB")
            feuille = feuille_bandelettes(bande)
            self._tk_feuille = ImageTk.PhotoImage(img_cadre_photo(feuille, int(self.W * 0.3), int(self.H * 0.55)))
            tk.Label(p, image=self._tk_feuille, bg=NUIT).pack()
        except Exception:
            pass
        tk.Label(p, text="Une seule impression : 2 bandelettes identiques sortent ensemble,\n"
                         "une pour vous… et une à partager !",
                 bg=NUIT, fg=TXT, font=(TITRE, self.p(30), "bold"), justify="center").pack(pady=self.p(18))
        ligne = tk.Frame(p, bg=NUIT)
        ligne.pack()
        self.bouton(ligne, "Annuler", self.retour_resultat, False).pack(side="left", padx=self.p(14))
        self.bouton(ligne, "Imprimer", lambda: self.imprimer(1)).pack(side="left", padx=self.p(14))
        self.montrer(p)

    def imprimer(self, copies):
        if self.imprime:            # protège contre les appuis répétés
            return
        reste = self.restantes()
        if reste is not None:
            copies = min(copies, reste)
            if copies <= 0:
                return self.choisir_copies()
        self.imprime = True
        self._compter(copies)
        self.retour_resultat()
        chemin, imprimante = self.montage_chemin, self.cfg["imprimante"]
        cfg_forme = self.cfg.get("forme_bandelette", "").strip()
        cfg_imp_bande = self.cfg.get("imprimante_bande", "").strip()
        duree = max(5, int(self.cfg.get("duree_impression") or 15)) + 9 * (copies - 1)
        self._suivi_impression = {"debut": time.time(), "duree": duree, "fini": False, "erreur": False,
                                  "chemin": chemin}
        self._barre_impression()

        def travail():
            try:
                img = Image.open(chemin)
                if est_bandelette(img.size):            # bandelette : 2 par feuille, coupe au milieu
                    if cfg_imp_bande:                   # imprimante déjà réglée sur la coupe
                        imprimer_photo(feuille_bandelettes(img), cfg_imp_bande, copies)
                    else:
                        nom = imprimante or win32print.GetDefaultPrinter()
                        imprimer_photo(feuille_bandelettes(img), imprimante, copies,
                                       forme_bandelette(nom, cfg_forme))
                else:
                    imprimer_photo(chemin, imprimante, copies)
                self._surveiller_file(imprimante)
            except Exception as e:
                log.exception("Impression")
                self._suivi_impression["erreur"] = True
                self.dans_ui(self._compter, -copies)
                self.dans_ui(self.toast, "Impression impossible : " + str(e)[:90], 8000)
        threading.Thread(target=travail, daemon=True).start()

    def _surveiller_file(self, imprimante):
        """La photo est sortie quand elle quitte la file d'attente de l'imprimante."""
        suivi = self._suivi_impression
        if not HAS_WIN32:
            return
        try:
            nom = imprimante or win32print.GetDefaultPrinter()
            time.sleep(2)
            while time.time() - suivi["debut"] < suivi["duree"] + 60:
                h = win32print.OpenPrinter(nom)
                try:
                    taches = win32print.EnumJobs(h, 0, 50, 1)
                finally:
                    win32print.ClosePrinter(h)
                if not any("Photobooth" in (t.get("pDocument") or "") for t in taches):
                    # La DNP prend la photo dans sa mémoire en 2-3 s, bien avant qu'elle sorte :
                    # on garde donc la durée réglée, sans jamais la raccourcir.
                    return
                # encore dans la file alors que le chrono arrive à la fin : on le prolonge un peu
                if suivi["duree"] - (time.time() - suivi["debut"]) < 3:
                    suivi["duree"] += 3
                time.sleep(1)
        except Exception as e:
            log.warning("Suivi de l'impression : %s", e)

    def _barre_impression(self):
        """Barre « Votre photo arrive dans X s » sous les boutons de l'écran résultat."""
        c, suivi = self.page_res, getattr(self, "_suivi_impression", None)
        c.delete("barre")
        if not suivi or suivi["erreur"] or self.etat not in ("resultat",) \
                or suivi.get("chemin") != getattr(self, "montage_chemin", None):
            return
        ecoule = time.time() - suivi["debut"]
        reste = suivi["duree"] - ecoule
        x0, x1 = self.W * 0.70, self.W * 0.99
        y = self.H * 0.90
        h = self.p(16)
        if reste <= 0:
            pret = "Vos 2 bandelettes sont prêtes ! 🎉" if getattr(self, "est_bande", False) \
                else "Votre photo est prête, servez-vous ! 🎉"
            c.create_text((x0 + x1) / 2, y, text=pret, tags="barre",
                          font=(TITRE, self.p(26), "bold"), fill=CYAN)
            self.root.after(6000, lambda: c.delete("barre"))
            return
        part = min(0.97, ecoule / suivi["duree"])
        c.create_text((x0 + x1) / 2, y - self.p(30), tags="barre", font=(TITRE, self.p(24), "bold"), fill=TXT,
                      text=(f"Vos bandelettes arrivent dans {int(reste) + 1} s…" if getattr(self, "est_bande", False)
                            else f"Votre photo arrive dans {int(reste) + 1} s…"))
        c.create_rectangle(x0, y, x1, y + h, fill=NUIT_CLAIR, outline="", tags="barre")
        c.create_rectangle(x0, y, x0 + (x1 - x0) * part, y + h, fill=ROSE, outline="", tags="barre")
        self.root.after(250, self._barre_impression)

    def _compter(self, n):
        self.cfg["impressions_faites"] = max(0, int(self.cfg.get("impressions_faites") or 0) + n)
        self._stat("impressions", n)

    def _stat(self, cle, n=1):
        stats = self.cfg.setdefault("stats", dict(DEFAUT["stats"]))
        stats[cle] = max(0, int(stats.get(cle, 0)) + n)
        try:
            sauver_reglages(self.cfg)
        except Exception as e:
            log.warning("Réglages non enregistrés : %s", e)

    # ---- QR code -----------------------------------------------------------
    def afficher_qr(self):
        self._evt_net.set()                 # vérifie la connexion tout de suite
        self._armer_retour()
        self.etat = "qr"
        if qrcode is None:
            return self.toast("Le module qrcode n'est pas installé.")
        if self.url_qr:
            return self._montrer_qr(self.url_qr)
        if self.cfg["qr_mode"] == "local":
            if not self.serveur:
                self._demarrer_serveur()
            if not self.serveur:
                self.retour_resultat()
                return self.toast("Le partage Wi-Fi n'a pas pu démarrer (port occupé ?)")
            return self._montrer_qr(self.serveur.url_pour(self.montage_chemin))
        self.lbl_qr_titre.config(text="Mise en ligne de votre photo…")
        self.lbl_qr.config(image="")
        self.lbl_qr_info.config(text="")
        self.montrer(self.page_qr)
        chemin, cfg = self.montage_chemin, dict(self.cfg)

        def travail():
            try:
                url = envoyer_ftp(cfg, chemin)
                self.dans_ui(self._montrer_qr, url)
            except Exception as e:
                log.exception("FTP")
                self.dans_ui(self._qr_ko, str(e))
        threading.Thread(target=travail, daemon=True).start()

    def _qr_ko(self, err):
        self.retour_resultat()
        self.toast("Pas de connexion internet pour le QR code : " + err[:60], 8000)

    def _montrer_qr(self, url):
        if self.etat != "qr":
            return
        if not self.url_qr:
            self._stat("qr")
        self.url_qr = url
        qr = qrcode.QRCode(box_size=10, border=2)
        qr.add_data(url)
        qr.make(fit=True)
        img = qr.make_image(fill_color=ENCRE, back_color="white").convert("RGB")
        cote = int(self.H * 0.48)
        img = img.resize((cote, cote), Image.NEAREST)
        img = img_carte_qr(img, self.p(24))
        self._tk_qr = ImageTk.PhotoImage(img)
        self.lbl_qr.config(image=self._tk_qr)
        self.lbl_qr_titre.config(text=self.cfg["qr_texte"])
        self.lbl_qr_info.config(text="")
        self.montrer(self.page_qr)

    # ---- e-mail --------------------------------------------------------------
    def afficher_mail(self):
        self._evt_net.set()
        self._armer_retour()
        self.etat = "mail"
        self.saisie.set("")
        self.lbl_mail_err.config(text="")
        self.accord.set(False)
        self._maj_accord()
        self.montrer(self.page_mail)

    def _valider_mail(self):
        adresse = self.saisie.get().strip()
        if not re.fullmatch(r"[^@\s]+@[^@\s]+\.[a-zA-Z]{2,}", adresse):
            self.lbl_mail_err.config(text="Cette adresse ne semble pas complète.")
            return
        if not self.accord.get():
            self.lbl_mail_err.config(text="Cochez la case d'accord ci-dessous pour recevoir la photo.")
            return
        self.emails.ajouter(adresse, self.montage_chemin)
        self._stat("emails")
        self.retour_resultat()
        self.toast(f"C'est noté, la photo part vers {adresse}")

    # ---- réglages ------------------------------------------------------------
    def ouvrir_reglages(self):
        self.reglages_ouverts = True
        self.etat = "reglages"
        self.root.attributes("-topmost", False)
        self.message("Réglages ouverts")
        FenetreReglages(self)

    def reglages_fermes(self, nouveau=None):
        self.reglages_ouverts = False
        self.root.attributes("-topmost", True)
        if nouveau is not None:
            ancien = self.cfg
            self.cfg = nouveau
            sauver_reglages(nouveau)
            cles_look = ("couleur_fond", "couleur_fond_clair", "mode", "latitude", "longitude", "animation_accueil",
                         "densite_anim",
                         "couleur_1",
                         "couleur_2", "couleur_3", "marque", "titre_accueil", "texte_accueil", "pied_accueil")
            if any(ancien.get(k) != nouveau.get(k) for k in cles_look) \
                    or mode_effectif(nouveau) != self.mode_actuel:
                self._reconstruire_interface()
            self._cache_gabarits = {}
            self.gabarit = self._gabarit(self._chemin_fond())
            if any(ancien[k] != nouveau[k] for k in ("qr_actif", "qr_mode", "port_local")):
                self._demarrer_serveur()
            if any(ancien.get(k) != nouveau.get(k) for k in ("telecommande", "port_telecommande")):
                self._demarrer_telecommande()
            if any(ancien[k] != nouveau[k] for k in ("camera", "digicam_url", "webcam_index")):
                self.reconnecter_camera()
            if nouveau.get("bloquer_clavier"):
                self._activer_verrou()
            else:
                self.retirer_verrou()
        self.afficher_accueil()

    def _bloquer_bords(self):
        """Les invités ne peuvent plus faire apparaître notifications, widgets ou barre des tâches."""
        if not self.cfg.get("bloquer_bords", True) or os.name != "nt":
            return
        import ctypes
        interieur = self.root.winfo_id()
        cadre = ctypes.windll.user32.GetParent(interieur) or interieur
        ok = bloquer_gestes_bord(cadre)
        bloquer_gestes_bord(interieur)
        log.info("Gestes de bord d'écran bloqués : %s", ok)

    def _reconstruire_interface(self):
        """Réapplique couleurs et mode (clair/sombre) à tous les écrans."""
        appliquer_theme(self.cfg)
        self.mode_actuel = mode_effectif(self.cfg)
        self._images_boutons = {}
        for w in list(self.root.winfo_children()):
            if not isinstance(w, tk.Toplevel):
                w.destroy()
        self.root.configure(bg=NUIT)
        self._construire()

    def _suivre_soleil(self):
        """En mode automatique : bascule clair/sombre au lever et au coucher du soleil."""
        try:
            if self.cfg.get("mode") == "auto" and mode_effectif(self.cfg) != self.mode_actuel \
                    and self.etat in ("accueil", "diaporama") and not self.reglages_ouverts:
                log.info("Mode automatique : passage en %s", mode_effectif(self.cfg))
                self._reconstruire_interface()
                self.afficher_accueil()
        except Exception:
            log.exception("Mode automatique")
        self.root.after(60000, self._suivre_soleil)

    def quitter(self):
        """Ferme le Photobooth à coup sûr : on range ce qu'on peut (5 s maximum), puis on s'arrête,
        même si l'appareil photo ou un service réseau ne répond plus."""
        if getattr(self, "_en_fermeture", False):
            return
        self._en_fermeture = True
        log.info("Fermeture du Photobooth")
        try:
            self.message("Fermeture…")
            self.root.update()
        except Exception:
            pass

        def nettoyer():
            for etape in (self.retirer_verrou,
                          lambda: self.prestation.desactiver(),
                          lambda: getattr(self, "telecommande", None) and self.telecommande.arreter(),
                          lambda: self.camera and self.camera.fermer(),
                          lambda: self.serveur and self.serveur.arreter()):
                try:
                    etape()
                except Exception:
                    pass
        t = threading.Thread(target=nettoyer, daemon=True)
        t.start()
        t.join(5)
        try:
            self.root.destroy()
        except Exception:
            pass
        logging.shutdown()
        os._exit(0)

    def lancer(self):
        self.root.mainloop()


# --------------------------------------------------------------------------
# Diagnostic : tout vérifier avant l'arrivée des invités
# --------------------------------------------------------------------------
class FenetreDiagnostic(tk.Toplevel):
    VERT, ROUGE, ORANGE = "#1E9E52", "#D62E2E", "#D98A00"

    def __init__(self, parent, app):
        super().__init__(parent)
        self.app = app
        self.title("Diagnostic du Photobooth")
        self.geometry("760x560")
        self.attributes("-topmost", True)
        self.transient(parent)
        ttk.Label(self, text="Vérification du matériel et des réglages", font=("Segoe UI", 13, "bold")).pack(
            anchor="w", padx=16, pady=(14, 6))
        self.cadre = ttk.Frame(self, padding=(16, 4))
        self.cadre.pack(fill="both", expand=True)
        bas = ttk.Frame(self, padding=12)
        bas.pack(fill="x")
        ttk.Button(bas, text="Relancer", command=self.lancer).pack(side="left")
        ttk.Button(bas, text="Fermer", command=self.destroy).pack(side="right")
        self.lancer()

    def lancer(self):
        for w in self.cadre.winfo_children():
            w.destroy()
        self.lignes = {}
        for cle, nom in self.verifications():
            r = len(self.lignes)
            pastille = tk.Label(self.cadre, text="…", width=3, font=("Segoe UI", 14, "bold"), fg="#888")
            pastille.grid(row=r, column=0, sticky="nw", pady=5)
            ttk.Label(self.cadre, text=nom, font=("Segoe UI", 11, "bold")).grid(row=r, column=1, sticky="nw", pady=6)
            detail = ttk.Label(self.cadre, text="Vérification…", foreground="#555", wraplength=470, justify="left")
            detail.grid(row=r, column=2, sticky="nw", pady=6, padx=(12, 0))
            self.lignes[cle] = (pastille, detail)
        cfg = dict(self.app.cfg)
        threading.Thread(target=self._tout_verifier, args=(cfg,), daemon=True).start()

    def verifications(self):
        cfg = self.app.cfg
        v = [("camera", "Appareil photo")]
        if cfg["impression_active"]:
            v.append(("imprimante", "Imprimante"))
        v += [("fond", "Fond"), ("internet", "Internet")]
        if cfg["email_actif"]:
            v.append(("email", "Envoi par e-mail"))
        if cfg["qr_actif"]:
            v.append(("qr", "QR code"))
        v.append(("disque", "Espace disque"))
        if cfg.get("dossier_secours"):
            v.append(("secours", "Copie de secours"))
        return v

    def _resultat(self, cle, niveau, texte):
        def maj():
            if not self.winfo_exists() or cle not in self.lignes:
                return
            pastille, detail = self.lignes[cle]
            symbole, couleur = {"ok": ("✔", self.VERT), "ko": ("✖", self.ROUGE),
                                "alerte": ("!", self.ORANGE)}[niveau]
            pastille.config(text=symbole, fg=couleur)
            detail.config(text=texte)
        self.app.dans_ui(maj)

    def _tout_verifier(self, cfg):
        for cle, _ in self.verifications():
            try:
                niveau, texte = getattr(self, "_v_" + cle)(cfg)
            except Exception as e:
                niveau, texte = "ko", str(e)
            self._resultat(cle, niveau, texte)

    def _v_camera(self, cfg):
        cam = self.app.camera
        if cam is None:
            return "ko", "Non connecté : " + (self.app.erreur_camera or "") + \
                " Vérifiez que l'appareil est allumé et que digiCamControl est ouvert."
        if not cam.en_ligne():
            return "ko", "L'appareil ne répond plus. Rallumez-le ou relancez digiCamControl."
        mode = {"canon": " (Canon en direct)", "digicam": " (via digiCamControl)"}.get(cfg["camera"], " (webcam)")
        return "ok", "Connecté et prêt." + mode

    def _v_imprimante(self, cfg):
        if not HAS_WIN32:
            return "ko", "Module d'impression absent."
        nom = cfg["imprimante"] or win32print.GetDefaultPrinter()
        if nom not in liste_imprimantes():
            return "ko", f"Imprimante « {nom} » introuvable. Choisissez-la dans l'onglet Impression."
        h = win32print.OpenPrinter(nom)
        try:
            info = win32print.GetPrinter(h, 2)
        finally:
            win32print.ClosePrinter(h)
        if info["Attributes"] & 0x400:
            return "ko", f"« {nom} » est hors ligne : vérifiez qu'elle est allumée et branchée."
        if info["Status"]:
            return "alerte", f"« {nom} » signale un problème (code {info['Status']}) : papier, ruban ou capot ?"
        attente = info.get("cJobs", 0)
        return "ok", f"« {nom} » prête." + (f" {attente} impression(s) en attente." if attente else "")

    def _v_fond(self, cfg):
        if not cfg["fond"]:
            return "alerte", "Aucun fond choisi : la photo sera imprimée pleine page."
        chemin = os.path.join(FONDS_DIR, cfg["fond"])
        if not os.path.isfile(chemin):
            return "ko", f"Le fond « {cfg['fond']} » a disparu du dossier Fonds."
        g = Gabarit(chemin)
        return "ok", f"« {cfg['fond']} » : {g.nb_photos} photo(s) par séance."

    def _v_internet(self, cfg):
        if self.app._tester_internet():
            return "ok", "Connecté."
        besoin = cfg["email_actif"] or (cfg["qr_actif"] and cfg["qr_mode"] == "ftp")
        if besoin:
            return "alerte", "Pas d'internet : les e-mails partiront plus tard" + \
                (", le QR code en ligne ne marchera pas." if cfg["qr_mode"] == "ftp" and cfg["qr_actif"] else ".")
        return "alerte", "Pas d'internet (pas nécessaire avec vos réglages actuels)."

    def _v_email(self, cfg):
        hote, port = cfg["smtp_hote"].strip(), int(cfg["smtp_port"])
        srv = smtplib.SMTP_SSL(hote, port, timeout=15) if port == 465 else smtplib.SMTP(hote, port, timeout=15)
        with srv:
            if port != 465:
                srv.starttls()
            srv.login(cfg["smtp_utilisateur"].strip(), cfg["smtp_mot_de_passe"])
        n = self.app.emails.en_attente()
        return "ok", f"Connexion à {hote} réussie." + (f" {n} e-mail(s) en attente d'envoi." if n else "")

    def _v_qr(self, cfg):
        if cfg["qr_mode"] == "local":
            if not self.app.serveur:
                return "ko", "Le partage Wi-Fi n'a pas démarré (port déjà utilisé ?)."
            ip = ip_locale()
            if ip.startswith("127."):
                return "ko", "Le PC n'est connecté à aucun réseau Wi-Fi : les invités ne pourront pas télécharger."
            return "ok", f"Partage Wi-Fi actif sur {ip}. Les invités doivent être sur le même réseau."
        with ftplib.FTP(cfg["ftp_hote"], timeout=15) as ftp:
            ftp.login(cfg["ftp_utilisateur"], cfg["ftp_mot_de_passe"])
        return "ok", f"Connexion FTP à {cfg['ftp_hote']} réussie."

    def _v_disque(self, cfg):
        libre = shutil.disk_usage(DATA_DIR).free / 1e9
        if libre < 2:
            return "ko", f"Seulement {libre:.1f} Go libres : faites de la place."
        if libre < 10:
            return "alerte", f"{libre:.1f} Go libres (environ {int(libre * 150)} photos)."
        return "ok", f"{libre:.0f} Go libres."

    def _v_secours(self, cfg):
        d = cfg["dossier_secours"]
        if not os.path.isdir(d):
            return "ko", f"Dossier de secours introuvable : {d} (clé USB branchée ?)."
        if not _dossier_inscriptible(d):
            return "ko", "Impossible d'écrire dans le dossier de secours."
        libre = shutil.disk_usage(d).free / 1e9
        return "ok", f"Prêt ({libre:.0f} Go libres)."


# --------------------------------------------------------------------------
# Éditeur de placement des photos
# --------------------------------------------------------------------------
class EditeurDisposition(tk.Toplevel):
    """Placement des photos, pensé pour le tactile : modèles tout prêts, aimantation, gros boutons."""
    TEINTES = ("#7C8DB5", "#B58CA9", "#8FB59E", "#C9A36B", "#8C9AA8", "#B5807C")
    AIMANT = 10           # distance d'aimantation, en pixels d'écran

    def __init__(self, parent, chemin_fond, rappel):
        super().__init__(parent)
        self.parent, self.rappel = parent, rappel
        self.g = Gabarit(chemin_fond)
        self.zones = [list(z) for z in self.g.zones]
        self.sel = 0 if self.zones else None
        self.mode, self.depart, self.guides = None, None, []
        self.title("Placer les photos : " + os.path.basename(chemin_fond))
        self.attributes("-topmost", True)
        self.transient(parent)
        self.configure(bg="#F2F2F5")
        sw, sh = self.winfo_screenwidth(), self.winfo_screenheight()
        self.geometry(f"{int(sw * 0.94)}x{int(sh * 0.9)}+{int(sw * 0.03)}+{int(sh * 0.03)}")
        W, H = self.g.taille
        self.e = min(sw * 0.62 / W, sh * 0.72 / H)
        self.cw, self.ch = round(W * self.e), round(H * self.e)
        self.POIGNEE = max(14, int(sh / 55))
        self.tk_fond = ImageTk.PhotoImage(self.g.image.resize((self.cw, self.ch), Image.LANCZOS)) \
            if self.g.image is not None else None

        police = ("Segoe UI", 12)
        gros = ("Segoe UI", 12, "bold")

        def bouton(parent, texte, cmd, principal=False):
            return tk.Button(parent, text=texte, command=cmd, font=gros if principal else police,
                             bg="#7B3FF2" if principal else "#FFFFFF", fg="white" if principal else "#1B1730",
                             activebackground="#FF3D9A", relief="flat", bd=0, padx=14, pady=10,
                             highlightthickness=1, highlightbackground="#D0CEDA", cursor="hand2")

        gauche = tk.Frame(self, bg="#F2F2F5")
        gauche.pack(side="left", fill="both", expand=True, padx=(16, 8), pady=16)
        self.cv = tk.Canvas(gauche, width=self.cw, height=self.ch, bg="#9a9a9a", highlightthickness=0)
        self.cv.pack()
        self.lbl = tk.Label(gauche, bg="#F2F2F5", fg="#1B1730", font=police, justify="left",
                            wraplength=self.cw, anchor="w")
        self.lbl.pack(fill="x", pady=(10, 0))

        droite = tk.Frame(self, bg="#F2F2F5")
        droite.pack(side="right", fill="y", padx=(8, 16), pady=16)

        tk.Label(droite, text="1. Choisir une disposition", bg="#F2F2F5", font=gros).pack(anchor="w")
        grille = tk.Frame(droite, bg="#F2F2F5")
        grille.pack(fill="x", pady=(4, 12))
        for i, (texte, code) in enumerate((("1 grande photo", "1"), ("2 côte à côte", "2h"),
                                           ("2 l'une sous l'autre", "2v"), ("3 photos", "3"),
                                           ("4 photos", "4"), ("1 grande + 2", "1+2"))):
            bouton(grille, texte, lambda c=code: self.modele(c)).grid(row=i // 2, column=i % 2, sticky="ew",
                                                                     padx=3, pady=3)
        grille.columnconfigure(0, weight=1)
        grille.columnconfigure(1, weight=1)
        bouton(droite, "Utiliser les zones transparentes du fond", self.detecter).pack(fill="x", pady=(0, 14))

        tk.Label(droite, text="2. Ajuster la photo choisie", bg="#F2F2F5", font=gros).pack(anchor="w")
        tk.Label(droite, text="Touchez une photo, faites-la glisser,\ntirez un coin pour la redimensionner.",
                 bg="#F2F2F5", fg="#555", font=police, justify="left").pack(anchor="w", pady=(2, 6))
        actions = tk.Frame(droite, bg="#F2F2F5")
        actions.pack(fill="x")
        for i, (texte, cmd) in enumerate((("+ Agrandir", lambda: self.redim(1.08)),
                                           ("− Réduire", lambda: self.redim(1 / 1.08)),
                                           ("Centrer", self.centrer), ("Mettre en n°1", self.premiere),
                                           ("Ajouter une photo", self.ajouter), ("Supprimer", self.supprimer))):
            bouton(actions, texte, cmd).grid(row=i // 2, column=i % 2, sticky="ew", padx=3, pady=3)
        actions.columnconfigure(0, weight=1)
        actions.columnconfigure(1, weight=1)

        tk.Label(droite, text="3. Options", bg="#F2F2F5", font=gros).pack(anchor="w", pady=(14, 2))
        self.v_devant = tk.BooleanVar(value=self.g.devant)
        cb_devant = tk.Checkbutton(droite, text="Le fond passe par-dessus les photos", variable=self.v_devant,
                                   command=self.dessiner, bg="#F2F2F5", font=police)
        cb_devant.pack(anchor="w")
        if self.g.image is not None and not self.g.a_transparence:
            self.v_devant.set(False)
            cb_devant.config(state="disabled")
            tk.Label(droite, text="(fond sans partie transparente : les photos passent toujours devant)",
                     bg="#F2F2F5", fg="#555", font=("Segoe UI", 10)).pack(anchor="w")
        self.v_ratio = tk.BooleanVar(value=True)
        tk.Checkbutton(droite, text="Garder les proportions", variable=self.v_ratio,
                       bg="#F2F2F5", font=police).pack(anchor="w")
        self.v_aimant = tk.BooleanVar(value=True)
        tk.Checkbutton(droite, text="Aimanter (aligner tout seul)", variable=self.v_aimant,
                       bg="#F2F2F5", font=police).pack(anchor="w")

        bas = tk.Frame(droite, bg="#F2F2F5")
        bas.pack(side="bottom", fill="x", pady=(14, 0))
        bouton(bas, "Enregistrer", self.enregistrer, True).pack(side="right", padx=3)
        bouton(bas, "Annuler", self.fermer).pack(side="right", padx=3)

        self.cv.bind("<Button-1>", self._clic)
        self.cv.bind("<B1-Motion>", self._glisser)
        self.cv.bind("<ButtonRelease-1>", self._lacher)
        for touche, (dx, dy) in {"<Left>": (-1, 0), "<Right>": (1, 0),
                                 "<Up>": (0, -1), "<Down>": (0, 1)}.items():
            self.bind(touche, lambda e, dx=dx, dy=dy: self._pousser(dx, dy, e))
        self.bind("<Delete>", lambda e: self.supprimer())
        self.protocol("WM_DELETE_WINDOW", self.fermer)
        self.dessiner()
        self.grab_set()
        self.focus_force()

    # ---- dispositions toutes prêtes ----
    def modele(self, code):
        W, H = self.g.taille
        m = int(min(W, H) * 0.045)           # marge extérieure
        e = int(min(W, H) * 0.03)            # espace entre les photos
        bas = int(H * 0.16)                  # bandeau en bas, pour le texte du fond
        x0, y0, x1, y1 = m, m, W - m, H - m - bas
        lw, lh = x1 - x0, y1 - y0
        if est_bandelette((W, H)) and code in ("2h", "2v", "3", "4", "1+2"):
            n = {"2h": 2, "2v": 2, "3": 3, "4": 4, "1+2": 3}[code]   # photos empilées
            h = (lh - (n - 1) * e) // n
            z = [(x0, y0 + i * (h + e), lw, h) for i in range(n)]
        elif code == "1":
            z = [(x0, y0, lw, lh)]
        elif code == "2h":
            w = (lw - e) // 2
            z = [(x0, y0, w, lh), (x0 + w + e, y0, w, lh)]
        elif code == "2v":
            h = (lh - e) // 2
            z = [(x0, y0, lw, h), (x0, y0 + h + e, lw, h)]
        elif code == "3":
            if W >= H:                                       # 3 côte à côte
                w = (lw - 2 * e) // 3
                z = [(x0 + i * (w + e), y0, w, lh) for i in range(3)]
            else:                                            # bande verticale
                h = (lh - 2 * e) // 3
                z = [(x0, y0 + i * (h + e), lw, h) for i in range(3)]
        elif code == "4":
            w, h = (lw - e) // 2, (lh - e) // 2
            z = [(x0 + c * (w + e), y0 + r * (h + e), w, h) for r in range(2) for c in range(2)]
        else:                                                # 1 grande + 2 petites
            if W >= H:
                gw = int((lw - e) * 0.64)
                pw, ph = lw - gw - e, (lh - e) // 2
                z = [(x0, y0, gw, lh), (x0 + gw + e, y0, pw, ph), (x0 + gw + e, y0 + ph + e, pw, ph)]
            else:
                gh = int((lh - e) * 0.6)
                pw, ph = (lw - e) // 2, lh - gh - e
                z = [(x0, y0, lw, gh), (x0, y0 + gh + e, pw, ph), (x0 + pw + e, y0 + gh + e, pw, ph)]
        self.zones = [list(map(int, zz)) for zz in z]
        self.sel = 0
        self.dessiner()

    # ---- dessin ----
    def _ecran(self, z):
        x, y, w, h = z
        return x * self.e, y * self.e, (x + w) * self.e, (y + h) * self.e

    def dessiner(self):
        c = self.cv
        c.delete("all")
        devant = self.v_devant.get()
        if self.tk_fond and not devant:
            c.create_image(0, 0, image=self.tk_fond, anchor="nw")
        for i, z in enumerate(self.zones):
            X, Y, X2, Y2 = self._ecran(z)
            c.create_rectangle(X, Y, X2, Y2, fill=self.TEINTES[i % len(self.TEINTES)], outline="")
            c.create_text((X + X2) / 2, (Y + Y2) / 2, text=str(i + 1), fill="white",
                          font=("Segoe UI", max(14, int(min(X2 - X, Y2 - Y) / 3)), "bold"))
        if self.tk_fond and devant:
            c.create_image(0, 0, image=self.tk_fond, anchor="nw")
        for gx, gy in self.guides:                           # repères d'alignement
            if gx is not None:
                c.create_line(gx * self.e, 0, gx * self.e, self.ch, fill="#21D4FD", width=2, dash=(6, 4))
            if gy is not None:
                c.create_line(0, gy * self.e, self.cw, gy * self.e, fill="#21D4FD", width=2, dash=(6, 4))
        p = self.POIGNEE
        for i, z in enumerate(self.zones):
            X, Y, X2, Y2 = self._ecran(z)
            choisie = i == self.sel
            c.create_rectangle(X, Y, X2, Y2, outline="#FF3D9A" if choisie else "white",
                               width=4 if choisie else 1, dash=() if choisie else (4, 3))
            c.create_rectangle(X, Y, X + 28, Y + 24, fill="#1B1730", outline="")
            c.create_text(X + 14, Y + 12, text=str(i + 1), fill="white", font=("Segoe UI", 11, "bold"))
            if choisie:
                for cx, cy in ((X, Y), (X2, Y), (X, Y2), (X2, Y2)):
                    c.create_oval(cx - p, cy - p, cx + p, cy + p, fill="white", outline="#FF3D9A", width=3)
        self._maj_info()

    def _maj_info(self):
        n = len(self.zones)
        t = f"{n} photo{'s' if n > 1 else ''} par séance (prises dans l'ordre des numéros)."
        if self.sel is not None and self.sel < n:
            x, y, w, h = self.zones[self.sel]
            t = (f"Photo {self.sel + 1} : {w / 300 * 2.54:.1f} × {h / 300 * 2.54:.1f} cm sur le 10x15.  " + t)
        if self.v_devant.get() and self.g.image is not None and not self.g.a_transparence:
            t = ("⚠ Ce fond n'a pas de partie transparente : par-dessus, il cachera les photos. "
                 "Décochez « Le fond passe par-dessus les photos ».  ") + t
        self.lbl.config(text=t)

    # ---- souris / doigt ----
    def _coin_touche(self, ex, ey):
        if self.sel is None or self.sel >= len(self.zones):
            return None
        X, Y, X2, Y2 = self._ecran(self.zones[self.sel])
        for nom, (cx, cy) in {"hg": (X, Y), "hd": (X2, Y), "bg": (X, Y2), "bd": (X2, Y2)}.items():
            if abs(ex - cx) <= self.POIGNEE * 1.6 and abs(ey - cy) <= self.POIGNEE * 1.6:
                return nom
        return None

    def _clic(self, e):
        self.cv.focus_set()
        coin = self._coin_touche(e.x, e.y)
        if coin:
            self.mode, self.depart = coin, (e.x / self.e, e.y / self.e, list(self.zones[self.sel]))
            return
        x, y = e.x / self.e, e.y / self.e
        for i in reversed(range(len(self.zones))):
            zx, zy, zw, zh = self.zones[i]
            if zx <= x <= zx + zw and zy <= y <= zy + zh:
                self.sel = i
                self.mode, self.depart = "deplacer", (x, y, list(self.zones[i]))
                self.dessiner()
                return
        self.mode = None
        self.dessiner()

    def _cibles(self):
        """Lignes sur lesquelles s'aimanter : bords et milieu du 10x15, bords et milieux des autres photos."""
        W, H = self.g.taille
        vx, vy = [0, W / 2, W], [0, H / 2, H]
        for i, (x, y, w, h) in enumerate(self.zones):
            if i != self.sel:
                vx += [x, x + w / 2, x + w]
                vy += [y, y + h / 2, y + h]
        return vx, vy

    def _aimanter(self, valeurs, cibles):
        """Retourne (décalage, ligne) si une des valeurs est proche d'une cible."""
        seuil = self.AIMANT / self.e
        meilleur = None
        for v in valeurs:
            for c in cibles:
                d = c - v
                if abs(d) <= seuil and (meilleur is None or abs(d) < abs(meilleur[0])):
                    meilleur = (d, c)
        return meilleur or (0, None)

    def _glisser(self, e):
        if self.sel is None or not self.mode:
            return
        x0, y0, z = self.depart
        dx, dy = e.x / self.e - x0, e.y / self.e - y0
        self.guides = []
        if self.mode == "deplacer":
            nx, ny, w, h = z[0] + dx, z[1] + dy, z[2], z[3]
            if self.v_aimant.get():
                vx, vy = self._cibles()
                ax, gx = self._aimanter((nx, nx + w / 2, nx + w), vx)
                ay, gy = self._aimanter((ny, ny + h / 2, ny + h), vy)
                nx, ny = nx + ax, ny + ay
                self.guides = [(gx, gy)]
            self.zones[self.sel] = [round(nx), round(ny), w, h]
        else:
            gauche, haut = self.mode[1] == "g", self.mode[0] == "h"
            fx = z[0] + z[2] if gauche else z[0]               # coin opposé, fixe
            fy = z[1] + z[3] if haut else z[1]
            mx = z[0] + dx if gauche else z[0] + z[2] + dx     # coin tiré
            my = z[1] + dy if haut else z[1] + z[3] + dy
            if self.v_aimant.get():
                vx, vy = self._cibles()
                ax, gx = self._aimanter((mx,), vx)
                ay, gy = self._aimanter((my,), vy)
                mx, my = mx + ax, my + ay
                self.guides = [(gx, gy)]
            w = max(60, abs(mx - fx))
            h = max(60, abs(my - fy))
            if self.v_ratio.get():
                r = z[3] / z[2]
                h = w * r
            nx = fx - w if gauche else fx
            ny = fy - h if haut else fy
            self.zones[self.sel] = [round(nx), round(ny), round(w), round(h)]
        self.dessiner()

    def _lacher(self, _e):
        self.mode = None
        self.guides = []
        self.dessiner()

    def _pousser(self, dx, dy, e):
        if self.sel is None:
            return
        pas = 20 if e.state & 0x0001 else 2
        self.zones[self.sel][0] += dx * pas
        self.zones[self.sel][1] += dy * pas
        self.dessiner()

    # ---- boutons ----
    def redim(self, facteur):
        if self.sel is None:
            return
        x, y, w, h = self.zones[self.sel]
        nw, nh = max(60, w * facteur), max(60, h * facteur)
        self.zones[self.sel] = [round(x - (nw - w) / 2), round(y - (nh - h) / 2), round(nw), round(nh)]
        self.dessiner()

    def centrer(self):
        if self.sel is None:
            return
        W, H = self.g.taille
        x, y, w, h = self.zones[self.sel]
        self.zones[self.sel] = [round((W - w) / 2), round((H - h) / 2), w, h]
        self.dessiner()

    def ajouter(self):
        W, H = self.g.taille
        w = int(W * 0.4)
        h = int(w * 2 / 3)
        decal = 40 * len(self.zones)
        self.zones.append([(W - w) // 2 + decal % 400, (H - h) // 2 + decal % 400, w, h])
        self.sel = len(self.zones) - 1
        self.dessiner()

    def supprimer(self):
        if self.sel is not None and len(self.zones) > 1:
            del self.zones[self.sel]
            self.sel = 0
            self.dessiner()
        elif len(self.zones) <= 1:
            messagebox.showinfo("Placer les photos", "Il faut garder au moins une photo.", parent=self)

    def premiere(self):
        if self.sel is not None:
            self.zones.insert(0, self.zones.pop(self.sel))
            self.sel = 0
            self.dessiner()

    def detecter(self):
        zones, devant = self.g.detecter_zones()
        self.zones = [list(z) for z in zones]
        self.v_devant.set(devant)
        self.sel = 0
        self.dessiner()

    def enregistrer(self):
        self.g.zones = [tuple(int(v) for v in z) for z in self.zones]
        self.g.devant = self.v_devant.get()
        try:
            self.g.sauver_disposition()
        except Exception as e:
            return messagebox.showerror("Placer les photos", str(e), parent=self)
        self.fermer()
        self.rappel()

    def fermer(self):
        self.grab_release()
        self.destroy()
        try:
            self.parent.grab_set()
            self.parent.focus_force()
        except tk.TclError:
            pass


# --------------------------------------------------------------------------
# Clavier intégré au logiciel (ne dépend pas du clavier tactile de Windows)
# --------------------------------------------------------------------------
class ClavierIntegre(tk.Frame):
    """Clavier AZERTY affiché DANS la fenêtre des réglages (pas une fenêtre à part : il ne peut
    donc pas se cacher derrière), qui écrit dans la dernière case touchée."""
    RANGEES = ("1234567890", "azertyuiop", "qsdfghjklm", "wxcvbn,;:!", "@.-_/'éèàç")

    def __init__(self, parent, cible):
        super().__init__(parent, bg="#1B2136", highlightthickness=2, highlightbackground="#7B3FF2")
        self.cible = cible
        self.maj = False
        self.touches = []
        # barre de titre : on la fait glisser pour déplacer le clavier
        barre = tk.Frame(self, bg="#7B3FF2", cursor="fleur")
        barre.pack(fill="x")
        poignee = tk.Label(barre, text="⠿  Clavier  (glissez ici pour le déplacer)", bg="#7B3FF2", fg="white",
                           font=("Segoe UI", 11, "bold"), pady=5)
        poignee.pack(side="left", padx=8)
        tk.Button(barre, text="✕", command=self.masquer, bg="#7B3FF2", fg="white", relief="flat", bd=0,
                  font=("Segoe UI", 13, "bold"), activebackground="#FF3D9A", takefocus=0, padx=10).pack(side="right")
        for w in (barre, poignee):
            w.bind("<ButtonPress-1>", self._debut_deplacement)
            w.bind("<B1-Motion>", self._deplacer)
        corps = tk.Frame(self, bg="#1B2136")
        corps.pack(padx=6, pady=6)
        for r in self.RANGEES:
            ligne = tk.Frame(corps, bg="#1B2136")
            ligne.pack(pady=2)
            for c in r:
                b = tk.Button(ligne, text=c, width=3, font=("Segoe UI", 14), bg="#2A3150", fg="white",
                              activebackground="#FF3D9A", activeforeground="white", relief="flat", bd=0,
                              takefocus=0, pady=4, command=lambda c=c: self.taper(c))
                b.pack(side="left", padx=1)
                if c.isalpha():
                    self.touches.append((b, c))
        bas = tk.Frame(corps, bg="#1B2136")
        bas.pack(pady=(4, 2))
        for texte, cmd, largeur in (("⇧ Maj", self.basculer_maj, 6), ("espace", lambda: self.taper(" "), 16),
                                    ("⌫", self.effacer, 5)):
            tk.Button(bas, text=texte, width=largeur, font=("Segoe UI", 13, "bold"), bg="#7B3FF2", fg="white",
                      activebackground="#FF3D9A", activeforeground="white", relief="flat", bd=0, takefocus=0,
                      pady=4, command=cmd).pack(side="left", padx=2)
        self.lbl = tk.Label(self, text="", bg="#1B2136", fg="#21D4FD", font=("Segoe UI", 11))
        self.lbl.pack(pady=(0, 6))

    def _case(self):
        w = self.cible()
        try:
            return w if w is not None and w.winfo_exists() else None
        except tk.TclError:
            return None

    def taper(self, c):
        w = self._case()
        if w is None:
            self.lbl.config(text="Touchez d'abord la case où écrire.")
            return
        if self.maj and c.isalpha():
            c = c.upper()
        try:
            w.insert("insert", c)
            w.focus_set()
        except tk.TclError:
            self.lbl.config(text="Cette case ne peut pas être modifiée au clavier.")
        if self.maj:
            self.basculer_maj()

    def effacer(self):
        w = self._case()
        if w is None:
            return
        try:
            if isinstance(w, tk.Text):
                w.delete("insert -1c")
            else:
                i = w.index("insert")
                if i > 0:
                    w.delete(i - 1)
            w.focus_set()
        except tk.TclError:
            pass

    def basculer_maj(self):
        self.maj = not self.maj
        for b, c in self.touches:
            b.config(text=c.upper() if self.maj else c)

    def masquer(self):
        self.place_forget()

    def montrer(self):
        """Affiche le clavier par-dessus la fenêtre (en bas au centre la première fois)."""
        fen = self.master
        fen.update_idletasks()
        self.update_idletasks()
        if not hasattr(self, "_pos"):
            w, h = self.winfo_reqwidth(), self.winfo_reqheight()
            self._pos = (max(0, (fen.winfo_width() - w) // 2), max(0, fen.winfo_height() - h - 90))
        self.place(x=self._pos[0], y=self._pos[1])
        self.lift()

    def _debut_deplacement(self, e):
        self._decalage = (e.x_root - self.winfo_rootx(), e.y_root - self.winfo_rooty())

    def _deplacer(self, e):
        fen = self.master
        x = e.x_root - fen.winfo_rootx() - self._decalage[0]
        y = e.y_root - fen.winfo_rooty() - self._decalage[1]
        x = max(0, min(x, fen.winfo_width() - self.winfo_width()))
        y = max(0, min(y, fen.winfo_height() - self.winfo_height()))
        self._pos = (x, y)
        self.place(x=x, y=y)


# --------------------------------------------------------------------------
# Fenêtre des réglages
# --------------------------------------------------------------------------
class FenetreReglages(tk.Toplevel):
    def __init__(self, app):
        super().__init__(app.root)
        self.app = app
        self.cfg = dict(app.cfg)
        self.vars = {}
        self.title("Réglages du Photobooth")
        self.attributes("-fullscreen", True)          # plein écran : tous les boutons restent visibles
        self.attributes("-topmost", True)
        self.transient(app.root)
        self.protocol("WM_DELETE_WINDOW", self.annuler)
        self._canvas_onglets = {}

        style = ttk.Style(self)
        style.configure("Retour.TButton", font=("Segoe UI", 14, "bold"), padding=(18, 10))
        style.configure("Gros.TButton", font=("Segoe UI", 11), padding=(12, 8))
        haut = ttk.Frame(self, padding=(10, 10, 10, 0))
        haut.pack(side="top", fill="x")
        ttk.Button(haut, text="←  Revenir à l'événement", style="Retour.TButton",
                   command=self.enregistrer).pack(side="left")
        ttk.Label(haut, text="Réglages du Photobooth", font=("Segoe UI", 16, "bold")).pack(side="left", padx=20)
        ttk.Label(haut, text=f"Version {VERSION}", foreground="#777").pack(side="right")
        credit = ttk.Frame(self, padding=(10, 4, 10, 0))
        credit.pack(side="top", fill="x")
        ttk.Label(credit, text=CREDIT, foreground="#7B3FF2", font=("Segoe UI", 10, "bold")).pack(side="left")

        bas = ttk.Frame(self, padding=(10, 6, 10, 10))
        bas.pack(side="bottom", fill="x")           # placée avant les onglets : jamais cachée

        nb = ttk.Notebook(self)
        nb.pack(fill="both", expand=True, padx=10, pady=10)
        self._nb = nb
        self.bind("<MouseWheel>", self._molette)
        if not self.cfg.get("guide_masque", False):
            self._guide(nb)
        self._general(nb)
        self._appareil(nb)
        self._apparence(nb)
        self._animation(nb)
        self._evenement(nb)
        self._fonds(nb)
        self._impression(nb)
        self._qr(nb)
        self._email(nb)

        ttk.Button(bas, text="Quitter le logiciel", style="Gros.TButton", command=self._quitter).pack(side="left")
        ttk.Button(bas, text="⌨  Clavier à l'écran", style="Gros.TButton", command=self._clavier).pack(
            side="left", padx=8)
        # clavier intégré, affiché au-dessus de la barre du bas quand on touche une case
        self._case = None
        self._cadre_clavier = ClavierIntegre(self, lambda: self._case)
        self._brancher_cases(self)
        ttk.Button(bas, text="✔  Diagnostic", style="Gros.TButton",
                   command=lambda: FenetreDiagnostic(self, self.app)).pack(side="left")
        ttk.Button(bas, text="Enregistrer", style="Gros.TButton", command=self.enregistrer).pack(side="right")
        ttk.Button(bas, text="Annuler", style="Gros.TButton", command=self.annuler).pack(side="right", padx=6)
        self.grab_set()
        self.focus_force()

    # -- outils
    def _brancher_cases(self, widget):
        """Chaque case de saisie prévient le clavier quand on la touche."""
        for enfant in widget.winfo_children():
            lecture_seule = False
            try:
                lecture_seule = str(enfant.cget("state")) == "readonly"
            except tk.TclError:
                pass
            if isinstance(enfant, (tk.Entry, ttk.Entry, tk.Text, tk.Spinbox)) and not lecture_seule:
                enfant.bind("<FocusIn>", lambda e, w=enfant: self._case_touchee(w), add="+")
                enfant.bind("<ButtonRelease-1>", lambda e, w=enfant: self._case_touchee(w), add="+")
            self._brancher_cases(enfant)

    def _case_touchee(self, w):
        self._case = w
        if self.app.cfg.get("clavier_auto", True) and not self._cadre_clavier.winfo_ismapped():
            self._montrer_clavier()

    def _montrer_clavier(self):
        self._cadre_clavier.montrer()

    def _clavier(self):
        if self._cadre_clavier.winfo_ismapped():
            self._cadre_clavier.masquer()
        else:
            self._montrer_clavier()

    def _onglet(self, nb, titre):
        """Onglet qui défile si son contenu dépasse la hauteur de l'écran."""
        exterieur = ttk.Frame(nb)
        nb.add(exterieur, text=titre)
        fond = ttk.Style(self).lookup("TFrame", "background") or "#F0F0F0"
        cv = tk.Canvas(exterieur, highlightthickness=0, bd=0, bg=fond)
        barre = ttk.Scrollbar(exterieur, orient="vertical", command=cv.yview)
        f = ttk.Frame(cv, padding=16)
        fenetre = cv.create_window(0, 0, window=f, anchor="nw")
        f.bind("<Configure>", lambda e: cv.configure(scrollregion=cv.bbox("all")))
        cv.bind("<Configure>", lambda e: cv.itemconfig(fenetre, width=e.width))
        cv.configure(yscrollcommand=barre.set)
        barre.pack(side="right", fill="y")
        cv.pack(side="left", fill="both", expand=True)
        # glisser le doigt sur le fond de l'onglet pour faire défiler
        cv.bind("<ButtonPress-1>", lambda e: cv.scan_mark(0, e.y))
        cv.bind("<B1-Motion>", lambda e: cv.scan_dragto(0, e.y, gain=1))
        f.bind("<ButtonPress-1>", lambda e: cv.scan_mark(0, e.y_root))
        f.bind("<B1-Motion>", lambda e: cv.scan_dragto(0, e.y_root, gain=1))
        self._canvas_onglets[str(exterieur)] = cv
        return f

    def _molette(self, e):
        try:
            cv = self._canvas_onglets.get(self._nb.select())
            if cv is not None:
                cv.yview_scroll(int(-e.delta / 120) * 3, "units")
        except tk.TclError:
            pass

    def _ligne(self, parent, label, cle, type_=str, largeur=44, secret=False):
        r = parent.grid_size()[1]
        if type_ is bool:
            v = tk.BooleanVar(value=bool(self.cfg[cle]))
            ttk.Checkbutton(parent, text=label, variable=v).grid(row=r, column=0, columnspan=3,
                                                                 sticky="w", pady=4)
        else:
            ttk.Label(parent, text=label).grid(row=r, column=0, sticky="w", pady=4, padx=(0, 12))
            v = tk.StringVar(value=str(self.cfg[cle]))
            w = ttk.Spinbox(parent, from_=0, to=99999, textvariable=v, width=8) if type_ is int \
                else ttk.Entry(parent, textvariable=v, width=largeur, show="•" if secret else "")
            w.grid(row=r, column=1, sticky="w", pady=4)
        self.vars[cle] = (v, type_)
        return v

    def _note(self, parent, texte):
        r = parent.grid_size()[1]
        ttk.Label(parent, text=texte, foreground="#555", wraplength=820, justify="left").grid(
            row=r, column=0, columnspan=3, sticky="w", pady=(10, 4))

    def _boutons(self, parent, *paires):
        r = parent.grid_size()[1]
        f = ttk.Frame(parent)
        f.grid(row=r, column=0, columnspan=3, sticky="w", pady=(12, 4))
        for texte, cmd in paires:
            ttk.Button(f, text=texte, command=cmd).pack(side="left", padx=(0, 8))

    def _collecter(self):
        cfg = dict(self.cfg)
        for cle, (v, type_) in self.vars.items():
            val = v.get()
            if type_ is int:
                try:
                    val = int(str(val).strip())
                except ValueError:
                    raise ValueError(f"« {cle} » doit être un nombre.")
            cfg[cle] = val
        for cle in ("couleur_fond", "couleur_fond_clair", "couleur_1", "couleur_2", "couleur_3"):
            if not re.fullmatch(r"#[0-9a-fA-F]{6}", str(cfg[cle]).strip()):
                raise ValueError(f"La couleur « {cfg[cle]} » doit s'écrire comme #7B3FF2.")
        if hasattr(self, "_v_animation"):
            cfg["animation_accueil"] = self._v_animation.get()
            cfg["densite_anim"] = float(self._v_densite.get())
        if hasattr(self, "_v_mode_format"):
            photo = self._v_fond_photo.get()
            photo = "" if photo == self.AUCUN_PHOTO else photo
            bande = self._v_fond_bande.get()
            bande = "" if bande == self.AUCUN_BANDE else bande
            mode = self._v_mode_format.get()
            if (mode == "bande" and not bande) or (mode == "choix" and not (photo and bande)):
                mode = "photo"                       # réglage incomplet : photo 10x15 par défaut
            cfg["fond_photo"], cfg["fond_bande"] = photo, bande
            cfg["fond"] = bande if mode == "bande" else photo
            cfg["choix_format"] = (mode == "choix")
        if getattr(self, "_nouvelle_adresse_test", None):
            cfg["url_mise_a_jour"] = self._nouvelle_adresse_test
            cfg["canal_test"] = True
        if not hasattr(self, "_v_mode_format"):
            cfg["fond"] = self.fond_choisi
        cfg["email_message"] = self.txt_message.get("1.0", "end").strip()
        return cfg

    # -- onglets
    # -- Encart « Mise en route » : tout ce qu'il faut faire une seule fois
    ETAPES_GUIDE = (
        ("camera", "📷", "Installer le kit de l'appareil photo Canon",
         "Installez digiCamControl (gratuit). Le Photobooth s'en sert UNIQUEMENT pour récupérer le kit "
         "officiel Canon qu'il contient : inutile de l'ouvrir ou de le régler, mais ne le désinstallez jamais.\n"
         "• Réglages > Appareil photo : choisissez « Reflex Canon en direct ».\n"
         "• Sur l'appareil : photos en JPEG (pas RAW), mise au point auto, arrêt automatique désactivé. "
         "Un adaptateur secteur évite la panne de batterie.",
         (("Télécharger digiCamControl", "https://digicamcontrol.com/download"),)),
        ("pilote", "🖨", "Installer le pilote de l'imprimante DNP",
         "Téléchargez le pilote de votre DNP (ex. DS-RX1HS) sur le site DNP, installez-le, puis branchez "
         "l'imprimante. Pour la coupe des bandelettes, l'imprimante doit avoir le micrologiciel V.1.10 "
         "ou plus récent.\n"
         "• Paramètres Windows > Imprimantes : décochez « Laisser Windows gérer mon imprimante par défaut ».",
         (("Site des pilotes DNP", "https://www.dnpphoto.eu"), ("Ouvrir les imprimantes Windows", "ms-settings:printers"))),
        ("double", "✂", "Créer une 2e imprimante « bandelettes »",
         "Chez DNP, la coupe en 2 n'est pas un format de papier : c'est une option du pilote. On crée donc "
         "une deuxième imprimante, réglée sur la coupe.\n"
         "• Paramètres > Imprimantes > Ajouter un périphérique > « Ajouter manuellement ».\n"
         "• « Ajouter une imprimante locale… » > port existant : le même que la DNP (ex. USB001).\n"
         "• Pilote : Dai Nippon Printing > DS-RX1 > « Utiliser le pilote actuellement installé ».\n"
         "• Nom : DS-RX1 bandelettes. Ne la mettez PAS par défaut.",
         (("Ouvrir les imprimantes Windows", "ms-settings:printers"),)),
        ("coupe", "⚙", "Régler la coupe (à 2 endroits sur chaque imprimante !)",
         "Windows garde deux réglages par imprimante : il faut changer LES DEUX.\n"
         "• Endroit 1 : Préférences d'impression > Avancé… > « 2inch cut ».\n"
         "• Endroit 2 : Propriétés de l'imprimante > onglet Avancé > Valeurs par défaut… > Avancé… > « 2inch cut ».\n"
         "→ DS-RX1 : Disable aux 2 endroits (photos 10x15 entières). C'est l'imprimante par défaut.\n"
         "→ DS-RX1 bandelettes : Enable aux 2 endroits (bandelettes coupées).",
         (("Ouvrir les imprimantes Windows", "ms-settings:printers"),)),
        ("logiciel", "✔", "Choisir les imprimantes dans le Photobooth",
         "Onglet Impression :\n"
         "• Imprimante : DS-RX1 (celle SANS « bandelettes »).\n"
         "• Bandelettes : imprimante dédiée : DS-RX1 bandelettes.\n"
         "• Durée d'impression : le temps réel de sortie d'une photo (ex. 21 s), pour le chrono des invités.\n"
         "Enregistrez, puis faites les deux pages test : la 10x15 doit sortir entière, la bandelette coupée.",
         (("→ Aller à l'onglet Impression", "onglet:Impression"),)),
        ("fonds", "🖼", "Préparer vos fonds",
         "Onglet Fonds : ① un fond 10x15 (1800 x 1200 ou 1200 x 1800 px), ② un fond bandelette "
         "(600 x 1800 px), ③ ce que les invités impriment.\n"
         "• « Importer mon fond… » puis « ✎ Placer les photos » (ex. « 3 photos » pour une bandelette).\n"
         "• Fond plein : les photos passent devant. Fond PNG avec des trous transparents : il passe par-dessus.",
         (("→ Aller à l'onglet Fonds", "onglet:Fonds"),)),
        ("essai", "🎉", "Faire un essai complet",
         "Appuyez sur « ✔ Diagnostic » en bas de l'écran : tout doit être vert. Puis revenez à l'événement "
         "et faites une vraie séance, en 10x15 et en bandelettes.",
         (("Lancer le diagnostic", "diagnostic"),)),
    )

    def _guide(self, nb):
        f = self._onglet(nb, "🚀 Mise en route")
        self._onglet_guide = nb.tabs()[-1]
        faites = set(self.app.cfg.get("guide_etapes", []))
        VIOLET, ROSE, VERT = "#7B3FF2", "#E0457B", "#22A06B"

        entete = tk.Frame(f, bg=VIOLET)
        entete.pack(fill="x", pady=(0, 12))
        tk.Label(entete, text="Bienvenue ! Mise en route du Photobooth", bg=VIOLET, fg="white",
                 font=("Segoe UI", 18, "bold")).pack(anchor="w", padx=18, pady=(14, 2))
        tk.Label(entete, bg=VIOLET, fg="#E9E0FF", font=("Segoe UI", 11), justify="left", wraplength=1100,
                 text="À faire une seule fois. Cochez chaque étape une fois faite. Quand tout est réglé, "
                      "masquez cet encart : vous pourrez toujours le retrouver dans l'onglet Général.").pack(
            anchor="w", padx=18, pady=(0, 6))
        self._lbl_progres = tk.Label(entete, bg=VIOLET, fg="white", font=("Segoe UI", 11, "bold"))
        self._lbl_progres.pack(anchor="w", padx=18, pady=(0, 4))
        self._barre_progres = tk.Canvas(entete, height=10, bg="#5A2BC0", highlightthickness=0)
        self._barre_progres.pack(fill="x", padx=18, pady=(0, 14))

        self._v_etapes = {}
        for n, (cle, icone, titre, texte, actions) in enumerate(self.ETAPES_GUIDE, 1):
            carte = tk.Frame(f, bg="white", highlightbackground="#E3DDF2", highlightthickness=1)
            carte.pack(fill="x", pady=5)
            bande = tk.Frame(carte, bg=VERT if cle in faites else ROSE, width=8)
            bande.pack(side="left", fill="y")
            corps = tk.Frame(carte, bg="white")
            corps.pack(side="left", fill="both", expand=True, padx=14, pady=10)
            ligne = tk.Frame(corps, bg="white")
            ligne.pack(fill="x")
            tk.Label(ligne, text=f"{n}", bg=VIOLET, fg="white", width=2,
                     font=("Segoe UI", 12, "bold")).pack(side="left")
            tk.Label(ligne, text=f"  {icone}  {titre}", bg="white", fg="#222",
                     font=("Segoe UI", 13, "bold")).pack(side="left")
            v = tk.BooleanVar(value=cle in faites)
            self._v_etapes[cle] = v
            tk.Checkbutton(ligne, text="C'est fait", variable=v, bg="white", activebackground="white",
                           font=("Segoe UI", 11), command=lambda c=cle, b=bande: self._etape_cochee(c, b)
                           ).pack(side="right")
            tk.Label(corps, text=texte, bg="white", fg="#444", font=("Segoe UI", 10), justify="left",
                     wraplength=1050, anchor="w").pack(fill="x", pady=(6, 4))
            if actions:
                bt = tk.Frame(corps, bg="white")
                bt.pack(anchor="w")
                for libelle, cible in actions:
                    ttk.Button(bt, text=libelle, command=lambda c=cible: self._action_guide(c)).pack(
                        side="left", padx=(0, 6))

        pied = tk.Frame(f)
        pied.pack(fill="x", pady=14)
        ttk.Button(pied, text="✔  Tout est réglé : masquer ce guide", style="Gros.TButton",
                   command=self._masquer_guide).pack(side="left")
        ttk.Label(pied, foreground="#777",
                  text="Besoin d'aide ? contact@audiova.eu").pack(side="left", padx=14)
        self._maj_progres()

    def _maj_progres(self):
        n = sum(v.get() for v in self._v_etapes.values())
        total = len(self._v_etapes)
        self._lbl_progres.config(text=f"{n} étape{'s' if n > 1 else ''} sur {total} faite{'s' if n > 1 else ''}")
        c = self._barre_progres

        def dessiner():
            c.delete("all")
            w = c.winfo_width()
            if w > 1:
                c.create_rectangle(0, 0, w * n / total, 10, fill="#21D4FD", outline="")
        c.after(50, dessiner)

    def _etape_cochee(self, cle, bande):
        faites = [k for k, v in self._v_etapes.items() if v.get()]
        bande.config(bg="#22A06B" if self._v_etapes[cle].get() else "#E0457B")
        for c in (self.cfg, self.app.cfg):            # gardé tout de suite, même sans « Enregistrer »
            c["guide_etapes"] = faites
        sauver_reglages(self.app.cfg)
        self._maj_progres()

    def _action_guide(self, cible):
        if cible == "diagnostic":
            FenetreDiagnostic(self, self.app)
        elif cible.startswith("onglet:"):
            nom = cible.split(":", 1)[1]
            for t in self._nb.tabs():
                if self._nb.tab(t, "text") == nom:
                    self._nb.select(t)
        else:
            try:
                os.startfile(cible)
            except Exception:
                import webbrowser
                webbrowser.open(cible)

    def _masquer_guide(self):
        if not messagebox.askyesno("Mise en route", "Masquer le guide de mise en route ?\n\n"
                                   "Vous pourrez le retrouver dans l'onglet Général.", parent=self):
            return
        for c in (self.cfg, self.app.cfg):
            c["guide_masque"] = True
        sauver_reglages(self.app.cfg)
        self._nb.forget(self._onglet_guide)

    def _revoir_guide(self):
        for c in (self.cfg, self.app.cfg):
            c["guide_masque"] = False
        sauver_reglages(self.app.cfg)
        messagebox.showinfo("Mise en route", "Le guide réapparaîtra à la prochaine ouverture des réglages.",
                            parent=self)

    def _general(self, nb):
        f = self._onglet(nb, "Général")
        if self.cfg.get("guide_masque", False):
            ttk.Button(f, text="🚀  Revoir le guide de mise en route", command=self._revoir_guide).grid(
                row=0, column=0, columnspan=2, sticky="w", pady=(0, 10))
        self._ligne(f, "Code des réglages", "pin", largeur=10)
        self._ligne(f, "Compte à rebours (secondes)", "compte_a_rebours", int)
        self._ligne(f, "Sons (bips et déclencheur)", "sons", bool)
        r = f.grid_size()[1]
        ttk.Label(f, text="Filtre des photos").grid(row=r, column=0, sticky="w", pady=4)
        v = tk.StringVar(value=self.cfg.get("filtre", "aucun"))
        self.vars["filtre"] = (v, str)
        ttk.Combobox(f, textvariable=v, values=FILTRES, state="readonly", width=16).grid(
            row=r, column=1, sticky="w")
        self._ligne(f, "Diaporama des photos quand personne n'utilise le photobooth", "diaporama", bool)
        self._ligne(f, "Diaporama après (secondes d'inactivité)", "diaporama_delai", int)
        v = self._ligne(f, "Dossier de secours (clé USB, 2e disque…)", "dossier_secours", largeur=36)
        ttk.Button(f, text="Parcourir…", command=lambda v=v: self._choisir_dossier(v)).grid(
            row=f.grid_size()[1] - 1, column=2, padx=6)
        self._ligne(f, "Retour à l'accueil après (secondes)", "delai_retour", int)
        self._ligne(f, "Aperçu en miroir (comme un miroir, la photo reste à l'endroit)", "miroir", bool)
        self._ligne(f, "Bloquer la touche Windows, Alt+Tab et Alt+F4 (seulement si un clavier est branché)",
                    "bloquer_clavier", bool)
        self._note(f, "Les invités ne peuvent ni quitter ni ouvrir ces réglages sans le code. "
                      "Le blocage du clavier s'arrête tant que cette fenêtre est ouverte.")
        self._note(f, "Dossier de secours : chaque photo y est copiée en plus, dès qu'elle est prise. "
                      "Sons : remplacez bip.wav et declic.wav du dossier Sons par vos propres sons.")
        self._ligne(f, "Aperçu cadré exactement comme la photo finale", "cadrage_exact", bool)
        self._ligne(f, "Proposer « Refaire » après chaque photo", "proposer_refaire", bool)
        self._ligne(f, "Ouvrir digiCamControl automatiquement s'il est fermé", "lancer_digicam", bool)
        self._ligne(f, "Afficher la fluidité de l'aperçu (images/s, pour les tests)", "afficher_fps", bool)
        self._ligne(f, "Clavier qui s'affiche tout seul quand on touche une case", "clavier_auto", bool)
        self._ligne(f, "Bouton « Noir et blanc / Couleur » sur la photo finale", "proposer_nb", bool)
        self._ligne(f, "Mode Prestation (pas de veille, pas de notifications Windows)", "mode_prestation", bool)
        self._ligne(f, "Bloquer les glissements depuis les bords de l'écran tactile", "bloquer_bords", bool)
        self._ligne(f, "Performances maximales pendant l'utilisation", "hautes_performances", bool)
        self._ligne(f, "Aide au cadrage (« Rapprochez-vous du centre ! »…)", "aide_cadrage", bool)
        self._ligne(f, "Écran « Comment ça marche » sur l'accueil", "comment_ca_marche", bool)
        self._ligne(f, "Télécommande depuis le téléphone (même Wi-Fi que le photobooth)", "telecommande", bool)
        r = f.grid_size()[1]
        tele = getattr(self.app, "telecommande", None)
        if tele:
            url = tele.url()
            ttk.Label(f, text=f"Adresse de la télécommande : {url}   (code = code des réglages)",
                      font=("Segoe UI", 10, "bold")).grid(row=r, column=0, columnspan=2, sticky="w")
            if qrcode is not None:
                q = qrcode.QRCode(box_size=4, border=2)
                q.add_data(url)
                q.make(fit=True)
                self._tk_qr_tele = ImageTk.PhotoImage(q.make_image().convert("RGB"))
                ttk.Label(f, image=self._tk_qr_tele).grid(row=r, column=2, columnspan=2, rowspan=3, sticky="w")
        else:
            ttk.Label(f, text="Télécommande inactive (cochez la case puis Enregistrer).", foreground="#555").grid(
                row=r, column=0, columnspan=2, sticky="w")
        # Canal de test (Audiova) : visible seulement si l'adresse privée est déjà enregistrée.
        # Aucune case ne montre ni ne permet de modifier cette adresse.
        if self.cfg.get("url_mise_a_jour"):
            self._ligne(f, "Recevoir les versions de test (réservé à Audiova France)", "canal_test", bool)
        r = f.grid_size()[1] + 1
        self.lbl_maj = ttk.Label(f, text=f"Version installée : {VERSION}")
        # Accès caché pour Audiova (réinstallation sans sauvegarde) : 7 appuis rapides sur la version
        self._appuis_version = []
        self.lbl_maj.bind("<Button-1>", self._appui_version)
        self.lbl_maj.grid(row=r, column=0, sticky="w", pady=(8, 0))
        ttk.Button(f, text="Rechercher une mise à jour", command=self._mise_a_jour).grid(
            row=r, column=1, sticky="w", pady=(8, 0))
        self._boutons(f, ("Ouvrir le dossier des photos", lambda: os.startfile(PHOTOS_DIR)),
                      ("Ouvrir le dossier du logiciel", lambda: os.startfile(DATA_DIR)))

    def _appui_version(self, _e=None):
        maintenant = time.time()
        self._appuis_version = [t for t in self._appuis_version if maintenant - t < 3] + [maintenant]
        if len(self._appuis_version) < 7:
            return
        self._appuis_version = []
        adresse = simpledialog.askstring("Audiova", "Adresse des versions de test :", parent=self, show="•")
        if adresse and adresse.strip().startswith("http"):
            self._nouvelle_adresse_test = adresse.strip()
            messagebox.showinfo("Audiova", "Canal de test activé. Cliquez sur « Enregistrer ».", parent=self)

    def _mise_a_jour(self):
        try:
            cfg = self._collecter()
        except ValueError as e:
            return messagebox.showerror("Mise à jour", str(e), parent=self)
        self.lbl_maj.config(text="Recherche…")

        def travail():
            try:
                dispo, url = chercher_mise_a_jour(cfg)
                self.app.dans_ui(self._maj_trouvee, dispo, url)
            except Exception as e:
                self.app.dans_ui(lambda: self.lbl_maj.config(
                    text=f"Version {VERSION} · recherche impossible ({str(e)[:50]})"))
        threading.Thread(target=travail, daemon=True).start()

    def _maj_trouvee(self, dispo, url):
        if getattr(self, "_maj_en_cours", False):       # un seul installateur à la fois
            return
        if not url:
            self.lbl_maj.config(text=f"Version {VERSION} : c'est la dernière.")
            return
        if not messagebox.askyesno("Mise à jour", f"La version {dispo} est disponible "
                                   f"(installée : {VERSION}).\n\nL'installer maintenant ? Le "
                                   "Photobooth va se fermer puis se relancer tout seul.", parent=self):
            self.lbl_maj.config(text=f"Version {dispo} disponible.")
            return
        self.lbl_maj.config(text="Téléchargement…")
        self._maj_en_cours = True

        def travail():
            try:
                import tempfile, subprocess
                dest = os.path.join(tempfile.gettempdir(), "Installer Photobooth Audiova.exe")
                req = urllib.request.Request(url, headers={"Cache-Control": "no-cache"})
                with urllib.request.urlopen(req, timeout=120) as r, open(dest, "wb") as f:
                    total = int(r.headers.get("Content-Length") or 0)
                    lu = 0
                    while True:
                        bloc = r.read(1 << 16)
                        if not bloc:
                            break
                        f.write(bloc)
                        lu += len(bloc)
                        if total:
                            p = int(lu * 100 / total)
                            self.app.dans_ui(lambda p=p: self.lbl_maj.config(text=f"Téléchargement {p} %"))
                journal = os.path.join(DATA_DIR, "mise_a_jour.log")       # détail en cas d'échec
                subprocess.Popen([dest, "/SILENT", "/SUPPRESSMSGBOXES", "/NORESTART", f"/LOG={journal}"])
                self.app.dans_ui(self.app.quitter)
            except Exception as e:
                log.exception("Mise à jour")
                self.app.dans_ui(lambda: self.lbl_maj.config(text="Échec : " + str(e)[:70]))
        threading.Thread(target=travail, daemon=True).start()

    def _choisir_dossier(self, v):
        d = filedialog.askdirectory(parent=self, title="Dossier de secours")
        if d:
            v.set(os.path.normpath(d))

    def _appareil(self, nb):
        f = self._onglet(nb, "Appareil photo")
        v = tk.StringVar(value=self.cfg["camera"])
        self.vars["camera"] = (v, str)
        ttk.Radiobutton(f, text="Reflex Canon en direct (le plus fluide, sans carré vert)"
                        + ("" if edsdk_disponible() else " : kit Canon introuvable"), value="canon",
                        variable=v).grid(row=0, column=0, columnspan=2, sticky="w", pady=4)
        ttk.Radiobutton(f, text="Reflex Canon (via digiCamControl)", value="digicam",
                        variable=v).grid(row=1, column=0, columnspan=2, sticky="w", pady=4)
        ttk.Radiobutton(f, text="Webcam", value="webcam", variable=v).grid(
            row=2, column=0, columnspan=2, sticky="w", pady=4)
        self._ligne(f, "Adresse de digiCamControl", "digicam_url", largeur=30)
        self._ligne(f, "Numéro de la webcam (0 = la première)", "webcam_index", int)
        self.lbl_cam = ttk.Label(f, text=self._etat_camera())
        self.lbl_cam.grid(row=f.grid_size()[1], column=0, columnspan=3, sticky="w", pady=8)
        self._boutons(f, ("Appliquer et reconnecter", self._reconnecter))
        self._note(f, "Canon 4000D : lancez digiCamControl avant le Photobooth, réglez l'appareil "
                      "en JPEG (pas RAW), et dans digiCamControl activez Settings > Webserver.")

    def _etat_camera(self):
        if self.app.camera is not None:
            return "État : appareil connecté"
        return "État : " + (self.app.erreur_camera or "non connecté")

    def _reconnecter(self):
        try:
            cfg = self._collecter()
        except ValueError as e:
            return messagebox.showerror("Réglages", str(e), parent=self)
        for k in ("camera", "digicam_url", "webcam_index"):
            self.app.cfg[k] = cfg[k]
            self.cfg[k] = cfg[k]
        sauver_reglages(self.app.cfg)
        self.lbl_cam.config(text="État : connexion en cours…")
        self.app.reconnecter_camera(lambda err: self.lbl_cam.config(text=self._etat_camera())
                                    if self.winfo_exists() else None)

    def _apparence(self, nb):
        f = self._onglet(nb, "Apparence")
        self._ligne(f, "Petit nom en haut (si pas de logo, facultatif)", "marque")
        self._ligne(f, "Grand texte de l'accueil", "titre_accueil")
        self._ligne(f, "Sous-titre (facultatif)", "texte_accueil")
        self._ligne(f, "Bas de l'écran d'accueil", "pied_accueil")
        r = f.grid_size()[1]
        ttk.Label(f, text="Mode d'affichage").grid(row=r, column=0, sticky="w", pady=4)
        v_mode = tk.StringVar(value=self.cfg.get("mode", "sombre"))
        self.vars["mode"] = (v_mode, str)
        cadre_mode = ttk.Frame(f)
        cadre_mode.grid(row=r, column=1, columnspan=3, sticky="w")
        ttk.Radiobutton(cadre_mode, text="Automatique (selon le soleil)", value="auto",
                        variable=v_mode, command=self._maj_soleil).pack(side="left")
        ttk.Radiobutton(cadre_mode, text="Sombre (soirées)", value="sombre", variable=v_mode,
                        command=self._maj_soleil).pack(side="left", padx=14)
        ttk.Radiobutton(cadre_mode, text="Clair (jour)", value="clair", variable=v_mode,
                        command=self._maj_soleil).pack(side="left")
        self._ligne(f, "Lieu de la prestation (mode automatique)", "lieu", largeur=20)
        r = f.grid_size()[1] - 1
        ttk.Button(f, text="Trouver ma position (internet)", command=self._position).grid(row=r, column=2,
                                                                                       columnspan=2, padx=6)
        self._ligne(f, "Latitude", "latitude", largeur=10)
        self._ligne(f, "Longitude", "longitude", largeur=10)
        r = f.grid_size()[1]
        self.lbl_soleil = ttk.Label(f, foreground="#555")
        self.lbl_soleil.grid(row=r, column=0, columnspan=4, sticky="w", pady=(0, 8))
        self.after(200, self._maj_soleil)
        self.apercus_couleur = {}
        for cle, nom in (("couleur_fond", "Couleur de fond (mode sombre)"),
                         ("couleur_fond_clair", "Couleur de fond (mode clair)"), ("couleur_1", "Couleur 1 (violet)"),
                         ("couleur_2", "Couleur 2 (magenta)"), ("couleur_3", "Couleur 3 (cyan)")):
            v = self._ligne(f, nom, cle, largeur=10)
            r = f.grid_size()[1] - 1
            pastille = tk.Label(f, width=4, bg=v.get())
            pastille.grid(row=r, column=2, padx=6)
            ttk.Button(f, text="Choisir…", command=lambda v=v, p=pastille: self._choisir_couleur(v, p)).grid(
                row=r, column=3)
        self._boutons(f, ("Remettre les couleurs Audiova", self._couleurs_audiova))
        self._note(f, "Logo : déposez votre logo en PNG transparent, nommé logo.png, dans le dossier "
                      "du logiciel : il s'affiche en petit en haut de l'accueil. "
                      "Les couleurs s'appliquent dès l'enregistrement.")

    def _maj_soleil(self):
        try:
            cfg = dict(self.cfg)
            for k in ("mode", "latitude", "longitude"):
                cfg[k] = self.vars[k][0].get()
            lat = float(str(cfg["latitude"]).replace(",", "."))
            lon = float(str(cfg["longitude"]).replace(",", "."))
            lever, coucher = lever_coucher(datetime.now().astimezone().date(), lat, lon)
            actuel = mode_effectif(cfg)
            if lever:
                texte = (f"Aujourd'hui : lever du soleil {lever:%H:%M}, coucher {coucher:%H:%M}. "
                         f"En ce moment : mode {actuel}.")
            else:
                texte = f"En ce moment : mode {actuel}."
            if cfg["mode"] != "auto":
                texte += " (mode forcé)"
            self.lbl_soleil.config(text=texte)
        except Exception:
            self.lbl_soleil.config(text="Latitude ou longitude incorrecte (ex. 46.95 et 4.30 pour Autun).")

    def _position(self):
        def travail():
            try:
                with urllib.request.urlopen("http://ip-api.com/json/?fields=status,city,lat,lon", timeout=8) as r:
                    d = json.loads(r.read().decode("utf-8"))
                if d.get("status") != "success":
                    raise RuntimeError("position introuvable")
                def maj():
                    self.vars["lieu"][0].set(d.get("city", ""))
                    self.vars["latitude"][0].set(f"{d['lat']:.2f}")
                    self.vars["longitude"][0].set(f"{d['lon']:.2f}")
                    self._maj_soleil()
                self.app.dans_ui(maj)
            except Exception as e:
                self.app.dans_ui(lambda: self.lbl_soleil.config(
                    text=f"Position introuvable ({e}). Tapez la latitude et la longitude à la main."))
        threading.Thread(target=travail, daemon=True).start()

    def _choisir_couleur(self, v, pastille):
        from tkinter import colorchooser
        _, hexa = colorchooser.askcolor(color=v.get(), parent=self)
        if hexa:
            v.set(hexa)
            pastille.config(bg=hexa)

    def _couleurs_audiova(self):
        for cle in ("couleur_fond", "couleur_fond_clair", "couleur_1", "couleur_2", "couleur_3"):
            self.vars[cle][0].set(DEFAUT[cle])

    def _animation(self, nb):
        f = self._onglet(nb, "Animation")
        ttk.Label(f, text="Animation de l'écran d'accueil", font=("Segoe UI", 13, "bold")).grid(
            row=0, column=0, columnspan=3, sticky="w", pady=(0, 4))
        ttk.Label(f, foreground="#555", text="Touchez une image pour la choisir. Les couleurs suivent celles "
                                             "de l'onglet Apparence.").grid(row=1, column=0, columnspan=3,
                                                                           sticky="w", pady=(0, 10))
        styles = (("bulles", "Bulles de lumière", "Douces bulles floues qui montent lentement"),
                  ("etoiles", "Étoiles scintillantes", "Un ciel d'étoiles qui s'allument une à une"),
                  ("guirlande", "Guirlande guinguette", "Ampoules chaudes qui s'allument doucement"),
                  ("paillettes", "Paillettes dorées", "Petits éclats dorés qui scintillent"),
                  ("aucune", "Fond lumineux fixe", "Aucun mouvement, le plus léger pour le PC"))
        actuel = self.cfg.get("animation_accueil", "bulles")
        self._v_animation = tk.StringVar(value=actuel if actuel in dict((s[0], 1) for s in styles) else "bulles")
        clair = mode_effectif(self.cfg) == "clair"
        self._tk_apercus_anim = []
        self._cartes_anim = {}
        for i, (cle, nom, desc) in enumerate(styles):
            carte = tk.Frame(f, bd=0, highlightthickness=4, cursor="hand2")
            carte.grid(row=2 + (i // 3) * 3, column=i % 3, padx=8, pady=8, sticky="n")
            tkimg = ImageTk.PhotoImage(apercu_animation(cle, 320, 180, clair))
            self._tk_apercus_anim.append(tkimg)
            image = tk.Label(carte, image=tkimg, bd=0)
            image.pack()
            ttk.Radiobutton(carte, text=nom, value=cle, variable=self._v_animation,
                            command=self._maj_cartes_anim).pack(anchor="w", pady=(6, 0))
            ttk.Label(carte, text=desc, foreground="#555", wraplength=300).pack(anchor="w")
            for w in (carte, image):
                w.bind("<Button-1>", lambda e, c=cle: (self._v_animation.set(c), self._maj_cartes_anim()))
            self._cartes_anim[cle] = carte
        self._maj_cartes_anim()
        r = f.grid_size()[1]
        ttk.Label(f, text="Quantité d'éléments animés").grid(row=r, column=0, sticky="w", pady=(16, 4))
        self._v_densite = tk.StringVar(value=str(float(self.cfg.get("densite_anim", 1.0) or 1.0)))
        cadre = ttk.Frame(f)
        cadre.grid(row=r, column=1, columnspan=2, sticky="w", pady=(16, 4))
        for texte, val in (("Peu", "0.6"), ("Normale", "1.0"), ("Beaucoup", "1.6")):
            ttk.Radiobutton(cadre, text=texte, value=val, variable=self._v_densite).pack(side="left", padx=(0, 14))
        self._ligne(f, "Animations sur l'écran de la photo (confettis)", "animations", bool)

    def _maj_cartes_anim(self):
        for cle, carte in self._cartes_anim.items():
            carte.config(highlightbackground="#FF3D9A" if cle == self._v_animation.get() else "#D8D8E0")

    def _evenement(self, nb):
        f = self._onglet(nb, "Événement")
        self._ligne(f, "Nom de l'événement", "evenement")
        self._ligne(f, "Nombre d'impressions prévu (0 = illimité)", "limite_impressions", int)
        r = f.grid_size()[1]
        self.lbl_compteur = ttk.Label(f, font=("Segoe UI", 12, "bold"))
        self.lbl_compteur.grid(row=r, column=0, columnspan=3, sticky="w", pady=(14, 4))
        self._maj_compteur()
        r = f.grid_size()[1]
        self.lbl_stats = ttk.Label(f, justify="left")
        self.lbl_stats.grid(row=r, column=0, columnspan=3, sticky="w", pady=(2, 4))
        self._maj_compteur()
        self._boutons(f, ("Nouvel événement : remettre les compteurs à zéro", self._raz_compteur))
        self._note(f, "Chaque tirage est compté, copies comprises. Quand le nombre prévu est atteint, "
                      "le bouton Imprimer disparaît ; le QR code et l'e-mail restent disponibles. "
                      "Les photos sont rangées dans un dossier au nom de l'événement.")
        r = f.grid_size()[1]
        ttk.Separator(f).grid(row=r, column=0, columnspan=4, sticky="ew", pady=10)
        ttk.Label(f, text="Galerie en ligne pour le client", font=("Segoe UI", 11, "bold")).grid(
            row=r + 1, column=0, columnspan=3, sticky="w")
        self.lbl_galerie = ttk.Label(f, text="", foreground="#555")
        self.lbl_galerie.grid(row=r + 2, column=0, columnspan=3, sticky="w", pady=4)
        self._boutons(f, ("Mettre toutes les photos en ligne", self._galerie),
                      ("Copier le lien", self._copier_lien))
        self._note(f, "Envoie toutes les photos de l'événement sur votre hébergement (réglages FTP de "
                      "l'onglet QR code) avec une jolie page web à vos couleurs. Vous transmettez le lien "
                      "au client. Relancez-le à tout moment : seules les nouvelles photos sont envoyées.")
        self._lien_galerie = ""

    def _maj_compteur(self):
        fait = int(self.cfg.get("impressions_faites") or 0)
        limite = int(self.cfg.get("limite_impressions") or 0)
        self.lbl_compteur.config(text=f"Impressions faites pour cet événement : {fait}"
                                 + (f" sur {limite}" if limite > 0 else " (sans limite)"))
        if hasattr(self, "lbl_stats"):
            st = self.cfg.get("stats", {})
            self.lbl_stats.config(text=(
                f"Séances : {st.get('seances', 0)}    Photos prises : {st.get('photos', 0)}    "
                f"Tirages : {st.get('impressions', 0)}    QR codes : {st.get('qr', 0)}    "
                f"E-mails : {st.get('emails', 0)}"))

    def _galerie(self):
        try:
            cfg = self._collecter()
        except ValueError as e:
            return messagebox.showerror("Galerie", str(e), parent=self)
        if not cfg["ftp_hote"]:
            return messagebox.showerror("Galerie", "Renseignez d'abord le FTP dans l'onglet QR code.",
                                        parent=self)
        self.lbl_galerie.config(text="Connexion…")

        def avance(i, n):
            self.app.dans_ui(lambda: self.lbl_galerie.config(text=f"Envoi : {i} / {n} photos")
                             if self.winfo_exists() else None)

        def travail():
            try:
                url, dossier = publier_galerie(cfg, avance)
                self.app.dans_ui(self._galerie_ok, url, dossier)
            except Exception as e:
                log.exception("Galerie")
                self.app.dans_ui(lambda: self.lbl_galerie.config(text="Échec : " + str(e)[:90])
                                 if self.winfo_exists() else None)
        threading.Thread(target=travail, daemon=True).start()

    def _galerie_ok(self, url, dossier):
        self.cfg["galerie_dossier"] = dossier
        self.app.cfg["galerie_dossier"] = dossier
        sauver_reglages(self.app.cfg)
        self._lien_galerie = url
        if self.winfo_exists():
            self.lbl_galerie.config(text="En ligne : " + url)
            self._copier_lien()

    def _copier_lien(self):
        if self._lien_galerie:
            self.clipboard_clear()
            self.clipboard_append(self._lien_galerie)
            messagebox.showinfo("Galerie", "Lien copié :\n" + self._lien_galerie, parent=self)

    def _raz_compteur(self):
        if messagebox.askyesno("Nouvel événement", "Remettre à zéro le compteur d'impressions, "
                               "les statistiques et le lien de galerie ?", parent=self):
            for c in (self.cfg, self.app.cfg):
                c["impressions_faites"] = 0
                c["stats"] = dict(DEFAUT["stats"])
                c["galerie_dossier"] = ""
            sauver_reglages(self.app.cfg)
            self._lien_galerie = ""
            self.lbl_galerie.config(text="")
            self._maj_compteur()

    AUCUN_PHOTO = "(Aucun fond : photo pleine page)"
    AUCUN_BANDE = "(Aucun fond bandelette)"

    def _fonds(self, nb):
        f = self._onglet(nb, "Fonds")
        # état actuel, déduit des réglages (compatible avec la télécommande)
        actuel = self.cfg.get("fond", "")
        if actuel and est_bandelette(self._taille_fond(os.path.join(FONDS_DIR, actuel))):
            photo, bande, mode = self.cfg.get("fond_photo", ""), actuel, "bande"
        else:
            photo, bande = actuel, self.cfg.get("fond_bande", "")
            mode = "choix" if (self.cfg.get("choix_format", True) and photo and bande) else "photo"
        self.fond_choisi = actuel
        self._v_fond_photo = tk.StringVar(value=photo or self.AUCUN_PHOTO)
        self._v_fond_bande = tk.StringVar(value=bande or self.AUCUN_BANDE)
        self._v_mode_format = tk.StringVar(value=mode)

        gauche = ttk.Frame(f)
        gauche.pack(side="left", fill="y")
        titre = ("Segoe UI", 10, "bold")
        self.lbl_etat_fond = {}
        for cle, texte, var, aucun in (("photo", "① Fond des photos 10x15", self._v_fond_photo, self.AUCUN_PHOTO),
                                       ("bande", "② Fond des bandelettes 5x15", self._v_fond_bande, self.AUCUN_BANDE)):
            bloc = ttk.LabelFrame(gauche, text=texte, padding=6)
            bloc.pack(fill="x", pady=(0, 8))
            cb = ttk.Combobox(bloc, textvariable=var, state="readonly", width=34)
            cb.pack(fill="x")
            cb.bind("<<ComboboxSelected>>", lambda e, v=var: self._montrer_fond(v.get()))
            setattr(self, "cb_" + cle, cb)
            boutons = ttk.Frame(bloc)
            boutons.pack(fill="x", pady=(4, 0))
            ttk.Button(boutons, text="Importer mon fond…",
                       command=lambda c=cle: self._ajouter_fond(c)).pack(side="left", expand=True, fill="x")
            ttk.Button(boutons, text="✎ Placer les photos",
                       command=lambda v=var, a=aucun: self._placer(None if v.get() == a else v.get())
                       ).pack(side="left", expand=True, fill="x", padx=(4, 0))
            self.lbl_etat_fond[cle] = ttk.Label(bloc, foreground="#C0392B", wraplength=260, justify="left")
            self.lbl_etat_fond[cle].pack(anchor="w")
        ttk.Label(gauche, text="③ Ce que les invités impriment", font=titre).pack(anchor="w")
        for val, txt in (("photo", "Photo 10x15 seulement"),
                         ("bande", "Bandelettes seulement"),
                         ("choix", "L'invité choisit au début de la séance")):
            ttk.Radiobutton(gauche, text=txt, value=val, variable=self._v_mode_format).pack(anchor="w")
        self.lbl_alerte_format = ttk.Label(gauche, foreground="#C0392B", wraplength=260, justify="left")
        self.lbl_alerte_format.pack(anchor="w")
        for v in (self._v_fond_photo, self._v_fond_bande, self._v_mode_format):
            v.trace_add("write", lambda *a: self._verifier_format())
        ttk.Separator(gauche).pack(fill="x", pady=10)
        ttk.Label(gauche, text="Tous mes fonds", font=titre).pack(anchor="w")
        ttk.Label(gauche, foreground="#555", wraplength=260, justify="left",
                  text="Pour voir ou supprimer un fond.").pack(anchor="w")
        self.liste = tk.Listbox(gauche, width=34, height=6, exportselection=False)
        self.liste.pack(fill="y", expand=True, pady=(4, 0))
        self.liste.bind("<<ListboxSelect>>", self._fond_selectionne)
        self.liste.bind("<Double-Button-1>", lambda e: self._placer())
        self.btn_placer = ttk.Button(gauche, text="✎  Placer les photos sur ce fond", command=self._placer)
        self.btn_placer.pack(fill="x", pady=(8, 2))
        ttk.Button(gauche, text="Supprimer ce fond", command=self._supprimer_fond).pack(fill="x", pady=2)
        ttk.Button(gauche, text="Ouvrir le dossier Fonds",
                   command=lambda: os.startfile(FONDS_DIR)).pack(fill="x", pady=2)

        droite = ttk.Frame(f, padding=(16, 0))
        droite.pack(side="left", fill="both", expand=True)
        self.lbl_apercu = ttk.Label(droite)
        self.lbl_apercu.pack()
        self.lbl_fond_info = ttk.Label(droite, wraplength=440, justify="left")
        self.lbl_fond_info.pack(pady=8)
        ttk.Label(droite, wraplength=440, justify="left", foreground="#555", text=(
            "Fonds en 10x15 à 300 dpi : 1800 x 1200 px (paysage) ou 1200 x 1800 px (portrait), "
            "ou bandelette 5x15 : 600 x 1800 px. "
            "En PNG avec des zones transparentes, le fond passe par-dessus les photos. "
            "Avec « Placer les photos… », vous positionnez et redimensionnez chaque photo "
            "comme vous voulez, et vous choisissez si le fond passe devant ou derrière.")).pack()
        self._remplir_liste()

    @staticmethod
    def _taille_fond(chemin):
        try:
            with Image.open(chemin) as im:
                return im.size
        except Exception:
            return (1, 1)

    def _fichiers_fonds(self):
        return sorted(n for n in os.listdir(FONDS_DIR)
                      if n.lower().endswith((".png", ".jpg", ".jpeg", ".webp")))

    def _remplir_liste(self):
        self.liste.delete(0, "end")
        self.liste.insert("end", "(Aucun fond : photo pleine page)")
        fichiers = self._fichiers_fonds()
        for n in fichiers:
            self.liste.insert("end", n)
        bandes = [n for n in fichiers if est_bandelette(self._taille_fond(os.path.join(FONDS_DIR, n)))]
        photos = [n for n in fichiers if n not in bandes]
        self.cb_photo.config(values=[self.AUCUN_PHOTO] + photos)
        self.cb_bande.config(values=[self.AUCUN_BANDE] + bandes)
        if self._v_fond_photo.get() not in photos:
            self._v_fond_photo.set(self.AUCUN_PHOTO)
        if self._v_fond_bande.get() not in bandes:
            self._v_fond_bande.set(self.AUCUN_BANDE)
        i = fichiers.index(self.fond_choisi) + 1 if self.fond_choisi in fichiers else 0
        if i == 0:
            self.fond_choisi = ""
        self.liste.selection_set(i)
        self.liste.see(i)
        self._fond_selectionne()
        self._verifier_format()

    def _fond_selectionne(self, _e=None):
        sel = self.liste.curselection()
        i = sel[0] if sel else 0
        self.fond_choisi = "" if i == 0 else self.liste.get(i)
        try:
            g = Gabarit(os.path.join(FONDS_DIR, self.fond_choisi) if self.fond_choisi else None)
            img = g.apercu_exemple()
            img.thumbnail((440, 440))
            self._tk_apercu = ImageTk.PhotoImage(img)
            self.lbl_apercu.config(image=self._tk_apercu)
            sens = "paysage" if g.taille[0] > g.taille[1] else "portrait"
            place = "par-dessus" if g.devant else "derrière"
            self.lbl_fond_info.config(text=f"Ce fond : {g.nb_photos} photo(s), format {sens}, "
                                           f"fond {place} les photos.")
            self.btn_placer.config(state="normal" if self.fond_choisi else "disabled")
        except Exception as e:
            self.lbl_fond_info.config(text="Ce fichier ne peut pas être lu : " + str(e))

    def _verifier_format(self):
        for cle, var, aucun in (("photo", self._v_fond_photo, self.AUCUN_PHOTO),
                                ("bande", self._v_fond_bande, self.AUCUN_BANDE)):
            nom, txt = var.get(), ""
            if nom != aucun:
                chemin = os.path.join(FONDS_DIR, nom)
                try:
                    a_zones = os.path.isfile(Gabarit.chemin_disposition(chemin)) or Gabarit(chemin).a_transparence
                except Exception:
                    a_zones = True
                if not a_zones:
                    txt = "⚠ Photos pas encore placées sur ce fond : touchez « ✎ Placer les photos »."
            self.lbl_etat_fond[cle].config(text=txt)
        mode = self._v_mode_format.get()
        photo = self._v_fond_photo.get() != self.AUCUN_PHOTO
        bande = self._v_fond_bande.get() != self.AUCUN_BANDE
        txt = ""
        if mode == "bande" and not bande:
            txt = "⚠ Choisissez un fond en ②, sinon ce sera la photo 10x15."
        elif mode == "choix" and not (photo and bande):
            txt = "⚠ Pour laisser le choix, il faut un fond en ① ET en ②."
        self.lbl_alerte_format.config(text=txt)

    def _montrer_fond(self, nom):
        """Affiche dans « Mes fonds » le fond choisi dans une des deux listes."""
        fichiers = list(self.liste.get(1, "end"))
        i = fichiers.index(nom) + 1 if nom in fichiers else 0
        self.liste.selection_clear(0, "end")
        self.liste.selection_set(i)
        self.liste.see(i)
        self._fond_selectionne()

    def _placer(self, nom=None):
        nom = nom or self.fond_choisi
        if not nom:
            return messagebox.showinfo("Fonds", "Choisissez d'abord un fond dans la liste.", parent=self)
        self._montrer_fond(nom)

        def apres():
            self._fond_selectionne()
            self._verifier_format()
        EditeurDisposition(self, os.path.join(FONDS_DIR, nom), apres)

    def _ajouter_fond(self, cible=None):
        chemins = filedialog.askopenfilenames(parent=self, title="Choisir mon fond",
                                              filetypes=[("Images", "*.png *.jpg *.jpeg *.webp")])
        for c in chemins:
            shutil.copy2(c, os.path.join(FONDS_DIR, os.path.basename(c)))
        if not chemins:
            return
        nom = os.path.basename(chemins[-1])
        bande = est_bandelette(self._taille_fond(os.path.join(FONDS_DIR, nom)))
        if cible and (cible == "bande") != bande:
            messagebox.showinfo("Fonds", f"« {nom} » est au format "
                                f"{'bandelette 5x15' if bande else '10x15'} : il a été mis dans la case "
                                f"{'②' if bande else '①'}.", parent=self)
        (self._v_fond_bande if bande else self._v_fond_photo).set(nom)
        self.fond_choisi = nom
        self._remplir_liste()
        if len(chemins) == 1:                 # un seul fond importé : on passe directement au placement
            self.after(300, lambda: self._placer(nom))

    def _supprimer_fond(self):
        if not self.fond_choisi:
            return
        if messagebox.askyesno("Fonds", f"Supprimer « {self.fond_choisi} » ?", parent=self):
            chemin = os.path.join(FONDS_DIR, self.fond_choisi)
            os.remove(chemin)
            if os.path.isfile(Gabarit.chemin_disposition(chemin)):
                os.remove(Gabarit.chemin_disposition(chemin))
            self.fond_choisi = ""
            self._remplir_liste()

    def _impression(self, nb):
        f = self._onglet(nb, "Impression")
        self._ligne(f, "Proposer l'impression", "impression_active", bool)
        ttk.Label(f, text="Imprimante").grid(row=1, column=0, sticky="w", pady=4)
        v = tk.StringVar(value=self.cfg["imprimante"])
        self.vars["imprimante"] = (v, str)
        imprimantes = liste_imprimantes()
        ttk.Combobox(f, textvariable=v, values=imprimantes, width=42).grid(row=1, column=1, sticky="w")
        self._ligne(f, "Nombre d'impressions maximum par photo", "copies_max", int)
        self._ligne(f, "Durée d'impression d'une photo (secondes, pour la barre d'attente)", "duree_impression", int)
        self._ligne(f, "Bandelettes : format de coupe (laisser vide, automatique)", "forme_bandelette",
                    largeur=30)
        r = f.grid_size()[1]
        ttk.Label(f, text="Bandelettes : imprimante dédiée (facultatif)").grid(row=r, column=0, sticky="w", pady=4)
        v = tk.StringVar(value=self.cfg.get("imprimante_bande", ""))
        self.vars["imprimante_bande"] = (v, str)
        ttk.Combobox(f, textvariable=v, values=[""] + liste_imprimantes(), width=42).grid(row=r, column=1, sticky="w")
        self._note(f, "Bandelettes 5x15 : rien à régler. Même papier 10x15 et même ruban : le logiciel imprime "
                      "2 bandelettes sur la feuille et demande lui-même à l'imprimante de la couper au milieu. "
                      "Laissez la case ci-dessus vide. Seulement si une feuille de bandelettes sort sans être "
                      "coupée : tapez le nom du format bandelette tel qu'il apparaît dans les préférences de "
                      "l'imprimante (DNP : quelque chose comme « 2x6 x2 »).")
        self._note(f, "À 1, la photo s'imprime directement. Au-dessus, l'invité choisit le nombre de "
                      "tirages, jusqu'à ce maximum. Dès que l'impression est lancée, le bouton Imprimer "
                      "disparaît : impossible de réimprimer la même photo.")
        self._boutons(f, ("Imprimer une page test 10x15", self._test_impression),
                      ("Imprimer une page test bandelettes (avec coupe)", self._test_bandelettes),
                      ("Voir les formats de l'imprimante", self._voir_formats))
        self._note(f, "DNP DS-RX1HS : dans Panneau de configuration > Imprimantes > DNP > "
                      "Préférences d'impression, choisissez le papier (PC)4x6 / 10x15 et "
                      "réglez-le par défaut. Laissez le champ vide pour l'imprimante par défaut."
                   + ("" if HAS_WIN32 else "\n\nAttention : le module pywin32 n'est pas installé, "
                                           "l'impression est impossible."))

    def _test_impression(self):
        try:
            cfg = self._collecter()
            g = Gabarit(os.path.join(FONDS_DIR, cfg["fond"]) if cfg["fond"] else None)
            imprimer_photo(g.apercu_exemple(), cfg["imprimante"], 1)
            messagebox.showinfo("Impression", "Page test envoyée.", parent=self)
        except Exception as e:
            messagebox.showerror("Impression", str(e), parent=self)

    def _test_bandelettes(self):
        """Feuille de 2 bandelettes avec la coupe au milieu, pour vérifier le format de coupe."""
        try:
            cfg = self._collecter()
            nom = cfg["imprimante"] or win32print.GetDefaultPrinter()
            chemin = os.path.join(FONDS_DIR, cfg.get("fond_bande", "")) if cfg.get("fond_bande") else ""
            if not (chemin and os.path.isfile(chemin)):
                chemin = os.path.join(FONDS_DIR, "Exemple - bandelette 3 photos.png")
            g = Gabarit(chemin if os.path.isfile(chemin) else None)
            bande = g.apercu_exemple() if est_bandelette(g.taille) else \
                ImageOps.fit(g.apercu_exemple(), FORMAT_BANDE, Image.LANCZOS)
            if cfg.get("imprimante_bande", "").strip():
                imprimer_photo(feuille_bandelettes(bande), cfg["imprimante_bande"].strip(), 1)
                return messagebox.showinfo("Bandelettes", f"Page test envoyée sur « {cfg['imprimante_bande']} ».",
                                           parent=self)
            forme = forme_bandelette(nom, cfg.get("forme_bandelette", "").strip())
            imprimer_photo(feuille_bandelettes(bande), cfg["imprimante"], 1, forme)
            if forme:
                messagebox.showinfo("Bandelettes", f"Page test envoyée avec le format de coupe « {forme} ».\n\n"
                                    "La feuille doit sortir coupée en 2 bandelettes. Si elle sort entière, "
                                    "cliquez sur « Voir les formats de l'imprimante » et envoyez-nous la liste.",
                                    parent=self)
            else:
                messagebox.showwarning("Bandelettes", "Page test envoyée, mais aucun format de coupe pour "
                                       "bandelettes n'a été trouvé dans cette imprimante : la feuille risque de "
                                       "sortir sans coupe.\n\nCliquez sur « Voir les formats de l'imprimante » "
                                       "pour choisir le bon.", parent=self)
        except Exception as e:
            messagebox.showerror("Bandelettes", str(e), parent=self)

    def _voir_formats(self):
        """Liste les formats papier du pilote : un clic remplit la case du format de coupe."""
        try:
            cfg = self._collecter()
            nom = cfg["imprimante"] or win32print.GetDefaultPrinter()
            h = win32print.OpenPrinter(nom)
            try:
                noms = [x["Name"] for x in win32print.EnumForms(h)]
            finally:
                win32print.ClosePrinter(h)
        except Exception as e:
            return messagebox.showerror("Formats", str(e), parent=self)
        fen = tk.Toplevel(self)
        fen.title(f"Formats de « {nom} »")
        fen.attributes("-topmost", True)
        fen.transient(self)
        fen.geometry("520x560")
        ttk.Label(fen, text="Touchez le format bandelette (souvent avec « 2x6 »), puis « Utiliser ce format ».",
                  wraplength=480, padding=10).pack(anchor="w")
        auto = forme_bandelette(nom, "")
        liste = tk.Listbox(fen, font=("Segoe UI", 12), exportselection=False)
        liste.pack(fill="both", expand=True, padx=10)
        for n in noms:
            liste.insert("end", n + ("   ← choisi automatiquement" if n == auto else ""))

        def utiliser():
            sel = liste.curselection()
            if sel:
                self.vars["forme_bandelette"][0].set(noms[sel[0]])
                fermer()

        def fermer():
            fen.grab_release()
            fen.destroy()
            self.grab_set()
        ttk.Button(fen, text="Utiliser ce format", command=utiliser).pack(pady=10)
        fen.protocol("WM_DELETE_WINDOW", fermer)
        fen.grab_set()

    def _qr(self, nb):
        f = self._onglet(nb, "QR code")
        self._ligne(f, "Proposer le QR code", "qr_actif", bool)
        v = tk.StringVar(value=self.cfg["qr_mode"])
        self.vars["qr_mode"] = (v, str)
        r = f.grid_size()[1]
        ttk.Radiobutton(f, text="Wi-Fi local, sans internet (les invités se connectent au Wi-Fi du photobooth)",
                        value="local", variable=v).grid(row=r, column=0, columnspan=3, sticky="w", pady=2)
        ttk.Radiobutton(f, text="Internet : envoi sur votre hébergement web (FTP)",
                        value="ftp", variable=v).grid(row=r + 1, column=0, columnspan=3, sticky="w", pady=2)
        self._ligne(f, "Texte au-dessus du QR code", "qr_texte")
        self._ligne(f, "Port (mode local)", "port_local", int)
        self._ligne(f, "Serveur FTP", "ftp_hote")
        self._ligne(f, "Utilisateur FTP", "ftp_utilisateur")
        self._ligne(f, "Mot de passe FTP", "ftp_mot_de_passe", secret=True)
        self._ligne(f, "Dossier FTP", "ftp_dossier")
        self._ligne(f, "Adresse web de ce dossier", "url_publique")
        self._boutons(f, ("Tester l'envoi FTP", self._test_ftp))

    def _test_ftp(self):
        try:
            cfg = self._collecter()
            chemin = os.path.join(DATA_DIR, "test_ftp.jpg")
            Gabarit().apercu_exemple().save(chemin, quality=80)
            url = envoyer_ftp(cfg, chemin)
            os.remove(chemin)
            messagebox.showinfo("FTP", "Envoi réussi. Vérifiez cette adresse :\n" + url, parent=self)
        except Exception as e:
            messagebox.showerror("FTP", str(e), parent=self)

    def _email(self, nb):
        f = self._onglet(nb, "E-mail")
        self._ligne(f, "Proposer l'envoi par e-mail", "email_actif", bool)
        self._ligne(f, "Serveur SMTP", "smtp_hote")
        self._ligne(f, "Port (587 ou 465)", "smtp_port", int)
        self._ligne(f, "Identifiant", "smtp_utilisateur")
        self._ligne(f, "Mot de passe (d'application)", "smtp_mot_de_passe", secret=True)
        self._ligne(f, "Adresse d'expédition (facultatif)", "email_expediteur")
        self._ligne(f, "Objet", "email_sujet")
        self._ligne(f, "Lien « Laissez-nous un avis Google » (e-mail et galerie)", "lien_avis", largeur=44)
        r = f.grid_size()[1]
        ttk.Label(f, text="Message").grid(row=r, column=0, sticky="nw", pady=4)
        self.txt_message = tk.Text(f, width=50, height=5, wrap="word")
        self.txt_message.insert("1.0", self.cfg["email_message"])
        self.txt_message.grid(row=r, column=1, sticky="w", pady=4)
        n = self.app.emails.en_attente()
        self._note(f, f"E-mails en attente d'envoi : {n}. Sans internet, ils partent "
                      "automatiquement dès que la connexion revient.")
        self._boutons(f, ("Envoyer un e-mail test", self._test_email),
                      ("Renvoyer les e-mails en attente", self.app.emails.relancer))

    def _test_email(self):
        dest = simpledialog.askstring("E-mail test", "Envoyer un test à quelle adresse ?", parent=self)
        if not dest:
            return
        try:
            cfg = self._collecter()
            chemin = os.path.join(DATA_DIR, "test_email.jpg")
            Gabarit().apercu_exemple().save(chemin, quality=80)
            envoyer_email(cfg, dest, chemin)
            os.remove(chemin)
            messagebox.showinfo("E-mail", "E-mail test envoyé.", parent=self)
        except Exception as e:
            messagebox.showerror("E-mail", str(e), parent=self)

    # -- fermeture
    def enregistrer(self):
        try:
            cfg = self._collecter()
        except ValueError as e:
            return messagebox.showerror("Réglages", str(e), parent=self)
        self.grab_release()
        self.destroy()
        self.app.reglages_fermes(cfg)

    def annuler(self):
        self.grab_release()
        self.destroy()
        self.app.reglages_fermes(None)

    def _quitter(self):
        if messagebox.askyesno("Quitter", "Fermer le Photobooth ?", parent=self):
            self.app.quitter()


# --------------------------------------------------------------------------
if __name__ == "__main__":
    if os.name == "nt":
        try:
            import ctypes
            ctypes.windll.shcore.SetProcessDpiAwareness(1)   # écran net en haute résolution
        except Exception:
            pass
    app = None
    try:
        app = Photobooth()
        app.lancer()
    except Exception as e:
        log.exception("Erreur fatale")
        if app is not None:
            app.retirer_verrou()
            try:
                app.root.attributes("-topmost", False)
                app.root.attributes("-fullscreen", False)
                app.root.withdraw()
            except Exception:
                pass
        # Redémarrage automatique (au plus 3 fois en 10 minutes, pour éviter une boucle)
        fichier = os.path.join(DATA_DIR, "redemarrages.json")
        try:
            with open(fichier, encoding="utf-8") as f:
                recents = [t for t in json.load(f) if time.time() - t < 600]
        except Exception:
            recents = []
        if len(recents) < 3:
            try:
                with open(fichier, "w", encoding="utf-8") as f:
                    json.dump(recents + [time.time()], f)
                import subprocess
                cmd = [sys.executable] if getattr(sys, "frozen", False) else \
                    [sys.executable, os.path.abspath(__file__)]
                time.sleep(2)
                subprocess.Popen(cmd)
                log.info("Redémarrage automatique du Photobooth")
                sys.exit(1)
            except SystemExit:
                raise
            except Exception:
                log.exception("Redémarrage impossible")
        try:
            messagebox.showerror("Photobooth", "Le Photobooth a rencontré une erreur et s'est fermé.\n\n"
                                 f"{e}\n\nLe détail est dans photobooth.log ({DATA_DIR}).")
        except Exception:
            pass
        sys.exit(1)
